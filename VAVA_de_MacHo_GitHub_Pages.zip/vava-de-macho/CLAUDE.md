# CLAUDE.md — LEIA ISTO PRIMEIRO (VAVA de MacHo)

Este arquivo existe para quem abrir o projeto (Claude ou pessoa) entender tudo rápido. O dono do projeto fala **português** e não é programador: responda em português simples e sem enrolação.

---

## 0. REGRAS FIXAS (valem sempre, em toda mudança)

1. **SEMPRE entregar o HTML pronto para testar.** Toda alteração termina com `npm run build` e com o envio do arquivo `dist/vava_de_macho.html` (nome sugerido na entrega: `vava_de_macho_vX.Y.Z.html`). O HTML é obrigatório; o .zip do projeto é um extra. (Contas/login só funcionam com `npm start`; o HTML aberto direto cai para CONVIDADO.) Nunca dizer "pronto" sem ter mandado o HTML.
2. **SEMPRE registrar na aba ATUALIZAÇÕES.** Adicionar uma entrada nova NO TOPO da lista `UPDATES` em `src/js/28-updates.js`, subindo a versão (0.0.1 → 0.0.2 → 0.0.3…), com data (dd/mm/aaaa), um título curto e a lista do que mudou em português simples. Atualizar também `"version"` no `package.json`. O rodapé do menu (`v0.0.x`) e o selo "ATUAL" vêm dessa lista automaticamente. A aba foi resetada em 03/11/2026 (versão 0.0.0). Versão atual: **0.0.12**; a próxima entrada é a **0.0.13**.
3. **Nunca editar `dist/` na mão.** Editar só em `src/` e rodar o build.
3b. **Manter o código formatado e legível:** depois de editar, rodar `npm run format` (Prettier, config em `.prettierrc.json`; linhas até ~100 colunas, uma instrução por linha). Não escrever código em linhas gigantes. Funções novas devem ter um comentário curto dizendo o que fazem, em português.
4. **Testar antes de entregar** (ver seção 9). Não entregar sem ter aberto no navegador e conferido que não há erro de JavaScript e que a mudança funciona.
5. Quando o dono pedir algo ambíguo, escolher a leitura mais razoável, fazer, e avisar qual leitura foi usada.
6. Ao final: dizer em poucas linhas o que mudou, o que NÃO foi possível/foi decidido, e mandar o HTML.

---

## 1. O que é o jogo

**VAVA de MacHo**: FPS tático 5v5 no navegador, inspirado em Valorant, feito com **Three.js r128** (carregado por CDN) e **PeerJS 1.5.4** (CDN, para sala P2P). Tudo é gerado em **um único HTML** (`dist/vava_de_macho.html`, ~285 KB) a partir de fontes modulares em `src/`. Sem framework, sem bundler: `build.js` só concatena arquivos.

- Mapa jogável: **Ascent** (cidade italiana; Site A a leste, Site B a oeste, Torre Grande no centro). Haven e Bind aparecem como "EM BREVE" (`locked:true`).
- Modo de jogo: ataque/defesa com **spike** (bomba), fase de compra, economia, rodadas até 13 (prorrogação em 12x12: vence quem fizer 2 seguidas).
- Modos no menu: **Servidor local** (offline/servidor próprio), **Competitivo** (sala P2P por código de 4 letras), **Treino** (campo de tiro com bots/alvos).
- Agentes (5): **Phoenix, Neon, Jett, Omen, Yoru**, cada um com 4 habilidades (C, Q, E e ultimate X).
- Lojas/armas: Classic, Ghost, Frenzy, Sheriff, Spectre, Stinger, Phantom, Vandal, Operator (luneta 2.5x/5x), facas (Faca Tática, Karambit, Kukri, Kunai, Tanto, Butterfly), escudos (leve 25 / pesado 100).

## 2. Estrutura de pastas

```
CLAUDE.md            este arquivo
README.md            resumo curto + comandos
package.json         scripts (build/start/dev) e "version" (= versão do jogo)
build.js             junta src/ em dist/vava_de_macho.html
.prettierrc.json     estilo do código (usado por `npm run format`)
dist/                SAÍDA do build (não editar)
server/server.js     servidor HTTP + WebSocket sem dependências (Node 18+)
src/
  body.html          todo o HTML da interface (HUD, menus, loja, abas)
  css/               01-base · 02-shop · 03-training · 04-minimap-mapselect · 05-spike-end-arsenal(+aba atualizações)
  js/NN-*.js         módulos principais (ordem numérica)
  js/patch/NN-*.js   "patch v0.99": ajustes que rodam DEPOIS, dentro de um IIFE
```

## 3. Como o build funciona (importante!)

`build.js` monta o HTML nesta ordem: CSS (`src/css/*.css` em ordem alfabética) → `body.html` → scripts do Three/PeerJS (CDN) → **script 1**: todos os `src/js/*.js` concatenados em ordem alfabética/numérica, dentro de `"use strict"` → **script 2**: todos os `src/js/patch/*.js` concatenados dentro de um IIFE `(function(){ ... })();`.

Consequências:
- Os módulos principais **compartilham o mesmo escopo global**. Dois `const`/`let` com o mesmo nome em arquivos diferentes quebram o jogo inteiro. Antes de criar nome novo, procure se já existe (`grep -n "const Nome" src/js/*.js`).
- A **ordem numérica importa**: um módulo só pode usar no topo o que foi definido por arquivo de número menor (dentro de funções, qualquer um pode ser chamado, desde que já exista na hora da chamada).
- Os arquivos do `patch/` enxergam tudo do script principal, mas o que eles declaram fica privado no IIFE (só vira público via `window.X`, como `window.Fx99`, `window.Mt99`). Eles **sobrescrevem/enrolam** funções do principal (ex.: `updateCamera` é reatribuída em `patch/06-camera.js` para chamar `Fx.cam()`).
- O código foi **reformatado** (antes da aba ser resetada) (antes eram linhas de 300+ caracteres). Agora dá para ler e editar normalmente com Read/Edit. Se aparecer código denso novo, rode `npm run format`.
- Novo módulo = novo arquivo `src/js/NN-nome.js` com o próximo número livre (hoje o último é `33-boot.js`; a inicialização fica sempre no último arquivo. Módulo novo = próximo número livre antes do boot; se faltar número, renomeie o boot para um maior).

## 4. Mapa dos módulos (`src/js/`)

| Arquivo | O que tem |
|---|---|
| `00-store.js` | `Store`: tudo que o jogo salva (`vdh_prof`, `vdh_cfg`, `vdh_knife`) passa por aqui. Convidado usa a chave normal; conta online usa `chave@id` e avisa o servidor. **Nunca use `localStorage` direto para dados do jogador.** |
| `01-maps.js` | Constantes do mundo (`S`=1/20 px→m, `WALL_H=5`, `EYE=1.65`, `RADIUS=.4`, `SPEED=5.2`), `MAP_DATA` (layout dos mapas), `BOX_H` (altura das caixas por tipo: V.9 X2.4 M1.2 N.9 K2.6 G1.3 T2.4 W1.3 P2.8 L1.1 C4.2 R1.2 S2.4) |
| `02-state.js` | Estado global: `renderer, scene, camera, segs` (paredes: `[ax,az,bx,bz,idxBarreira,porta,topo]`), `pos, vel, yaw, pitch, keys` |
| `03-textures.js` | Texturas procedurais em canvas |
| `04-scene.js` | `initScene`, luz, `BOXES` (`[x1,z1,x2,z2,topo]` em metros) e `POLYS` (sólidos escaláveis), `addEdges` |
| `05-city-map.js` | Geração da cidade/Ascent, paredes, caixas, barris, chão, sites A/B, spawns, `inPoly`, `ceilH` (teto) |
| `06-barriers.js` | Barreiras de energia da fase de compra |
| `07-controls.js` | Mouse/touch, teclas, `setQuality`, `resetPlayer`, `handleResize` |
| `08-movement.js` | **Física do jogador** (ver seção 6) |
| `09-loop-config.js` | Teclas configuráveis (`KB_DEF`), `CFG2` (salva em localStorage `vdh_cfg`), limite de FPS, resolução dinâmica, **loop `animate`** (física em passo mínimo de 1/240 s), escolha de lado (`SideSel`, máx. 5 por lado) |
| `10-game-config.js` | `CFG` (economia/tempos), `CROSS` (mira), `WeaponRegistry`/`WR` (todas as armas), escudos |
| `11-models.js` | Modelos 3D por listas de peças (armas, personagem/avatar, mãos), `animAv` (animação do avatar), **`mkBody`** (cria o corpo do outro jogador/bot + nome) |
| `11b-new-guns.js` | Modelos 3D e cores (`GP`) das armas novas: Shorty, Bandit, Bucky, Judge, Bulldog, Guardian, Marshal, Outlaw, Ares, Odin. Os dados delas (preço, dano…) ficam em `WeaponRegistry` (10-game-config). Campos extras: `pel` projéteis, `fall` queda de dano, `burst`, `arate`, `spool`, `tight`, `zoom`, `zo`, `hip`, `rld1`, `spd` |
| `12-economy-round-shop-hud.js` | `Econ`, `Inv`, `Round` (fases buy/live, placar, prorrogação), `Shop` (loja B), `Hud` |
| `13-weapon-fx.js` | `Recoil`, `Cross`, `Tracer`, `Anim`, `Weapon` (tiro, recarga, trocas, alvos) |
| `14-audio.js` | `Sfx`: áudio WebAudio sintetizado (tiros, passos, oclusão 3D) |
| `15-scope.js` | Luneta do Operator |
| `16-abilities.js` | `Mv` (estado de movimento visto por habilidades), `ABI` (habilidades dos 5 agentes), `Hp` (vida), `Abil` |
| `17-doors-steps.js` | `Doors` (portas destrutíveis) e `Steps` (passos por superfície) |
| `18-spike.js` | `BOMB` (plantar 4 s, desarmar 7 s, 45 s de pavio) e `Bomb` |
| `19-game.js` | `Game` (lado, init, `resetRound`, teclas de jogo, `update` por frame) |
| `20-net.js` | `SERVER`, `Net` (WebSocket e P2P, envio de estado `t:'s'` a cada 50 ms, tiros `f`, dano `h`, morte `k`, avatar remoto `Net.av`) |
| `21-menu.js` | `Menu` (fluxo Menu → Mapa → Agente → Lado → Jogo) |
| `22-pause.js` | `Pause` (ESC, configurações) |
| `23-agents.js` | `AGENTS` e tela de escolha de agente |
| `24-mapselect.js` | Tela de escolha de mapa |
| `25-minimap-board.js` | `Stats`, `Mini` (minimapa, M = mapa grande), `Board` (placar TAB) |
| `26-training.js` | Modo treino (troca `segs`/`BOXES`/alvos pelos do campo e restaura ao sair) |
| `27-arsenal-boot.js` | Aba ARSENAL (`ArMenu`: escolher faca) e `Loader` (tela de carregamento) |
| `28-updates.js` | **Aba ATUALIZAÇÕES** (lista `UPDATES`, `Updates`) |
| `29-tabs-profile.js` | `Tabs` (barra de cima fixa), `Profile` (perfil + estatísticas por agente, salvos em `vdh_prof`), `SKINS`/`Skins` (skins = troca de cores), `AgentsPage` (aba AGENTES), `Career` (aba CARREIRA) |
| `30-stage.js` | `Stage`: palco 3D do agente (segunda cena, desenhada no lugar da cena do jogo enquanto `Stage.on`; `body.stage` esconde o menu) |
| `31-settings.js` | `Settings`: painel único de configurações (abas GERAL · MIRA com prévia · CONTROLES · VÍDEO · ÁUDIO). O MESMO elemento `#stg` é movido (`Settings.mount`) entre o ESC (`#pSetHost`) e a aba CONFIGURAÇÕES (`#cfHost`), por isso os ids dos controles (`sens`, `fov`, `vol`, `kb`, `pQ`…) existem uma vez só. `SETX` = ajustes simples; mira = `CROSS` (10-game-config) + `xApply/xHtml/xPaint` (13-weapon-fx); salva via `CFG2.save()` |
| `32-auth.js` | `Auth`: tela de login, sessão, sincronização da conta com o servidor (`/api/*`). Convidado = sem conta |
| `33-boot.js` | **Inicialização do jogo**: `Auth.init(...)` → `Loader.show()` → `startGame()` (`initScene`, `Pause.init`, `Menu.init`, `Tabs.init`… e `window.MAP`). Roda por último |
| `patch/01-helpers.js` | Atalhos (`V3`, `$`, `rnd`, `bm2`…) |
| `patch/02-audio.js` | Áudio novo (inclui `Sfx.mantle`) |
| `patch/03-effects.js` | `Fx`: efeitos, fumaça (`Fx.blocked`), esconder/mostrar arma |
| `patch/04-bomb.js` | Modelo/animação da spike |
| `patch/05-climb.js` | Resquício do antigo "puxar": hoje só define `Mt` vazio (a subida real está em `08-movement.js`) |
| `patch/06-camera.js` | `wallBetween` (linha de visão), `Fx.cam` (morte, tremor, **visibilidade do nome**) |
| `patch/07-music.js` | Música de tensão dos últimos 10 s da spike |

## 5. Interface (`src/body.html` + `src/css`)

- IDs importantes: `#menu`, `#mTabs` (abas: JOGAR, ARSENAL, AGENTES, CARREIRA, ATUALIZAÇÕES, **CONFIGURAÇÕES** = filhos 0..5), `#mName` (nome do jogador), `#mPages` (conteúdo das abas: `#mMain` jogar, `#arMenu` arsenal, `#agMenu` agentes, `#caMenu` carreira, `#upMenu` atualizações, `#cfMenu` configurações; só um tem a classe `on`). Não existe mais rodapé (`#mBot`); a versão fica em `#ver` no logo, `#pause`, `#shop`, `#agents`, `#mapSelect`, `#sideSel`, `#hudL/#hudB/#score`, `#board`, `#mini/#bigmap`.
- Regra CSS crítica: no menu (`body.menu`), tudo some **exceto** os ids listados em `body.menu>*:not(#menu):not(canvas):not(#fps)…` (em `01-base.css`). Ao criar uma tela de tela cheia nova no menu, adicione `:not(#idDela)` lá.
- Para uma aba nova do menu: adicionar `<span>` em `#mTabs`, uma `<div class="pg">` dentro de `#mPages`, o id dela em `Tabs.ids` e o render em `Tabs.go` (`29-tabs-profile.js`). ESC volta para JOGAR.
- Skins por mérito: metas em `SKIN_REQ` (`29-tabs-profile.js`; skin i+1 de cada agente, estatística do próprio agente). `Skins.open(id,i)` diz se está liberada; `Skins.sel` ignora skin bloqueada. `Profile.rec` avisa ao desbloquear.
- Skins: o corpo/mão são montados com `agentOf(id)`; a skin só vale dentro de `Skins.run(...)` (ver `mkHand` e `Net.mkAv`). Estatísticas: `Profile.rec(agente, 'p'|'w'|'k'|'d'|'h')`.

## 6. Física e movimento (`src/js/08-movement.js`)

Tudo em metros. O objeto **`MOVE`** concentra os parâmetros (ajuste fino aqui):
`H 1.80 / HC 1.18` (altura em pé/agachado), `STEP .35` (degrau), `G 30`, `JUMP_H 1.40` (Jett 1.92), `JUMP_KEEP 1`, `JUMP_CD 0`, `JUMP_BUF .12`, `AIR_ACCEL 75`, `AIR_WISH .55`, `AIR_MAXK 1.55`, `REACH 1.3`, `REACH_MIN .25`, `GRAB_R .35`, `MANTLE_T .30`.

Fluxo: `updateMovement(dt)` lê teclas → `Move.step(h)` (passos de até 1/120 s) → `moveGround`/`moveAir` → colisão (`checkCollisions` contra `segs`) → vertical (`Terrain.ground`, gravidade, pouso).

Decisões já tomadas (não desfazer sem o dono pedir):
- **Bhop NUNCA automático**: o pulo é por toque (`jprev`/`jbuf`), um toque de espaço por pulo, apertado até 0,12 s antes de pousar. Segurar espaço não pula sozinho.
- **A e D funcionam no ar** (strafe estilo Source: `moveAir` só acelera se a velocidade na direção desejada for menor que `AIR_WISH`; W sozinho não ganha velocidade). Teto de velocidade = `AIR_MAXK` × corrida.
- Pousar com pulo já apertado (bhop) **não perde velocidade** (`land()` ignora `LAND_LOSS` se `jbuf>0`).
- **Subir em objetos** (`Move.ledge()` + animação `Move.mt`): no ar, olhando/andando para uma quina cujo topo esteja entre `Mv.h+REACH_MIN` e `Mv.h+REACH` (até ~2,6 m com o pulo normal), se houver espaço em cima (`Terrain.headroom`), o jogador se agarra e sobe em `MANTLE_T` s. Não funciona em objetos de 2,8 m ou mais, nem sem pular, nem no modo fantasma (Omen/Yoru).
- SHIFT = andar devagar e silencioso · CTRL = agachar.

## 7. Regras de jogo já decididas

- **Nome sobre a cabeça** (`mkBody` cria o sprite, `Fx.cam` em `patch/06-camera.js` decide se aparece): só aparece para jogador do **mesmo time** (`Net.ps === Game.side`) e somente **sem parede/porta/barreira no meio** (`wallBetween`). Inimigos, bots do treino e decoys nunca mostram nome.
- Times: `Game.side` = meu lado (`'atk'`/`'def'`), `Net.ps` = lado do outro jogador. Máx. 5 por lado (`MAX_SIDE`). Hoje a partida em rede é 1x1 (o servidor casa 2 jogadores por sala).
- Economia (PROVISÓRIO, ajustável em `CFG`): 800 iniciais, vitória 3000, derrota 1900, teto 9000, compra 30 s, rodada 100 s. Ultimate custa 5 pontos (`ULT_COST`): 1 por abate, 1 ao plantar, 1 ao desarmar; sem ganho por tempo; pontos passam entre rodadas. Smoke/flash usam cargas (`CHG` em `16-abilities.js`, campo `chg` em `ABI`), compradas na coluna HABILIDADES da loja (`Shop.abilCol`).

## 8. Servidor e rede

- `npm start` sobe `server/server.js` (porta 3000, `PORT=4000 npm start` muda). Ele serve o HTML e um WebSocket mínimo que casa **2 jogadores por sala** e repassa as mensagens. Abrindo o HTML direto (`file://`), "Servidor local" tenta `localhost:3000` e, se não houver servidor, cai para partida offline.
- P2P (PeerJS): "Criar sala" gera código de 4 letras (peer id `mapafps-CODIGO`); o outro entra com o código.
- Mensagens (`Net.recv`): `s` estado do jogador (x,y,z,yaw,agente,arma,agachado,no-ar), `f` tiro, `h` dano, `k` morte, `c` habilidade, `bp`/`bd` plantar/desarmar, `side` lado escolhido.

### Login, contas e banco de dados (v0.0.8)

- Ordem ao abrir: **LOGIN (`#login`) → tela de carregamento (`#loader`, começa escondido) → menu**. O mapa/cena só é montado em `startGame()` (`33-boot.js`) depois do login.
- Contas ficam em `server/data/db.json` (`DB_FILE=` muda; já está no `.gitignore`; backup = copiar o arquivo). Senha com scrypt + sal; token de sessão de 90 dias guardado só como hash; limite de tentativas por IP e bloqueio de 5 min após 8 senhas erradas; gravação atômica.
- API (JSON, `Authorization: Bearer <token>`, CORS liberado para abrir o HTML de `file://`): `POST /api/register`, `POST /api/login`, `GET /api/me`, `GET|PUT /api/data`, `POST /api/logout`. A conta guarda só as chaves de `Store.KEYS` (e o servidor só aceita essas).
- Cliente: `Auth.queue()` (chamado por `Store.set`) manda os dados 1,5 s depois da última mudança; no login `Auth.pull()` baixa. Se ficou alteração não enviada (`vdh_dirty@id`), a versão local vence.
- Convidado: sem servidor ou botão "JOGAR COMO CONVIDADO"; usa as chaves antigas do navegador.
- Conta online: o nome do menu é o nome da conta (campo travado).
- O WebSocket da partida (`/` com upgrade) **ainda não exige login**.

## 9. Como testar antes de entregar

1. `npm run build` (tem que imprimir `OK -> .../dist/vava_de_macho.html`).
2. Checar sintaxe dos dois `<script>` do HTML gerado (por exemplo `new Function(trecho)` em Node).
3. Teste real no navegador headless com **Playwright** (já instalado no ambiente do Claude). Como a sandbox pode não alcançar os CDNs, baixe `three@0.128.0` e `peerjs@1.5.4` com `npm pack` e use `page.route('**/three.min.js', ...)` e `page.route('**/peerjs.min.js', ...)` para servir os arquivos locais. Para checar física sem jogar: `Menu.cancel(); Menu.on=false; Pause.on=true;` (para o loop automático) e chamar `updateMovement(1/240)` em laço, controlando `keys.w/a/d/' '`, `yaw`, `pos`, `vel`. Os globais (`Move`, `Mv`, `BOXES`, `segs`, `Net`, `Game`…) são acessíveis em `page.evaluate`.
4. Para telas/menus, tirar screenshot (`page.screenshot`) e olhar.
5. Só então empacotar e enviar o HTML (regra 0.1).

## 10. Armadilhas conhecidas

- Nomes duplicados entre arquivos do script principal derrubam tudo (ver seção 3).
- `Training` troca `segs`/`BOXES` ao entrar e restaura ao sair: código novo que leia colisão deve usar sempre `segs`/`BOXES` atuais, nunca cópias guardadas.
- `Move.cap` é o teto de velocidade horizontal no ar, definido em `Move.leave()` na decolagem.
- Habilidades que mexem em velocidade/altura usam `Mv.vy`, `Mv.dx/dz`, `Mv.speed`, `Mv.ghost` (ver `16-abilities.js`).
- A câmera do jogador é posta em `updateCamera()` (`08-movement.js`) e depois ajustada por `Fx.cam()` (patch).
- Não há mais mapas além de Ascent: `haven` e `bind` têm `layout:null`.

## 11. Onde mexer para mudar cada coisa

| Quero mudar… | Arquivo e lugar |
|---|---|
| Velocidade de corrida, tamanho do jogador, altura do olho | `src/js/01-maps.js` → `SPEED`, `EYE`, `RADIUS` |
| Gravidade, altura do pulo, bhop, degrau, subir em quinas, agachar | `src/js/08-movement.js` → objeto `MOVE` |
| Dano, preço, cadência, recoil, carregador das armas | `src/js/10-game-config.js` → `WeaponRegistry` |
| Dinheiro inicial, prêmios, tempo de compra e de rodada | `src/js/10-game-config.js` → `CFG` |
| Rodadas para vencer, prorrogação | `src/js/12-economy-round-shop-hud.js` → `WIN_ROUNDS`, `OT_AT` |
| Habilidades dos agentes (recarga, duração, dano) | `src/js/16-abilities.js` → `ABI` |
| Lista/descrição dos agentes na tela de escolha | `src/js/23-agents.js` → `AGENTS` |
| Tempo de plantar/desarmar/explodir a spike | `src/js/18-spike.js` → `BOMB` |
| Layout do mapa, altura das caixas | `src/js/01-maps.js` → `MAP_DATA`, `BOX_H` |
| Teclas padrão | `src/js/09-loop-config.js` → `KB_DEF`, `KB_NAME` |
| Nome sobre a cabeça | `src/js/11-models.js` → `mkBody` e `src/js/patch/06-camera.js` → `Fx.cam` |
| Sons (tiro, passo, pouso) | `src/js/14-audio.js` e `src/js/patch/02-audio.js` |
| Menu, abas, telas | `src/body.html` e `src/css/` |
| Histórico de versões | `src/js/28-updates.js` → `UPDATES` |
| Servidor/partida em rede | `server/server.js` e `src/js/20-net.js` |
| Contas, login, banco | `server/server.js` (API/banco) e `src/js/32-auth.js` (cliente) |
| Configurações, mira, prévia | `src/js/31-settings.js` e `src/css/09-settings.css` |
| O que é salvo por jogador | `src/js/00-store.js` (`Store.KEYS`) e `DATA_KEYS` em `server/server.js` |

## 12. Histórico

Ver a aba ATUALIZAÇÕES do jogo ou `src/js/28-updates.js`. A lista foi zerada: versão atual **0.0.12**, a próxima entrada será a **0.0.13**.


Habilidades com usos por rodada: campo `rr` em `ABI` (usos que voltam a cada rodada, em `st[i].u`); `rk` = +1 uso por abate (Yoru E). Cargas compradas: campo `chg`.
