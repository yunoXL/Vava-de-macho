// Servidor do VAVA de MacHo: serve o HTML do jogo + WebSocket que casa 2 jogadores por sala e repassa as mensagens.
// Uso:  npm install && npm start   ->  http://localhost:3000   (PORT=4000 npm start para mudar a porta)
const http = require('http'),
  fs = require('fs'),
  path = require('path');
const crypto = require('crypto');
const PORT = +process.env.PORT || 3000,
  ROOT = path.join(__dirname, '..'),
  HTML = path.join(ROOT, 'dist', 'vava_de_macho.html');
const MAX_MSG = 64 * 1024,
  ROOM_SIZE = 2;

// ---- WebSocket mínimo (RFC 6455), sem dependências: texto, ping/pong, close ----
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
class WS {
  constructor(sock) {
    this.sock = sock;
    this.readyState = 1;
    this.buf = Buffer.alloc(0);
    this.frag = null;
    this.h = {};
    sock.setNoDelay(true);
    sock.on('data', d => {
      this.buf = Buffer.concat([this.buf, d]);
      try {
        this.parse();
      } catch (_) {
        this.terminate();
      }
    });
    sock.on('close', () => this.fin());
    sock.on('error', () => this.fin());
  }
  on(e, f) {
    this.h[e] = f;
    return this;
  }
  emit(e, ...a) {
    this.h[e] && this.h[e](...a);
  }
  fin() {
    if (this.readyState === 3) return;
    this.readyState = 3;
    this.emit('close');
  }
  frame(op, payload) {
    const n = payload.length;
    let head;
    if (n < 126) head = Buffer.from([0x80 | op, n]);
    else if (n < 65536) {
      head = Buffer.alloc(4);
      head[0] = 0x80 | op;
      head[1] = 126;
      head.writeUInt16BE(n, 2);
    } else {
      head = Buffer.alloc(10);
      head[0] = 0x80 | op;
      head[1] = 127;
      head.writeBigUInt64BE(BigInt(n), 2);
    }
    return Buffer.concat([head, payload]);
  }
  send(str) {
    if (this.readyState === 1) this.sock.write(this.frame(1, Buffer.from(str)));
  }
  ping() {
    if (this.readyState === 1) this.sock.write(this.frame(9, Buffer.alloc(0)));
  }
  close() {
    if (this.readyState !== 1) return;
    this.readyState = 2;
    try {
      this.sock.end(this.frame(8, Buffer.alloc(0)));
    } catch (_) {}
  }
  terminate() {
    this.readyState = 3;
    this.sock.destroy();
    this.emit('close');
  }
  parse() {
    for (;;) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = !!(b[0] & 0x80),
        op = b[0] & 15,
        masked = !!(b[1] & 0x80);
      let len = b[1] & 127,
        o = 2;
      if (len === 126) {
        if (b.length < 4) return;
        len = b.readUInt16BE(2);
        o = 4;
      } else if (len === 127) {
        if (b.length < 10) return;
        len = Number(b.readBigUInt64BE(2));
        o = 10;
      }
      if (len > MAX_MSG) return this.terminate();
      if (!masked) return this.terminate(); // cliente sempre mascara
      if (b.length < o + 4 + len) return;
      const mask = b.subarray(o, o + 4),
        data = Buffer.from(b.subarray(o + 4, o + 4 + len));
      for (let i = 0; i < len; i++) data[i] ^= mask[i & 3];
      this.buf = b.subarray(o + 4 + len);
      if (op === 8) return this.close();
      if (op === 9) {
        this.sock.write(this.frame(10, data));
        continue;
      }
      if (op === 10) {
        this.emit('pong');
        continue;
      }
      if (op === 1 || op === 2 || op === 0) {
        if (op !== 0) this.frag = { op, parts: [] };
        if (!this.frag) continue;
        this.frag.parts.push(data);
        if (fin) {
          const f = this.frag;
          this.frag = null;
          this.emit('message', Buffer.concat(f.parts), f.op === 2);
        }
      }
    }
  }
}

// ---- Mini banco de dados de contas (arquivo JSON, sem dependências) ----
// Guarda usuários (senha com scrypt + sal), sessões (só o hash do token) e os dados do jogo de cada conta.
// Arquivo: server/data/db.json  (DB_FILE=/outro/caminho.json muda). Faça backup copiando esse arquivo.
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data', 'db.json');
const DATA_KEYS = ['vdh_prof', 'vdh_cfg', 'vdh_knife']; // o que o jogo salva na conta
const MAX_VAL = 60000; // tamanho máximo de cada valor salvo
const SESSION_MS = 90 * 24 * 3600 * 1000;
const NAME_RE = /^[A-Za-z0-9_]{3,16}$/;

function loadDb() {
  let raw;
  try {
    raw = fs.readFileSync(DB_FILE, 'utf8');
  } catch (_) {
    return { v: 1, users: {}, sessions: {} }; // primeira vez: banco novo
  }
  try {
    const j = JSON.parse(raw);
    return { v: 1, users: j.users || {}, sessions: j.sessions || {} };
  } catch (_) {
    // arquivo estragado: guarda uma cópia e começa vazio (nunca apaga em silêncio)
    const bak = DB_FILE + '.corrompido-' + Date.now();
    fs.renameSync(DB_FILE, bak);
    console.log('ATENÇÃO: banco ilegível. Cópia guardada em ' + bak);
    return { v: 1, users: {}, sessions: {} };
  }
}
const db = loadDb();
let dbTimer = null;
function flushDb() {
  clearTimeout(dbTimer);
  dbTimer = null;
  try {
    fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    const tmp = DB_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, DB_FILE); // troca atômica: nunca fica meio escrito
  } catch (e) {
    console.log('ERRO ao salvar o banco: ' + e.message);
  }
}
const saveDb = () => {
  if (!dbTimer) dbTimer = setTimeout(flushDb, 300);
};
for (const sig of ['SIGINT', 'SIGTERM'])
  process.on(sig, () => {
    flushDb();
    process.exit(0);
  });

const sha = t => crypto.createHash('sha256').update(t).digest('hex');
const scrypt = (pw, salt) =>
  new Promise((ok, no) => crypto.scrypt(pw, salt, 64, (e, k) => (e ? no(e) : ok(k))));
const userById = id => Object.values(db.users).find(u => u.id === id);

// limites contra tentativa em massa: por IP (todas as chamadas de conta) e por usuário (senha errada)
const ipHits = new Map(),
  lockouts = new Map();
function tooMany(ip) {
  const now = Date.now();
  let r = ipHits.get(ip);
  if (!r || now - r.t > 600000) ipHits.set(ip, (r = { n: 0, t: now }));
  return ++r.n > 40;
}
const isLocked = key => (lockouts.get(key) || { until: 0 }).until > Date.now();
function failedLogin(key) {
  const r = lockouts.get(key) || { n: 0, until: 0 };
  if (++r.n >= 8) {
    r.n = 0;
    r.until = Date.now() + 5 * 60000; // 8 erros = 5 min de espera
  }
  lockouts.set(key, r);
}

function newSession(uid) {
  const tok = crypto.randomBytes(32).toString('hex');
  db.sessions[sha(tok)] = { uid, exp: Date.now() + SESSION_MS };
  saveDb();
  return tok;
}
function authOf(req) {
  const m = /^Bearer ([a-f0-9]{64})$/.exec(req.headers.authorization || '');
  if (!m) return null;
  const s = db.sessions[sha(m[1])];
  if (!s || s.exp < Date.now()) return null;
  const user = userById(s.uid);
  return user ? { user, hash: sha(m[1]) } : null;
}
setInterval(() => {
  const now = Date.now();
  let n = 0;
  for (const k in db.sessions)
    if (db.sessions[k].exp < now) {
      delete db.sessions[k];
      n++;
    }
  if (n) saveDb();
}, 3600000);

const CORS = {
  'Access-Control-Allow-Origin': '*', // o jogo pode ser aberto de file://; usamos Bearer token, não cookies
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS'
};
const json = (res, code, o) => {
  res.writeHead(code, Object.assign({ 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, CORS));
  res.end(JSON.stringify(o));
};
function readBody(req, max) {
  return new Promise((ok, no) => {
    const parts = [];
    let n = 0;
    req.on('data', d => {
      n += d.length;
      if (n > max) {
        no(Object.assign(new Error('Pedido grande demais'), { status: 413 }));
        req.destroy();
        return;
      }
      parts.push(d);
    });
    req.on('end', () => {
      try {
        ok(JSON.parse(Buffer.concat(parts).toString('utf8') || '{}'));
      } catch (_) {
        no(Object.assign(new Error('JSON inválido'), { status: 400 }));
      }
    });
    req.on('error', no);
  });
}

async function api(req, res, u) {
  const ip = req.socket.remoteAddress || '?';
  try {
    if (req.method === 'OPTIONS') {
      res.writeHead(204, CORS);
      return res.end();
    }
    if (tooMany(ip)) return json(res, 429, { error: 'Muitas tentativas. Espere alguns minutos.' });

    if (u === '/api/register' && req.method === 'POST') {
      const b = await readBody(req, 2048),
        name = String(b.name || ''),
        pass = String(b.pass || '');
      if (!NAME_RE.test(name)) return json(res, 400, { error: 'Usuário: 3 a 16 letras, números ou _' });
      if (pass.length < 6 || pass.length > 64)
        return json(res, 400, { error: 'A senha precisa ter de 6 a 64 caracteres' });
      const key = name.toLowerCase();
      if (db.users[key]) return json(res, 409, { error: 'Esse nome de usuário já existe' });
      const salt = crypto.randomBytes(16).toString('hex'),
        hash = (await scrypt(pass, salt)).toString('hex');
      if (db.users[key]) return json(res, 409, { error: 'Esse nome de usuário já existe' }); // corrida
      const user = { id: crypto.randomBytes(5).toString('hex'), name, salt, hash, created: Date.now(), data: {} };
      db.users[key] = user;
      const token = newSession(user.id);
      log('conta criada: ' + name);
      return json(res, 200, { token, user: { id: user.id, name: user.name } });
    }

    if (u === '/api/login' && req.method === 'POST') {
      const b = await readBody(req, 2048),
        name = String(b.name || ''),
        pass = String(b.pass || ''),
        key = name.toLowerCase(),
        bad = () => json(res, 401, { error: 'Usuário ou senha incorretos' });
      if (isLocked(key)) return json(res, 429, { error: 'Muitos erros. Espere 5 minutos.' });
      const user = NAME_RE.test(name) && db.users[key];
      if (!user || pass.length > 64) {
        await scrypt('x', 'y'); // gasta o mesmo tempo: não revela se o usuário existe
        failedLogin(key);
        return bad();
      }
      const got = await scrypt(pass, user.salt),
        want = Buffer.from(user.hash, 'hex');
      if (got.length !== want.length || !crypto.timingSafeEqual(got, want)) {
        failedLogin(key);
        return bad();
      }
      lockouts.delete(key);
      return json(res, 200, { token: newSession(user.id), user: { id: user.id, name: user.name } });
    }

    // daqui para baixo precisa estar logado
    const a = authOf(req);
    if (!a) return json(res, 401, { error: 'Sessão vencida. Entre de novo.' });

    if (u === '/api/me' && req.method === 'GET')
      return json(res, 200, { user: { id: a.user.id, name: a.user.name } });

    if (u === '/api/data' && req.method === 'GET') return json(res, 200, { data: a.user.data || {} });

    if (u === '/api/data' && req.method === 'PUT') {
      const b = await readBody(req, 200 * 1024),
        d = b && typeof b.data === 'object' && b.data ? b.data : null;
      if (!d) return json(res, 400, { error: 'Dados inválidos' });
      const out = a.user.data || {};
      for (const k of DATA_KEYS) {
        const v = d[k];
        if (typeof v !== 'string' || v.length > MAX_VAL) continue;
        if (k !== 'vdh_knife')
          try {
            JSON.parse(v);
          } catch (_) {
            continue;
          }
        out[k] = v;
      }
      a.user.data = out;
      saveDb();
      return json(res, 200, { ok: true });
    }

    if (u === '/api/logout' && req.method === 'POST') {
      delete db.sessions[a.hash];
      saveDb();
      return json(res, 200, { ok: true });
    }

    return json(res, 404, { error: 'Não encontrado' });
  } catch (e) {
    return json(res, e.status || 500, { error: e.status ? e.message : 'Erro no servidor' });
  }
}

if (!fs.existsSync(HTML)) require(path.join(ROOT, 'build.js')); // gera o HTML se ainda não existir

const server = http.createServer((req, res) => {
  const u = req.url.split('?')[0];
  if (u === '/status' && req.method === 'OPTIONS') {
    res.writeHead(204, CORS);
    return res.end();
  }
  if (u === '/' || u === '/index.html' || u === '/vava_de_macho.html') {
    fs.readFile(HTML, (e, b) => {
      if (e) {
        res.writeHead(500);
        return res.end('Rode: npm run build');
      }
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'no-cache'
      });
      res.end(b);
    });
  } else if (u.startsWith('/api/')) {
    api(req, res, u);
  } else if (u === '/status') {
    res.writeHead(200, Object.assign({ 'Content-Type': 'application/json' }, CORS));
    res.end(
      JSON.stringify({
        accounts: Object.keys(db.users).length,
        rooms: rooms.size,
        players: [...rooms.values()].reduce((n, r) => n + r.size, 0)
      })
    );
  } else {
    res.writeHead(404);
    res.end('404');
  }
});

const clients = new Set();
server.on('upgrade', (req, sock) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') return sock.destroy();
  sock.write(
    'HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' +
      crypto
        .createHash('sha1')
        .update(key + GUID)
        .digest('base64') +
      '\r\n\r\n'
  );
  const ws = new WS(sock);
  clients.add(ws);
  ws.on('close', () => clients.delete(ws));
  onConnection(ws, req);
});
const rooms = new Map(); // id -> Set<ws>
let seq = 0;
const send = (ws, o) => {
  if (ws.readyState === 1) ws.send(JSON.stringify(o));
};
const others = ws => [...(rooms.get(ws.room) || [])].filter(x => x !== ws);

function onConnection(ws, req) {
  // sala com vaga (a mais antiga primeiro) ou nova sala
  let id = [...rooms.keys()].find(k => rooms.get(k).size < ROOM_SIZE);
  if (!id) {
    id = 'r' + ++seq;
    rooms.set(id, new Set());
  }
  const room = rooms.get(id);
  ws.room = id;
  ws.alive = true;
  room.add(ws);
  const peers = others(ws);
  send(ws, { t: 'hi', room: id, peer: peers.length > 0 });
  peers.forEach(p => send(p, { t: 'peer' }));
  log(`+ ${req.socket.remoteAddress} entrou em ${id} (${room.size}/${ROOM_SIZE})`);

  ws.on('pong', () => {
    ws.alive = true;
  });
  ws.on('message', (data, isBinary) => {
    if (isBinary) return;
    const txt = data.toString();
    let m;
    try {
      m = JSON.parse(txt);
    } catch (_) {
      return;
    }
    if (!m || typeof m.t !== 'string') return;
    others(ws).forEach(p => {
      if (p.readyState === 1) p.send(txt);
    }); // repasse direto ao adversário
  });
  ws.on('close', () => {
    const r = rooms.get(ws.room);
    if (!r) return;
    r.delete(ws);
    r.forEach(p => send(p, { t: 'left' }));
    if (!r.size) rooms.delete(ws.room);
    log(`- saiu de ${ws.room} (${r.size}/${ROOM_SIZE})`);
  });
}

// derruba conexões mortas
setInterval(
  () =>
    clients.forEach(ws => {
      if (!ws.alive) return ws.terminate();
      ws.alive = false;
      ws.ping();
    }),
  20000
);

function log(s) {
  console.log(new Date().toISOString().slice(11, 19), s);
}
server.listen(PORT, () => {
  console.log(`VAVA de MacHo rodando em http://localhost:${PORT}`);
  console.log(`  contas salvas em ${DB_FILE} (${Object.keys(db.users).length} cadastradas)`);
  const nets = require('os').networkInterfaces();
  for (const k in nets)
    for (const n of nets[k])
      if (n.family === 'IPv4' && !n.internal)
        console.log(`  na rede local: http://${n.address}:${PORT}`);
});
