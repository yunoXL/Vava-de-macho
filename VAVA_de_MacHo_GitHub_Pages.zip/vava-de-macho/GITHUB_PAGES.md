# Publicar o VAVA de MacHo no GitHub Pages

## O que esta versão já prepara

- O build gera `dist/index.html` e mantém `dist/vava_de_macho.html`.
- O workflow `.github/workflows/pages.yml` compila e publica automaticamente ao enviar alterações para `main`.
- O jogo continua com o modo local/bots.
- O modo P2P manual existente (CRIAR SALA X1 / ENTRAR NA SALA) permanece disponível usando PeerJS.

## Limitação importante do multiplayer automático

GitHub Pages é hospedagem estática. Ele não executa `server/server.js`, não mantém WebSocket, não fornece fila de matchmaking e não hospeda o banco de contas. Por isso, o botão de busca automática que dependia do servidor Node não pode funcionar apenas com GitHub Pages. Nesta versão ele informa a limitação em vez de fingir que encontrou uma partida.

O P2P manual usa PeerJS e requer sinalização PeerJS; o serviço público PeerJS pode estar sujeito a disponibilidade, limites e restrições de rede. Conexões em algumas redes podem precisar de TURN. Para matchmaking automático real, será necessário adicionar um serviço de rendezvous/sinalização (por exemplo, Firebase Realtime Database/Supabase ou um pequeno serviço próprio). Para contas persistentes, também será necessário backend/banco de dados.

## Publicação pelo navegador (sem Git instalado)

1. Entre em https://github.com e crie uma conta.
2. Clique em **New repository**.
3. Nome: `vava-de-macho`. Marque **Public** e crie o repositório.
4. Extraia o ZIP do projeto no computador.
5. Abra o repositório no GitHub e clique em **Add file → Upload files**.
6. Envie o conteúdo da pasta `vava-de-macho` (não envie a pasta externa que contém tudo). Preserve a pasta `.github/workflows`.
7. Aguarde o envio e clique em **Commit changes**.
8. Abra a aba **Actions**. Aguarde o workflow **Publicar VAVA de MacHo no GitHub Pages** terminar com marca verde.
9. Abra **Settings → Pages**. Em **Build and deployment**, selecione **GitHub Actions** como source, se ainda não estiver selecionado.
10. O endereço será `https://SEU-USUARIO.github.io/vava-de-macho/`.

## Atualizar o jogo

Edite os arquivos em `src/`, envie as alterações para a branch `main` e o GitHub Actions fará o build e a publicação novamente. Não edite `dist/index.html` manualmente: ele é gerado pelo `build.js`.

## Teste local

É necessário Node.js 20 ou superior:

```bash
npm run build
```

Abra `dist/index.html` em um navegador para testar o modo local. Para testar o servidor antigo e o matchmaking que ele fornece na rede local:

```bash
npm start
```

O servidor Node antigo não é executado pelo GitHub Pages.
