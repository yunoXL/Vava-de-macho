// Junta src/ em um único HTML: node build.js  ->  dist/vava_de_macho.html
const fs = require('fs'),
  path = require('path');
const S = path.join(__dirname, 'src');
const read = f => fs.readFileSync(path.join(S, f), 'utf8');
const dir = d =>
  fs
    .readdirSync(path.join(S, d))
    .filter(f => /\.(js|css)$/.test(f))
    .sort()
    .map(f => read(path.join(d, f)));
const css = dir('css').join('');
const main = dir('js').join(''); // ordem alfabética: 01-, 02-, ... (escopo global compartilhado)
const patch = dir('js/patch').join(''); // corpo do IIFE v0.99
const staticHosting = process.env.VDH_STATIC_HOSTING === '1';
const runtimeConfig = `<script>window.VDH_STATIC_HOSTING = ${staticHosting ? 'true' : 'false'};</script>`;
const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>VAVA de MacHo</title>
<style>
${css}
</style>
</head>
<body>
${read('body.html')}
${runtimeConfig}
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/peerjs/1.5.4/peerjs.min.js"></script>
<script>
"use strict";
${main}
</script>
<script>
(function(){
${patch}
})();
</script>
</body>
</html>
`;
fs.mkdirSync(path.join(__dirname, 'dist'), { recursive: true });
const out = path.join(__dirname, 'dist', 'vava_de_macho.html');
const index = path.join(__dirname, 'dist', 'index.html');
fs.writeFileSync(out, html);
fs.writeFileSync(index, html);
fs.writeFileSync(path.join(__dirname, 'dist', '.nojekyll'), '');
console.log('OK ->', out, 'e', index, (html.length / 1024).toFixed(0) + ' KB');
