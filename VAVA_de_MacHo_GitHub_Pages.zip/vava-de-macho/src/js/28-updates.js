/* ========= ABA DE ATUALIZAÇÕES (menu principal) =========
   Para registrar uma atualização nova: adicione um objeto NO TOPO de UPDATES e suba o número (0.0.1, 0.0.2, ...).
   A versão do rodapé do menu e o título "ATUAL" vêm daqui. Lembre de atualizar também "version" no package.json. */
const UPDATES = [
  {
    v: '0.0.12',
    d: '05/11/2026',
    t: 'Loja igual à do Valorant',
    l: [
      'Loja refeita seguindo o menu de compra do Valorant: três grupos (PISTOLA, PRIMÁRIA e ESCUDOS), cartões grandes que ocupam a tela toda e borda verde-água nas armas que você já comprou.',
      'Primária em 3 colunas: SMGs com Shotguns, Rifles, e Snipers com Pesadas. Escudos em dois cartões altos com a barra (ex.: 100/100).',
      'Todas as armas aparecem para os dois lados, como no Valorant: Ghost, Spectre e Phantom não são mais só de defensor, e Frenzy, Stinger e Vandal não são mais só de atacante.',
      'As habilidades do agente ficam numa faixa embaixo. A barra de estatísticas continua ao passar o mouse; clique esquerdo compra e direito vende.'
    ]
  },
  {
    v: '0.0.11',
    d: '05/11/2026',
    t: 'Loja estilo Valorant, smokes mais longas e bomba maior',
    l: [
      'Loja reorganizada como a do Valorant: faixa de escudos e habilidades em cima e 4 colunas de armas (pistolas · SMGs e shotguns · rifles · snipers e metralhadoras), cada coluna do mais barato ao mais caro.',
      'Passe o mouse numa arma para ver na barra de baixo: dano de cabeça/corpo/perna, cadência, munição, recarga e penetração. Sem mouse, a barra mostra a arma na mão.',
      'Clique esquerdo compra, clique direito vende (só na fase de compra, devolve o preço cheio).',
      'Smokes bem mais longas: Véu de Névoa da Jett de 4,5 s para 11 s e Névoa Escura do Omen de 15 s para 28 s.',
      'Raio da explosão da spike de 16 m para 30 m (quem está dentro morre; o clarão e o susto vão até 48 m).'
    ]
  },
  {
    v: '0.0.10',
    d: '04/11/2026',
    t: '10 armas novas (arsenal completo do Valorant)',
    l: [
      'Pistolas: Shorty (¤300, 2 tiros, espingarda de bolso) e Bandit (¤600, 8 balas, 1 headshot mata em escudo leve).',
      'Shotguns: Bucky (¤850, bombeamento, mirar fecha os projéteis) e Judge (¤1850, automática).',
      'Rifles: Bulldog (¤2050, mirar = rajada de 3) e Guardian (¤2250, semiautomático com zoom 1.5x).',
      'Snipers: Marshal (¤950, zoom 2.5x) e Outlaw (¤2400, cano duplo, 2 balas, zoom 3.5x, atravessa parede bem).',
      'Pesadas: Ares (¤1600, 50 balas, fica mais precisa atirando sem parar) e Odin (¤3200, 100 balas, acelera após 8 tiros). As duas andam um pouco mais devagar.',
      'Shotguns atiram vários projéteis por disparo e o dano cai com a distância.',
      'Headshot agora usa o dano de cabeça de cada arma (antes era 3x o dano do corpo, no máximo 150).',
      'Todas já aparecem na loja (colunas SHOTGUNS e PESADAS) e valem para os dois lados.'
    ]
  },
  {
    v: '0.0.9',
    d: '04/11/2026',
    t: 'Skins desbloqueáveis por mérito',
    l: [
      'As 3 skins de cada agente agora se ganham jogando, com as estatísticas daquele agente: skin 1 = 100 abates, skin 2 = 20 vitórias, skin 3 = 75 headshots.',
      'Na aba AGENTES, skin bloqueada aparece apagada com o progresso (ex.: 37/100 ABATES). Clicar nela mostra o que falta.',
      'Quando você bate a meta aparece o aviso SKIN DESBLOQUEADA na hora.',
      'Se as estatísticas forem zeradas na CARREIRA, as skins voltam a ficar bloqueadas e o agente usa a padrão.'
    ]
  },
  {
    v: '0.0.8',
    d: '04/11/2026',
    t: 'Login, contas e configurações novas',
    l: [
      'Nova tela de LOGIN antes da tela de carregamento. Crie sua conta (usuário + senha) e entre. Dá para continuar com um clique na conta salva neste navegador.',
      'As contas ficam em um mini banco de dados no servidor (server/data/db.json). Cada conta guarda seu perfil, estatísticas, skins, faca, mira, teclas e configurações, e vale em qualquer computador que abra o jogo pelo servidor.',
      'Sem servidor no ar dá para jogar como CONVIDADO (salva só neste navegador, como antes). Botão SAIR/ENTRAR no canto de cima do menu.',
      'Configurações refeitas com abas: GERAL, MIRA, CONTROLES, VÍDEO e ÁUDIO. Abrem no ESC dentro do jogo e também na nova aba CONFIGURAÇÕES do menu principal.',
      'Aba MIRA com prévia ao vivo (fundos escuro, claro, grama, céu e tijolo), cor, espessura, comprimento, abertura, ponto central, tamanho do ponto, opacidade, contorno, 6 miras prontas e 3 vagas para guardar as suas. Clique na prévia para ver a mira abrindo como num tiro.',
      'Novas opções: inverter eixo Y, mostrar/esconder FPS, ligar/desligar sombras. Resolução dinâmica, qualidade e limite de FPS agora também ficam salvos.'
    ]
  },
  {
    v: '0.0.7',
    d: '03/11/2026',
    t: 'Habilidades com usos por rodada',
    l: [
      'Neon: Parede Elétrica (C) e Ricochete (Q) só podem ser usados 1 vez por rodada. Equipamento Voltaico (E) continua recarregando normalmente.',
      'Phoenix: Chama (C) e Mão Quente (Q) só podem ser usadas 1 vez por rodada.',
      'Omen: Passos Tenebrosos (C) pode ser usado 2 vezes por rodada.',
      'Yoru: Farsa (C) 1 vez por rodada. Salto Dimensional (E) 2 vezes por rodada, e ganha +1 uso a cada abate.',
      'Os usos voltam ao total no começo de cada rodada. O ícone mostra quantos usos restam.',
      'Jett não mudou.'
    ]
  },
  {
    v: '0.0.6',
    d: '03/11/2026',
    t: 'Ultimate com 5 pontos e smokes/flashes comprados na loja',
    l: [
      'Ultimate agora custa 5 pontos. Não ganha mais ponto por tempo: só 1 por abate, 1 ao plantar a spike e 1 ao desarmar a spike. Os pontos continuam de uma rodada para a outra. O ícone mostra quantos pontos você tem (ex.: 3/5).',
      'Smokes e flashes não têm mais tempo de recarga: agora têm cargas. Smoke: começa com 1 e dá para ter até 3. Flash: começa com 1 e dá para ter até 2.',
      'A loja ganhou a coluna HABILIDADES, que muda conforme o agente. Preços: smoke ¤200, flash ¤250 por carga. Só dá para comprar na fase de compra.',
      'Cargas que sobram passam para a rodada seguinte. A cada rodada você recebe de volta a carga grátis, se tiver gastado.',
      'Smokes: Véu de Névoa (Jett) e Névoa Escura (Omen). Flashes: Bola Curva (Phoenix), Cegueira (Yoru) e Visão Obscura (Omen). As outras habilidades continuam com recarga normal.',
      'No treino as cargas nunca acabam.'
    ]
  },
  {
    v: '0.0.5',
    d: '03/11/2026',
    t: 'Ajuste da escolha de agente',
    l: [
      'Os botões dos agentes ficam embaixo e o boneco 3D fica atrás, no centro da tela.',
      'Tirei a lista de habilidades da tela de escolha (elas continuam na aba AGENTES do menu).',
      'Se o palco 3D der algum erro, a tela mostra fundo escuro em vez do mapa do jogo.'
    ]
  },
  {
    v: '0.0.4',
    d: '03/11/2026',
    t: 'Telas de seleção novas',
    l: [
      'Escolha de mapa: o cartão escolhido cresce, os outros escurecem e o desenho do mapa se traça linha por linha.',
      'Escolha de agente: o agente aparece em 3D no fundo, parado e respirando, com luz na cor dele. Ao clicar em outro agente o 3D troca com um giro, um anel de luz e zoom. Os agentes ficam em fila no rodapé. A skin escolhida na aba AGENTES aparece no palco.',
      'Escolha de lado: tela cheia dividida na diagonal, ATACANTE (vermelho/laranja) de um lado e DEFENSOR (azul) do outro. Ao passar o mouse o lado cresce e mostra as vagas e uma frase curta.',
      'HUD das armas: a lista agora mostra 1 pistola, 2 principal e 3 faca, de cima para baixo, igual às teclas.'
    ]
  },
  {
    v: '0.0.3',
    d: '03/11/2026',
    t: 'Menu com abas, agentes com skins e carreira',
    l: [
      'Barra de cima fixa: JOGAR, ARSENAL, AGENTES, CARREIRA e ATUALIZAÇÕES agora só trocam o conteúdo de baixo, sem botão VOLTAR.',
      'Nova aba AGENTES: habilidades de cada agente, estatísticas por agente (partidas, vitórias, abates, mortes, K/D e headshots) e 3 skins por agente.',
      'As skins aparecem nas suas mãos e para o outro jogador na partida online.',
      'Nova aba CARREIRA: perfil neste computador com nome, descrição e estatísticas gerais. Procurar outros jogadores fica para quando existirem contas online.',
      'O código do nome (#0001) agora é único por perfil, sorteado na primeira vez.',
      'Rodapé do menu removido. A versão foi para o canto do logo e o texto do servidor saiu. As teclas continuam em Configurações > Teclas.'
    ]
  },
  {
    v: '0.0.2',
    d: '03/11/2026',
    t: 'Nome oficial: VAVA de MacHo',
    l: [
      'O jogo agora se chama VAVA de MacHo: título da aba, logo do menu, tela de carregamento e loja.'
    ]
  },
  {
    v: '0.0.1',
    d: '03/11/2026',
    t: 'Tela de carregamento',
    l: [
      'Nova tela preta com o logo e uma linha animada ao abrir o jogo.',
      'Ela cobre o tempo de montar o mapa e some com fade depois de no mínimo 2,5 segundos, quando tudo estiver pronto.'
    ]
  }
];
const VERSION = () => (UPDATES.length ? UPDATES[0].v : '0.0.0');
const Updates = {
  render() {
    $$('upCur').textContent = 'VERSÃO ATUAL ' + VERSION();
    if (!UPDATES.length) {
      $$('upList').innerHTML =
        '<div class="up"><p class="ut">Nenhuma atualização registrada ainda.</p></div>';
      return;
    }
    $$('upList').innerHTML = UPDATES.map(
      (u, i) =>
        '<div class="up"><div class="uh"><span class="uv">' +
        u.v +
        '</span>' +
        (i ? '' : '<span class="un">ATUAL</span>') +
        '<span class="ud">' +
        u.d +
        '</span></div><p class="ut">' +
        u.t +
        '</p><ul>' +
        u.l.map(x => '<li>' + x + '</li>').join('') +
        '</ul></div>'
    ).join('');
  },
  init() {
    const v = $$('ver');
    if (v) v.textContent = 'v' + VERSION();
  }
};
