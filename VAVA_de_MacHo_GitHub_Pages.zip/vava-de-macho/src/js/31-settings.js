/* ========= CONFIGURAÇÕES =========
   Um único painel (#stg) usado em dois lugares: no ESC dentro do jogo (#pSetHost)
   e na aba CONFIGURAÇÕES do menu principal (#cfHost). O painel é "mudado de lugar" com
   Settings.mount(), então os ids dos controles (sens, fov, vol, kb, pQ…) existem uma vez só.
   Abas: GERAL · MIRA (com prévia) · CONTROLES · VÍDEO · ÁUDIO. Tudo é salvo por CFG2.save(). */

/* ajustes simples (o resto fica em CROSS, KB e FPSU) */
const SETX = { sens: 3.6, fov: 80, vol: 80, inv: 0, fps: 1, shadow: 1, quality: 2, adr: 1 };

/* miras prontas (cartões na aba MIRA) */
const XPRE = [
  { n: 'PADRÃO', c: { color: '#ffffff', thick: 2, len: 9, gap: 3, dot: true } },
  { n: 'PONTO VERDE', c: { color: '#46ff8a', thick: 2, len: 0, gap: 0, dot: true, lines: false, dotS: 4 } },
  { n: 'CIANO FINA', c: { color: '#00f0ff', thick: 1, len: 7, gap: 2, dot: false } },
  { n: 'AMARELA', c: { color: '#ffe600', thick: 3, len: 8, gap: 4, dot: false } },
  { n: 'ABERTA', c: { color: '#ff4655', thick: 2, len: 6, gap: 9, dot: true } },
  { n: 'LONGA', c: { color: '#ffffff', thick: 2, len: 15, gap: 5, dot: false, out: false } }
];
const XCOL = ['#ffffff', '#46ff8a', '#00f0ff', '#ffe600', '#ff4655', '#ff7ad9', '#8a5cff', '#ff9a3b'];
const XBG = ['ESCURO', 'CLARO', 'GRAMA', 'CÉU', 'TIJOLO'];

const Settings = {
  el: null,
  tab: 0,
  bg: 0,
  xs: [null, null, null] /* 3 vagas para suas miras */,
  TABS: ['GERAL', 'MIRA', 'CONTROLES', 'VÍDEO', 'ÁUDIO'],

  /* helpers de HTML */
  sl(id, label, min, max, step) {
    return (
      '<label class="sr"><span>' +
      label +
      '</span><input type="range" id="' +
      id +
      '" min="' +
      min +
      '" max="' +
      max +
      '" step="' +
      (step || 1) +
      '"><b id="' +
      id +
      'V"></b></label>'
    );
  },
  ck(id, label) {
    return '<label class="sr"><span>' + label + '</span><input type="checkbox" id="' + id + '"></label>';
  },

  /* monta o painel (uma vez) */
  build() {
    const e = (this.el = document.createElement('div'));
    e.id = 'stg';
    const sw = XCOL.map(c => '<i data-c="' + c + '" style="background:' + c + '"></i>').join(''),
      bgs = XBG.map((n, i) => '<button data-b="' + i + '">' + n + '</button>').join('');
    e.innerHTML =
      '<div class="stT">' +
      this.TABS.map((t, i) => '<button data-t="' + i + '">' + t + '</button>').join('') +
      '</div>' +
      /* GERAL */
      '<div class="stP" data-p="0">' +
      this.sl('sens', 'SENSIBILIDADE', 1, 10, 0.1) +
      this.sl('fov', 'CAMPO DE VISÃO', 70, 100, 1) +
      this.ck('inv', 'INVERTER EIXO Y DO MOUSE') +
      '</div>' +
      /* MIRA */
      '<div class="stP" data-p="1"><div class="xw"><div class="xL">' +
      '<div class="xpv" id="xpv" title="Clique para simular um tiro"><div class="xc" id="xpc"><i class="u"></i><i class="d"></i><i class="l"></i><i class="r"></i><b></b></div></div>' +
      '<div class="xbg" id="xbg">' +
      bgs +
      '</div>' +
      '<div class="xcap">VAGAS DE MIRA</div><div class="xsl" id="xsl"></div>' +
      '</div><div class="xR">' +
      '<div class="xcol"><input type="color" id="xc"><div class="xsw" id="xsw">' +
      sw +
      '</div></div>' +
      this.sl('xt', 'ESPESSURA', 1, 6, 1) +
      this.sl('xl', 'COMPRIMENTO', 3, 20, 1) +
      this.sl('xg', 'ABERTURA', 0, 14, 1) +
      this.sl('xs', 'TAMANHO DO PONTO', 1, 6, 1) +
      this.sl('xa', 'OPACIDADE', 20, 100, 5) +
      this.ck('xn', 'MOSTRAR LINHAS') +
      this.ck('xd', 'PONTO CENTRAL') +
      this.ck('xo', 'CONTORNO PRETO') +
      '</div></div><div class="xcap">MIRAS PRONTAS — CLIQUE PARA USAR</div><div class="xpre" id="xpre"></div></div>' +
      /* CONTROLES */
      '<div class="stP" data-p="2"><div id="kb"></div><button class="stb" id="kbReset">RESTAURAR PADRÃO</button></div>' +
      /* VÍDEO */
      '<div class="stP" data-p="3"><div class="sr"><span>QUALIDADE GRÁFICA</span><div class="mrow" id="pQ"><button data-q="2">ALTA</button><button data-q="1">MÉDIA</button><button data-q="0">BAIXA</button></div></div>' +
      this.ck('adr', 'RESOLUÇÃO DINÂMICA (AUTO)') +
      this.ck('shd', 'SOMBRAS') +
      this.ck('fpsOn', 'MOSTRAR FPS') +
      '<label class="sr"><span>LIMITE DE FPS</span><select id="fpsl"><option value="0">DA TELA (AUTO)</option><option value="60">60</option><option value="90">90</option><option value="120">120</option><option value="144">144</option><option value="240">240</option><option value="-1">SEM LIMITE</option></select></label></div>' +
      /* ÁUDIO */
      '<div class="stP" data-p="4">' +
      this.sl('vol', 'VOLUME GERAL', 0, 100, 1) +
      '</div>';
    document.getElementById('pSetHost').appendChild(e);
    this.mk = e;
  },

  /* coloca o painel dentro de um lugar (ESC ou aba do menu) */
  mount(host, cls) {
    host.appendChild(this.el);
    this.el.classList.remove('inpause', 'inmenu');
    this.el.classList.add(cls);
    this.sync();
    this.go(this.tab);
  },
  go(i) {
    this.tab = i;
    this.el.querySelectorAll('.stT button').forEach((b, j) => b.classList.toggle('on', j === i));
    this.el.querySelectorAll('.stP').forEach((p, j) => p.classList.toggle('on', j === i));
    if (i === 1) this.xRender();
    if (i === 2) KB.render();
  },

  /* põe os valores atuais nos controles */
  sync() {
    const $ = id => this.el.querySelector('#' + id),
      set = (id, v, txt) => {
        $(id).value = v;
        $(id + 'V').textContent = txt === undefined ? v : txt;
      };
    set('sens', SETX.sens, (+SETX.sens).toFixed(1));
    set('fov', SETX.fov);
    set('vol', SETX.vol, SETX.vol + '%');
    $('inv').checked = !!SETX.inv;
    $('adr').checked = !!SETX.adr;
    $('shd').checked = !!SETX.shadow;
    $('fpsOn').checked = !!SETX.fps;
    $('fpsl').value = FPSU.free ? '-1' : String(FPSU.cap);
    this.el
      .querySelectorAll('#pQ button')
      .forEach(b => b.classList.toggle('on', +b.dataset.q === quality));
    $('xc').value = CROSS.color;
    set('xt', CROSS.thick);
    set('xl', CROSS.len);
    set('xg', CROSS.gap);
    set('xs', CROSS.dotS || 2);
    set('xa', CROSS.alpha === undefined ? 100 : CROSS.alpha, (CROSS.alpha === undefined ? 100 : CROSS.alpha) + '%');
    $('xn').checked = CROSS.lines !== false;
    $('xd').checked = !!CROSS.dot;
    $('xo').checked = CROSS.out !== false;
    this.xPreview();
    KB.render();
  },

  /* aplica os ajustes no jogo */
  apply() {
    sens = 0.0014 * SETX.sens;
    Scope.base = +SETX.fov;
    if (!Scope.on) {
      camera.fov = Scope.base;
      camera.updateProjectionMatrix();
    }
    Sfx.setVol(SETX.vol / 100);
    setQuality(SETX.quality);
    $$('fps').style.display = SETX.fps ? '' : 'none';
  },

  /* ----- aba MIRA ----- */
  xPreview() {
    const pv = this.el.querySelector('#xpv');
    pv.dataset.bg = this.bg;
    xApply(this.el.querySelector('#xpc'), CROSS, CROSS.gap);
    this.el.querySelectorAll('#xbg button').forEach((b, i) => b.classList.toggle('on', i === this.bg));
  },
  xRender() {
    /* vagas salvas */
    this.el.querySelector('#xsl').innerHTML = this.xs
      .map(
        (c, i) =>
          '<div class="xslot' +
          (c ? ' has' : '') +
          '"><div class="xmini" data-u="' +
          i +
          '">' +
          (c ? xHtml(c) : '<em>VAZIA</em>') +
          '</div><button data-sv="' +
          i +
          '">SALVAR AQUI</button></div>'
      )
      .join('');
    /* miras prontas */
    this.el.querySelector('#xpre').innerHTML = XPRE.map(
      (p, i) =>
        '<div class="xcard" data-pr="' +
        i +
        '"><div class="xmini">' +
        xHtml(Object.assign({}, CROSS_BASE, p.c)) +
        '</div><b>' +
        p.n +
        '</b></div>'
    ).join('');
    xPaint(this.el);
  },
  /* troca a mira inteira (pronta ou vaga) */
  xUse(c) {
    Object.assign(CROSS, CROSS_BASE, c);
    Cross.init();
    this.sync();
    CFG2.save();
  },
  /* lê os controles da mira e aplica */
  xRead() {
    const v = id => this.el.querySelector('#' + id);
    CROSS.color = v('xc').value;
    CROSS.thick = +v('xt').value;
    CROSS.len = +v('xl').value;
    CROSS.gap = +v('xg').value;
    CROSS.dotS = +v('xs').value;
    CROSS.alpha = +v('xa').value;
    CROSS.lines = v('xn').checked;
    CROSS.dot = v('xd').checked;
    CROSS.out = v('xo').checked;
    Cross.init();
    ['xt', 'xl', 'xg', 'xs'].forEach(id => (v(id + 'V').textContent = v(id).value));
    v('xaV').textContent = v('xa').value + '%';
    this.xPreview();
    CFG2.save();
  },

  /* liga os eventos (uma vez) */
  bind() {
    const e = this.el,
      $ = id => e.querySelector('#' + id),
      num = (id, key, txt) => {
        $(id).oninput = () => {
          SETX[key] = +$(id).value;
          $(id + 'V').textContent = txt ? txt(SETX[key]) : SETX[key];
          this.apply();
          CFG2.save();
        };
      },
      chk = (id, key, inv) => {
        $(id).onchange = () => {
          SETX[key] = $(id).checked ? 1 : 0;
          this.apply();
          CFG2.save();
        };
      };
    e.querySelector('.stT').onclick = ev => {
      const b = ev.target.closest('button');
      if (b) this.go(+b.dataset.t);
    };
    num('sens', 'sens', v => v.toFixed(1));
    num('fov', 'fov');
    num('vol', 'vol', v => v + '%');
    chk('inv', 'inv');
    chk('adr', 'adr');
    chk('fpsOn', 'fps');
    $('shd').onchange = () => {
      SETX.shadow = $('shd').checked ? 1 : 0;
      setQuality(quality);
      CFG2.save();
    };
    $('pQ').onclick = ev => {
      const b = ev.target.closest('button');
      if (!b) return;
      SETX.quality = +b.dataset.q;
      setQuality(SETX.quality);
      CFG2.save();
    };
    $('fpsl').onchange = ev => {
      setFps(ev.target.value);
      CFG2.save();
    };
    /* mira */
    ['xc', 'xt', 'xl', 'xg', 'xs', 'xa', 'xn', 'xd', 'xo'].forEach(id => {
      $(id).oninput = () => this.xRead();
      $(id).onchange = () => this.xRead();
    });
    $('xsw').onclick = ev => {
      const i = ev.target.closest('i');
      if (!i) return;
      $('xc').value = i.dataset.c;
      this.xRead();
    };
    $('xbg').onclick = ev => {
      const b = ev.target.closest('button');
      if (!b) return;
      this.bg = +b.dataset.b;
      this.xPreview();
    };
    $('xpv').onclick = () => {
      /* simula um tiro: a mira abre e fecha */
      const c = $('xpc');
      c.style.setProperty('--g', CROSS.gap + 8 + 'px');
      setTimeout(() => c.style.setProperty('--g', CROSS.gap + 'px'), 110);
    };
    $('xsl').onclick = ev => {
      const sv = ev.target.closest('[data-sv]'),
        us = ev.target.closest('[data-u]');
      if (sv) {
        this.xs[+sv.dataset.sv] = Object.assign({}, CROSS);
        this.xRender();
        CFG2.save();
        toast('Mira salva na vaga ' + (+sv.dataset.sv + 1));
      } else if (us && this.xs[+us.dataset.u]) {
        this.xUse(this.xs[+us.dataset.u]);
        toast('Mira da vaga ' + (+us.dataset.u + 1) + ' em uso');
      }
    };
    $('xpre').onclick = ev => {
      const c = ev.target.closest('[data-pr]');
      if (!c) return;
      this.xUse(XPRE[+c.dataset.pr].c);
      toast('Mira: ' + XPRE[+c.dataset.pr].n);
    };
    /* controles */
    $('kb').onclick = ev => {
      const b = ev.target.closest('button');
      if (!b) return;
      KB.cap = b.dataset.a;
      KB.render();
    };
    $('kbReset').onclick = () => {
      KB.b = Object.assign({}, KB_DEF);
      KB.rebuild();
      KB.cap = null;
      KB.render();
      CFG2.save();
    };
  },

  init() {
    this.build();
    this.bind();
    this.apply();
    this.sync();
    this.go(0);
    Cross.init();
  }
};
/* mira "de fábrica": as miras prontas completam o que faltar com isto */
const CROSS_BASE = {
  color: '#ffffff',
  thick: 2,
  len: 9,
  gap: 3,
  dot: true,
  lines: true,
  out: true,
  alpha: 100,
  dotS: 2
};
