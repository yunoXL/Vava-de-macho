/* ========= SPIKE (bomba): atacante segura [4] numa zona de plantio · defensor segura [4] perto dela para desarmar ========= */
const BOMB = {
  plant: 4,
  defuse: 7,
  half: 3.5,
  fuse: 45,
  reach: 2.6,
  boom: 30 /* raio da explosão (era 16 m) */
}; /* segundos / metros */
const Bomb = {
  pl: null,
  t: 0,
  prog: 0,
  dp: 0,
  half: 0,
  act: 0,
  g: null,
  led: null,
  bt: 0,
  lt: 0,
  tc: 0,
  hs: '',
  cs: 'x',
  zone() {
    const x = pos.x / S,
      y = pos.z / S;
    return inPoly(x, y, LAYOUT.plantA) ? 'A' : inPoly(x, y, LAYOUT.plantB) ? 'B' : '';
  },
  still() {
    return (
      Math.hypot(vel.x, vel.z) < 1 &&
      Mv.h <= (Mv.G || 0) + 0.02 &&
      !Mv.ghost &&
      !Abil.ae &&
      !Abil.aim
    );
  },
  ui(t, f, c) {
    c = c || '';
    const k = t + '|' + (f == null ? '' : Math.round(f * 60)) + c;
    if (k === this.hs) return;
    this.hs = k;
    const e = $$('bomb');
    if (!t) {
      e.style.display = 'none';
      return;
    }
    e.style.display = 'flex';
    e.className = c;
    $$('bmT').textContent = t;
    $$('bmB').style.display = f == null ? 'none' : 'block';
    $$('bmF').style.width = ((f || 0) * 100).toFixed(1) + '%';
  },
  reset() {
    if (this.g) {
      scene.remove(this.g);
      this.g = null;
    }
    this.led = null;
    this.pl = null;
    this.t = 0;
    this.prog = 0;
    this.dp = 0;
    this.half = 0;
    this.act = 0;
    this.bt = 0;
    this.lt = 0;
    this.tc = 0;
    this.cs = 'x';
    this.ui('');
    $$('spk').classList.remove('on');
  },
  stop() {
    this.act = 0;
    this.prog = 0;
    this.ui('');
  },
  plant(site, rem, x, z, y) {
    if (this.pl || Round.over) return;
    const px = rem ? x : pos.x,
      pz = rem ? z : pos.z,
      gy = rem ? y || 0 : Mv.G || 0;
    this.pl = { x: px, z: pz, site, v: new THREE.Vector3(px, gy + 0.3, pz) };
    this.t = BOMB.fuse;
    this.prog = 0;
    this.dp = 0;
    this.half = 0;
    this.act = 0;
    this.bt = 0;
    this.lt = 0;
    this.tc = 0;
    const g = new THREE.Group(),
      dk = new THREE.MeshStandardMaterial({ color: 0x1b1f26, roughness: 0.45, metalness: 0.7 }),
      rd = new THREE.MeshStandardMaterial({
        color: 0x6a0f16,
        emissive: 0xff2233,
        emissiveIntensity: 0.8,
        roughness: 0.4
      }),
      c = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.5), dk),
      bd = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.26, 0.5, 8), dk),
      r = new THREE.Mesh(new THREE.TorusGeometry(0.23, 0.03, 6, 16), rd),
      led = new THREE.Mesh(
        new THREE.SphereGeometry(0.07, 8, 6),
        new THREE.MeshBasicMaterial({ color: 0xff3344 })
      );
    c.position.y = 0.06;
    bd.position.y = 0.3;
    r.rotation.x = Math.PI / 2;
    r.position.y = 0.45;
    led.position.y = 0.62;
    led.visible = false;
    g.add(c, bd, r, led);
    g.position.set(px, gy, pz);
    scene.add(g);
    this.g = g;
    this.led = led;
    Sfx.bomb('plant');
    banner('SPIKE PLANTADA · SITE ' + site, 2600);
    Round.k = '';
    Round.show();
    this.ui('');
    if (!rem) {
      Net.send({ t: 'bp', x: px, z: pz, s: site, y: gy });
      Econ.add(300);
      Abil.addUlt(1); /* plantar a spike dá 1 ponto de ultimate */
    }
  },
  beep(dt) {
    this.bt -= dt;
    if (this.lt > 0) {
      this.lt -= dt;
      if (this.led && this.lt <= 0) this.led.visible = false;
    }
    if (this.bt > 0) return;
    const t = this.t;
    this.bt = t > 20 ? 1 : t > 10 ? 0.65 : t > 5 ? 0.4 : t > 2 ? 0.22 : 0.11;
    this.lt = 0.08;
    if (this.led) this.led.visible = true;
    Sfx.beep(this.pl.v);
  },
  done() {
    if (!this.pl || Round.over) return;
    Sfx.bomb('defuse');
    if (Game.side === 'def') {
      Net.send({ t: 'bd' });
      Abil.addUlt(1); /* desarmar a spike dá 1 ponto de ultimate */
    }
    Round.finish(Game.side === 'def', 'SPIKE DESARMADA', 2600);
  },
  boom() {
    const p = this.pl;
    Round.finish(Game.side === 'atk', 'SPIKE DETONADA', 2800);
    Sfx.bomb('boom');
    const m = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 14), bm(0xffa040, 0.85));
    m.position.set(p.x, 0.8, p.z);
    Abil.add(m, 1.1, e => {
      const k = e.t / 1.1;
      e.m.scale.setScalar(0.5 + k * BOMB.boom);
      e.m.material.opacity = 0.85 * (1 - k);
    });
    if (this.g) this.g.visible = false;
    const d = Math.hypot(pos.x - p.x, pos.z - p.z);
    if (d < BOMB.boom) {
      Abil.rc = null;
      Hp.v = 0;
      Hud.hp(0);
      Hud.hurt(90);
    } else if (d < BOMB.boom * 1.6) {
      Abil.fl = 0.8;
      Abil.fr = 1.1;
    }
  },
  update(dt) {
    if (Training.on || Menu.on) return;
    const key = keyLab(KB.b.bomb),
      live =
        Round.phase === 'live' && !Round.over && !Round.done && Hp.v > 0 && !Shop.on && !Pause.on,
      hk = !!keys['4'];
    const car = Game.side === 'atk' && !this.pl && Hp.v > 0,
      cs = car ? 'on' + key : '';
    if (cs !== this.cs) {
      this.cs = cs;
      const e = $$('spk');
      e.textContent = car ? '◆ SPIKE · SEGURE [' + key + '] NA ZONA' : '';
      e.classList.toggle('on', car);
    }
    if (this.pl) {
      if (!Round.over) {
        this.t -= dt;
        this.beep(dt);
        if (this.t <= 0) {
          this.boom();
          return;
        }
      }
      if (live && Game.side === 'def') {
        const near = Math.hypot(pos.x - this.pl.x, pos.z - this.pl.z) < BOMB.reach;
        if (hk && near && this.still()) {
          this.act = 2;
          this.dp += dt;
          if (this.dp >= BOMB.half) this.half = 1;
          if ((this.tc -= dt) <= 0) {
            this.tc = 0.5;
            Sfx.bomb('tick');
          }
          if (this.dp >= BOMB.defuse) {
            this.done();
            return;
          }
          this.ui('DESARMANDO…', this.dp / BOMB.defuse, 'df');
        } else {
          if (this.act === 2) this.dp = this.half ? BOMB.half : 0;
          this.act = 0;
          this.ui(
            near ? 'SEGURE [' + key + '] PARA DESARMAR' + (this.half ? ' · CHECKPOINT' : '') : ''
          );
        }
      } else {
        this.act = 0;
        if (Round.over || Game.side !== 'def') this.ui('');
      }
      return;
    }
    if (Game.side !== 'atk' || !live) {
      this.act = 0;
      this.prog = 0;
      this.ui('');
      return;
    }
    const z = this.zone();
    if (!z) {
      this.act = 0;
      this.prog = 0;
      this.ui('');
      return;
    }
    if (hk && this.still()) {
      this.act = 1;
      this.prog += dt;
      if ((this.tc -= dt) <= 0) {
        this.tc = 0.5;
        Sfx.bomb('tick');
      }
      if (this.prog >= BOMB.plant) {
        this.act = 0;
        this.plant(z);
        return;
      }
      this.ui('PLANTANDO… SITE ' + z, this.prog / BOMB.plant);
    } else {
      this.act = 0;
      this.prog = 0;
      this.ui('SEGURE [' + key + '] PARA PLANTAR · SITE ' + z);
    }
  }
};
