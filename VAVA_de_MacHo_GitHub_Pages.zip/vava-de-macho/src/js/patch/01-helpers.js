const V3 = THREE.Vector3,
  $ = id => document.getElementById(id),
  sm = t => t * t * (3 - 2 * t),
  rnd = Math.random;
const bm2 = (c, o, add) =>
  new THREE.MeshBasicMaterial({
    color: c,
    transparent: true,
    opacity: o,
    depthWrite: false,
    side: THREE.DoubleSide,
    blending: add ? THREE.AdditiveBlending : THREE.NormalBlending
  });
const PG = new THREE.SphereGeometry(1, 6, 5);
const css = document.createElement('style');
css.textContent =
  '#smkIn{position:fixed;inset:0;pointer-events:none;opacity:0;transition:none;z-index:8;background-image:radial-gradient(circle at 30% 40%,rgba(255,255,255,.35),transparent 45%),radial-gradient(circle at 72% 62%,rgba(0,0,0,.28),transparent 50%),radial-gradient(circle at 55% 20%,rgba(255,255,255,.2),transparent 40%);background-size:180% 180%;animation:smkMv 7s ease-in-out infinite alternate}@keyframes smkMv{to{background-position:100% 80%}}#dthfx{position:fixed;inset:0;pointer-events:none;opacity:0;z-index:7;background:radial-gradient(ellipse at center,rgba(0,0,0,0) 15%,rgba(110,0,12,.9) 100%)}#spd{position:fixed;inset:0;pointer-events:none;opacity:0;z-index:7;background:radial-gradient(circle at 50% 50%,transparent 55%,rgba(255,255,255,.28) 100%)}';
document.head.appendChild(css);
for (const id of ['smkIn', 'dthfx', 'spd']) {
  const d = document.createElement('div');
  d.id = id;
  document.body.appendChild(d);
}
