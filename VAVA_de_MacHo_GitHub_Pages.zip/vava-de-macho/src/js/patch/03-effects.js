/* ---------- EFEITOS ---------- */
const Fx = { shake: 0, dead: 0, dt: 0, l: performance.now(), H: null, sv: null };
window.Fx99 = Fx;
function puff(n, col, o, sp, up, life, size, add, g) {
  const near = o.distanceTo(camera.position) < 4;
  add = add && !near;
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(
      PG,
      bm2(Array.isArray(col) ? col[(rnd() * col.length) | 0] : col, near ? 0.5 : 0.9, add)
    );
    m.position.copy(o);
    const v = new V3((rnd() - 0.5) * sp, up * (0.3 + rnd()), (rnd() - 0.5) * sp),
      sz = size * (0.5 + rnd());
    Abil.add(m, life * (0.6 + rnd() * 0.6), (e, dt) => {
      v.y -= (g || 0) * dt;
      e.m.position.addScaledVector(v, dt);
      const k = e.t / e.dur;
      e.m.scale.setScalar(sz * (1 - k * 0.6));
      e.m.material.opacity = (near ? 0.5 : 0.9) * (1 - k);
    });
  }
}
function ring(x, z, col, R, dur, y) {
  const m = new THREE.Mesh(new THREE.RingGeometry(0.85, 1, 36), bm2(col, 0.5, 0));
  m.rotation.x = -Math.PI / 2;
  m.position.set(x, y || 0.08, z);
  Abil.add(m, dur, e => {
    const k = e.t / dur;
    e.m.scale.setScalar(0.3 + R * (1 - Math.pow(1 - k, 2)));
    e.m.material.opacity = 0.5 * (1 - k);
  });
}
const TH = {
  phoenix: [[0xff7a2f, 0xffc040, 0xff3a10], 1, 1.5, 0.55, 0.09],
  neon: [[0xa678ff, 0x4fe0ff, 0xd9c6ff], 2.2, 0, 0.22, 0.05],
  jett: [[0xdfe8f0, 0x9ed8ff, 0xffffff], 1.2, 0.2, 0.4, 0.07],
  omen: [[0x6a2fb0, 0x2a1f45, 0x8b5cf6], 0.9, 1, 0.8, 0.12],
  yoru: [[0x4fe0ff, 0x4fa8ff, 0xffffff], 1.6, 0.4, 0.35, 0.06]
};
function theme(o, id, n) {
  const t = TH[id] || TH.phoenix;
  puff(n, t[0], o, t[1], t[2], t[3], t[4], 1);
  if (id === 'neon' && rnd() < 0.5)
    Abil.beam(o, o.clone().add(new V3(rnd() - 0.5, rnd() - 0.5, rnd() - 0.5).multiplyScalar(1.3)));
}
const hw = () => camera.localToWorld(new V3(0.22, -0.22, -0.65));
function hideVM(h) {
  if (Weapon.vm && h && !(Abil.kn > 0 || Abil.lg)) Weapon.vm.visible = false;
}
function showVM() {
  if (Weapon.vm && !(Abil.kn > 0 || Abil.lg) && !Fx.H && !Fx.sv && !Fx.dead)
    Weapon.vm.visible = true;
}

/* habilidades: gesto da mão + partículas do agente + som */
Fx.cast = function (a) {
  Sfx.abil(a);
  const id = Game.agent || 'phoenix',
    col = (TH[id] || TH.phoenix)[0][0];
  if (this.H) camera.remove(this.H.p);
  const P = new THREE.Group(),
    h = mkHand('r', 1);
  h.position.set(0, -0.11, 0.09);
  P.add(h);
  P.scale.setScalar(0.5);
  P.position.set(0.2, -0.4, -0.4);
  camera.add(P);
  const orb = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), bm2(col, 0.9, 0));
  orb.position.set(0, 0.02, -0.1);
  P.add(orb);
  this.H = { p: P, orb, t: 0, d: a.t === 'wall' ? 0.75 : 0.6, k: a.t, id, col, rl: 0 };
};
Fx.hand = function (dt) {
  const H = this.H;
  if (!H) return;
  H.t += dt;
  const k = Math.min(1, H.t / H.d),
    e = H.k;
  let x = 0.2,
    y = -0.18,
    z = -0.4,
    rx = 0,
    rz = 0;
  hideVM(1);
  if (e === 'proj' || e === 'point' || e === 'decoy' || e === 'gate') {
    const w = sm(Math.min(1, k / 0.4)),
      t = sm(Math.max(0, Math.min(1, (k - 0.4) / 0.25)));
    y += 0.1 * w;
    z += 0.12 * w - 0.4 * t;
    rx = 0.9 * w - 1.5 * t;
    H.orb.visible = k < 0.5;
    if (k < 0.5) theme(hw(), H.id, 1);
    if (!H.rl && k >= 0.5) {
      H.rl = 1;
      theme(hw(), H.id, 5);
    }
  } else if (e === 'wall') {
    const w = sm(k);
    x += -0.25 + 0.6 * w;
    z -= 0.15;
    rz = -0.9 + 1.5 * w;
    rx = -0.4;
    if (k > 0.2 && k < 0.85) theme(hw(), H.id, 2);
  } else if (e === 'jump') {
    y -= 0.3 * Math.sin(k * Math.PI);
    rx = 0.9 * Math.sin(k * Math.PI);
    if (!H.rl) {
      H.rl = 1;
      ring(pos.x, pos.z, H.col, 3.5, 0.5);
      theme(new V3(pos.x, 0.2, pos.z), H.id, 6);
    }
  } else if (e === 'dash') {
    z += 0.2 * Math.sin(k * Math.PI);
    rz = 0.5 * Math.sin(k * Math.PI);
    if (!H.rl) {
      H.rl = 1;
      this.shake = Math.max(this.shake, 0.25);
      const s = $('spd');
      s.animate && s.animate([{ opacity: 0.5 }, { opacity: 0 }], { duration: 300 });
    }
  } else {
    const w = sm(Math.min(1, k / 0.35));
    x = 0.2 * (1 - w);
    y = -0.18 + 0.08 * w;
    z = -0.4 - 0.12 * w;
    rx = -0.3 * w;
    H.orb.scale.setScalar(1 + w * 1.5 + 0.2 * Math.sin(H.t * 20));
    if (k < 0.7) theme(hw(), H.id, 1);
  }
  y -=
    0.5 * sm(Math.max(0, (k - 0.8) / 0.2)) +
    0.5 * (1 - sm(Math.min(1, k / 0.15))) * (k < 0.15 ? 1 : 0);
  H.p.position.set(x, y, z);
  H.p.rotation.set(rx, 0, rz);
  if (k >= 1) {
    camera.remove(H.p);
    this.H = null;
    showVM();
  }
};
{
  const oc = Abil.cast;
  Abil.cast = function (i) {
    const a = this.ab && this.ab[i],
      s = this.st && this.st[i];
    if (!a || !s) return oc.call(this, i);
    const cd = s.cd,
      nn = s.n,
      uu = s.u,
      ul = this.ult,
      ae = this.ae,
      aim = this.aim,
      kn = this.kn,
      nb = this.nb && this.nb.on,
      pe = s.pend,
      mk = s.mk;
    oc.call(this, i);
    const ok = a.ult ? this.ult < ul : a.chg ? s.n < nn : a.rr ? s.u < uu : s.cd > cd;
    if (
      ok ||
      (this.aim && !aim) ||
      (this.ae && !ae) ||
      this.kn > kn ||
      (this.nb && this.nb.on !== nb) ||
      (s.pend && !pe) ||
      (mk && !s.mk && a.t === 'gate')
    )
      Fx.cast(a);
  };
}
/* paredes: chamas e raios saindo da parede */
Fx.walls = function (dt) {
  if (!Abil.e) return;
  for (const e of Abil.e) {
    if (!e.W || e.L < 1 || e.m.material.opacity < 0.3) continue;
    const c = e.m.material.color,
      fire = c.r > c.b,
      s = rnd() * e.L,
      H = e.m.geometry.parameters.height;
    const p = new V3(e.o.x + e.h.x * s, 0.15, e.o.z + e.h.z * s);
    if (fire) {
      if (rnd() < dt * 40) puff(1, [0xff7a2f, 0xffc040, 0xff3a10], p, 0.5, 2.6, 0.8, 0.16, 1);
    } else if (rnd() < dt * 5)
      Abil.beam(
        p,
        p.clone().add(new V3((rnd() - 0.5) * 0.8, H * (0.5 + rnd() * 0.5), (rnd() - 0.5) * 0.8))
      );
  }
};
/* smoke: volume opaco, textura em movimento, sem ver através (dentro nem fora) */
let ST = null;
function stex() {
  if (ST) return ST;
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const x = c.getContext('2d');
  x.fillStyle = '#b4b4b4';
  x.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 150; i++) {
    const px = rnd() * 256,
      py = rnd() * 256,
      r = 16 + rnd() * 48,
      v = (110 + rnd() * 145) | 0,
      g = x.createRadialGradient(px, py, 0, px, py, r);
    g.addColorStop(0, 'rgba(' + v + ',' + v + ',' + v + ',.55)');
    g.addColorStop(1, 'rgba(' + v + ',' + v + ',' + v + ',0)');
    x.fillStyle = g;
    x.fillRect(px - r, py - r, r * 2, r * 2);
  }
  return (ST = new THREE.CanvasTexture(c));
}
Abil.smoke = function (a, p) {
  Sfx.smoke(p);
  const c = a.h,
    tx = stex().clone();
  tx.needsUpdate = true;
  tx.wrapS = tx.wrapT = THREE.RepeatWrapping;
  tx.repeat.set(2.5, 1.6);
  const mt = new THREE.MeshBasicMaterial({
      color: a.col,
      map: tx,
      transparent: false,
      opacity: 1,
      side: THREE.DoubleSide,
      depthWrite: true
    }),
    m = new THREE.Mesh(
      c ? new THREE.CylinderGeometry(1, 1, a.h, 32, 1, true) : new THREE.SphereGeometry(1, 32, 22),
      mt
    );
  m.renderOrder = 20;
  let tr = false; /* casca oca: opaca dos dois lados, meio vazio */
  m.position.set(p.x, c ? a.h / 2 : Math.max(p.y, a.r * 0.6), p.z);
  m.userData.sm = a.col;
  m.userData.h = c ? a.h : 0;
  puff(14, a.col, new V3(p.x, 0.3, p.z), 7, 0.6, 1, 0.6);
  this.add(m, a.dur, e => {
    const g = Math.min(1, e.t / (c ? 0.8 : 0.5)),
      f = Math.min(1, (e.dur - e.t) / (c ? 3 : 0.7)),
      sy = c ? (0.3 + 0.7 * g) * (0.4 + 0.6 * f) : 0.2 + g * a.r,
      sx = 0.2 + g * a.r;
    e.m.scale.set(sx, sy, sx);
    if (f < 1 && !tr) {
      tr = true;
      mt.transparent = true;
      mt.needsUpdate = true;
    }
    mt.opacity = Math.min(1, f * (c ? 1.4 : 1));
    mt.map.offset.set(e.t * 0.05, e.t * 0.03);
    if (c) e.m.position.y = (a.h * sy) / 2;
  });
};
Fx.blocked = function (a, b) {
  const ab = b.clone().sub(a);
  for (const e of Abil.e) {
    const u = e.m.userData;
    if (!u || u.sm === undefined || e.m.material.opacity < 0.6) continue;
    const c = e.m.position,
      R = e.m.scale.x * 0.98,
      top = u.h ? c.y + (u.h * e.m.scale.y) / 2 : 0;
    const ins = q =>
        u.h ? Math.hypot(q.x - c.x, q.z - c.z) < R && q.y < top : q.distanceTo(c) < R,
      ia = ins(a),
      ib = ins(b);
    if (ia && ib) continue;
    if (ia !== ib)
      return 1; /* os dois dentro da mesma bola: se veem; um dentro e outro fora: casca bloqueia */
    if (u.h) {
      const ax = a.x - c.x,
        az = a.z - c.z,
        L2 = ab.x * ab.x + ab.z * ab.z || 1e-6,
        t = Math.max(0, Math.min(1, -(ax * ab.x + az * ab.z) / L2));
      if (Math.hypot(ax + ab.x * t, az + ab.z * t) < R && a.y + ab.y * t < top) return 1;
    } else {
      const t = Math.max(0, Math.min(1, c.clone().sub(a).dot(ab) / (ab.lengthSq() || 1e-6)));
      if (a.clone().addScaledVector(ab, t).distanceTo(c) < R) return 1;
    }
  }
  return 0;
};
