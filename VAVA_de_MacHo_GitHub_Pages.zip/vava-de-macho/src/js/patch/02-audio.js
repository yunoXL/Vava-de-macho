/* ---------- ÁUDIO ---------- */
Object.assign(Sfx, {
  SW(o, wet, type, f0, f1, q, g, du, dl, rate) {
    const A = this.ac,
      t = A.currentTime + (dl || 0),
      s = A.createBufferSource(),
      fl = A.createBiquadFilter(),
      gn = A.createGain();
    s.buffer = this.nb;
    s.loop = true;
    s.playbackRate.value = rate || 1;
    fl.type = type;
    fl.Q.value = q;
    fl.frequency.setValueAtTime(f0, t);
    fl.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + du);
    gn.gain.setValueAtTime(0.0008, t);
    gn.gain.exponentialRampToValueAtTime(g, t + Math.min(0.03, du * 0.2));
    gn.gain.exponentialRampToValueAtTime(0.0008, t + du);
    s.connect(fl);
    fl.connect(gn);
    gn.connect(o);
    this.W(gn, wet);
    s.start(t, rnd() * 0.4);
    s.stop(t + du + 0.05);
  },
  Z(o, wet, type, f0, f1, g, du, dl) {
    const A = this.ac,
      t = A.currentTime + (dl || 0),
      s = A.createOscillator(),
      gn = A.createGain();
    s.type = type;
    s.frequency.setValueAtTime(f0, t);
    s.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + du);
    gn.gain.setValueAtTime(g, t);
    gn.gain.exponentialRampToValueAtTime(0.0008, t + du);
    s.connect(gn);
    gn.connect(o);
    this.W(gn, wet);
    s.start(t);
    s.stop(t + du + 0.03);
  },
  shot(id, p) {
    if (!this.ok()) return;
    const o = this.out(p, 130);
    if (!o) return;
    if (id === 'knife') {
      this.SW(o, 0.05, 'bandpass', 2000, 6500, 1.4, 0.22, 0.17);
      this.N(o, 0, 'highpass', 6000, 0.7, 0.08, 0.06, 0.05);
      return;
    }
    const P = this.SH[id] || this.SH.classic,
      r = 0.94 + rnd() * 0.12;
    this.N(o, P.w * 0.6, 'highpass', P.c * 1.2, 0.8, P.g * 0.7, 0.03, 0, r * 1.6); /* estalo */
    this.SW(o, P.w, 'bandpass', P.c, P.l * 0.35, 0.9, P.g * 0.9, P.d * 1.1, 0, r); /* corpo */
    this.SW(
      o,
      P.w + 0.2,
      'lowpass',
      P.l * 0.5,
      150,
      0.7,
      P.g * 0.7,
      P.d * 1.8,
      0,
      r * 0.7
    ); /* cauda com reverb */
    this.T(o, P.w * 0.5, P.t[0] * r * 1.2, P.t[1] * 0.6, P.g * 1.1, P.d * 1.2); /* soco grave */
    this.Z(o, 0, 'sine', P.t[0] * 0.5, 28, P.g * 0.8, P.d * 2); /* sub */
    this.N(o, P.w + 0.2, 'lowpass', 900, 0.5, P.g * 0.22, P.d * 4, 0.03, r * 0.6); /* eco do mapa */
    if (P.m && !p) {
      this.click(o, 0.6, 2000, 0.35);
      this.click(o, 0.78, 1300, 0.4);
    }
  },
  hit(h) {
    if (!this.ok()) return;
    this.T(this.bus, 0.05, h ? 2600 : 1700, h ? 2100 : 1300, h ? 0.3 : 0.22, h ? 0.16 : 0.08);
    if (h) {
      this.T(this.bus, 0.1, 3400, 3000, 0.2, 0.22);
      this.N(this.bus, 0, 'highpass', 6000, 0.7, 0.15, 0.04);
    } else this.N(this.bus, 0, 'lowpass', 700, 0.6, 0.25, 0.08);
  },
  bomb(k) {
    if (!this.ok()) return;
    const o = this.bus;
    if (k === 'boom') {
      this.Z(o, 0.5, 'sine', 110, 14, 2.2, 2.8);
      this.Z(o, 0.3, 'sine', 60, 12, 1.8, 3.4);
      this.SW(o, 0.7, 'lowpass', 3000, 70, 0.7, 2.4, 2.8);
      this.N(o, 0.3, 'highpass', 3000, 0.6, 0.9, 0.5);
      this.SW(o, 0.8, 'bandpass', 900, 110, 0.6, 1.2, 3.6, 0.15);
      for (let i = 0; i < 16; i++)
        this.N(o, 0.25, 'bandpass', 1500 + rnd() * 3500, 3, 0.2, 0.07, 0.5 + rnd() * 2.4);
    } else if (k === 'plant') {
      for (let i = 0; i < 4; i++) this.click(o, i * 0.16, 1400 + i * 260, 0.4);
      this.N(o, 0.2, 'bandpass', 2400, 5, 0.35, 0.05, 0.7);
      this.Z(o, 0.2, 'triangle', 200, 900, 0.18, 0.7);
      this.T(o, 0.2, 90, 40, 0.7, 0.3, 0.72);
      this.click(o, 0.72, 3200, 0.4);
    } else if (k === 'defuse') {
      this.Z(o, 0.3, 'sine', 700, 1500, 0.25, 0.5);
      this.click(o, 0, 2200, 0.35);
      this.click(o, 0.1, 1600, 0.35);
      this.T(o, 0.3, 1800, 1800, 0.12, 0.7, 0.3);
    } else if (k === 'tick') this.click(o, 0, 2400, 0.12);
  },
  beep(p) {
    if (!this.ok()) return;
    const o = this.out(p, 90);
    if (!o) return;
    this.T(o, 0.18, 1750, 1700, 0.24, 0.12);
    this.T(o, 0.08, 3500, 3400, 0.09, 0.07);
    this.N(o, 0.1, 'bandpass', 4200, 6, 0.05, 0.03);
  },
  death() {
    if (!this.ok()) return;
    const o = this.bus;
    this.T(o, 0.2, 130, 38, 0.8, 0.55);
    this.SW(o, 0.3, 'lowpass', 1800, 100, 0.8, 0.7, 0.7);
    this.N(o, 0.5, 'bandpass', 520, 1, 0.3, 0.3, 0.12);
    this.T(o, 0.4, 70, 38, 0.35, 0.22, 0.5);
    this.T(o, 0.4, 70, 38, 0.25, 0.22, 0.72);
    this.T(o, 0.5, 3100, 3000, 0.05, 1.8);
  },
  mantle() {
    if (!this.ok()) return;
    this.SW(this.bus, 0.05, 'bandpass', 500, 1600, 1, 0.3, 0.2);
    this.N(this.bus, 0, 'lowpass', 500, 0.6, 0.3, 0.1, 0.15);
  },
  thud(p) {
    if (!this.ok()) return;
    const o = this.out(p, 60);
    if (!o) return;
    this.T(o, 0.1, 100, 40, 0.7, 0.2);
    this.N(o, 0.1, 'lowpass', 500, 0.6, 0.4, 0.15);
  },
  smoke(p) {
    if (!this.ok()) return;
    const o = this.out(p, 90);
    if (!o) return;
    this.N(o, 0.3, 'highpass', 3500, 0.7, 0.8, 0.15);
    this.SW(o, 0.3, 'bandpass', 5000, 1200, 0.7, 0.7, 2);
    this.T(o, 0.2, 160, 60, 0.4, 0.3);
  },
  abil(a) {
    if (!this.ok()) return;
    const o = this.bus,
      k = a.t;
    if (k === 'wall') {
      if (a.flame) {
        this.SW(o, 0.3, 'lowpass', 2200, 300, 0.8, 0.9, 1.4);
        for (let i = 0; i < 8; i++)
          this.N(o, 0.1, 'bandpass', 900 + rnd() * 2000, 2, 0.2, 0.05, 0.1 + i * 0.12);
        this.T(o, 0.2, 120, 50, 0.5, 0.5);
      } else {
        this.Z(o, 0.3, 'sawtooth', 90, 420, 0.2, 0.8);
        this.SW(o, 0.3, 'bandpass', 1500, 5000, 2, 0.5, 0.7);
        for (let i = 0; i < 6; i++) this.N(o, 0.2, 'highpass', 4000, 0.8, 0.25, 0.03, i * 0.1);
      }
    } else if (k === 'proj' || k === 'point') {
      this.SW(o, 0.1, 'bandpass', 500, 2600, 1.2, 0.5, 0.35);
      this.T(o, 0.1, 300, 700, 0.2, 0.2);
    } else if (k === 'jump') {
      this.SW(o, 0.2, 'highpass', 700, 6000, 0.9, 0.7, 0.45);
      this.T(o, 0.1, 80, 200, 0.4, 0.3);
    } else if (k === 'dash') {
      this.SW(o, 0.2, 'bandpass', 3000, 800, 1, 0.8, 0.35);
    } else if (k === 'buff' || k === 'bar') {
      this.Z(o, 0.3, 'sawtooth', 120, 900, 0.2, 0.5);
      this.N(o, 0.2, 'highpass', 5000, 0.8, 0.3, 0.12);
    } else if (k === 'knives') {
      this.click(o, 0, 3000, 0.3);
      this.SW(o, 0.1, 'highpass', 4000, 9000, 0.8, 0.5, 0.3);
    } else {
      this.Z(o, 0.5, 'sine', 160, 60, 0.5, 1);
      this.SW(o, 0.5, 'lowpass', 300, 2500, 0.7, 0.4, 0.8);
    }
  }
});

/* passo simples: batida abafada (ruído filtrado, sem tons) + baque grave curto; o piso só muda o corte do filtro e o "tick" */
const SD = {
  stone: [1100, 0.12],
  marble: [1800, 0.2],
  tile: [1900, 0.2],
  brick: [900, 0.08],
  grass: [480, 0, 1],
  metal: [1500, 0.22],
  iron: [1600, 0.26]
};
Sfx.step = function (s, v, p) {
  if (!this.ok()) return;
  const o = this.out(p);
  if (!o) return;
  const D = SD[s] || SD.stone,
    vv = (v || 1) * (0.85 + rnd() * 0.3),
    r = 0.93 + rnd() * 0.14,
    ft = (this.fs = !this.fs) ? 0.94 : 1.06;
  const hit = (dl, k) => {
    const F = D[0] * r * ft * (k < 1 ? 1.25 : 1);
    this.N(o, 0.01, 'lowpass', F, 0.4, 0.5 * vv * k, 0.045, dl, r); /* batida */
    this.N(o, 0, 'lowpass', F * 0.35, 0.4, 0.45 * vv * k, 0.07, dl, r * 0.8); /* corpo */
    this.T(o, 0, 75 * r * ft, 45, 0.32 * vv * k, 0.06, dl); /* baque grave */
    if (D[1])
      this.N(o, 0, 'highpass', 3200, 0.5, D[1] * vv * k, 0.01, dl); /* estalo do piso duro */
    if (D[2]) this.N(o, 0.01, 'highpass', 2500, 0.5, 0.06 * vv * k, 0.1, dl + 0.01);
  }; /* folhas/grama */
  hit(0, 1);
  hit(0.06, 0.4);
};
