/* ---------- MÚSICA DE TENSÃO: últimos 10 s da spike ---------- */
const Mus = { on: 0, nodes: [], g: null, next: 0, step: 0 };
Mus.osc = function (type, f0, f1, t, du, g, lp) {
  const A = Sfx.ac,
    o = A.createOscillator(),
    fl = A.createBiquadFilter(),
    gn = A.createGain();
  o.type = type;
  o.frequency.setValueAtTime(f0, t);
  if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + du);
  fl.type = 'lowpass';
  fl.frequency.value = lp;
  gn.gain.setValueAtTime(0.0008, t);
  gn.gain.exponentialRampToValueAtTime(g, t + 0.008);
  gn.gain.exponentialRampToValueAtTime(0.0008, t + du);
  o.connect(fl);
  fl.connect(gn);
  gn.connect(this.g);
  o.start(t);
  o.stop(t + du + 0.05);
};
Mus.noise = function (t, du, g, type, f, q) {
  const A = Sfx.ac,
    s = A.createBufferSource(),
    fl = A.createBiquadFilter(),
    gn = A.createGain();
  s.buffer = Sfx.nb;
  s.loop = true;
  fl.type = type;
  fl.frequency.value = f;
  fl.Q.value = q;
  gn.gain.setValueAtTime(g, t);
  gn.gain.exponentialRampToValueAtTime(0.0008, t + du);
  s.connect(fl);
  fl.connect(gn);
  gn.connect(this.g);
  s.start(t, rnd() * 0.5);
  s.stop(t + du + 0.05);
};
Mus.start = function (rem) {
  const A = Sfx.ac,
    T = A.currentTime,
    p0 = 1 - rem / 10;
  this.on = 1;
  this.step = 0;
  this.next = T + 0.05;
  this.nodes = [];
  const g = (this.g = A.createGain());
  g.gain.setValueAtTime(0.0008, T);
  g.gain.exponentialRampToValueAtTime(0.7, T + 0.4);
  g.connect(Sfx.bus);
  const s = A.createBufferSource(),
    f = A.createBiquadFilter(),
    gn = A.createGain();
  s.buffer = Sfx.nb;
  s.loop = true;
  f.type = 'bandpass';
  f.Q.value = 2.5;
  f.frequency.setValueAtTime(300 * Math.pow(23, p0), T);
  f.frequency.exponentialRampToValueAtTime(7000, T + rem);
  gn.gain.setValueAtTime(0.04 + 0.3 * p0, T);
  gn.gain.linearRampToValueAtTime(0.4, T + rem);
  s.connect(f);
  f.connect(gn);
  gn.connect(g);
  s.start(T);
  this.nodes.push(s); /* riser */
  for (const m of [1, 1.5, 2.003]) {
    const o = A.createOscillator(),
      lf = A.createBiquadFilter(),
      og = A.createGain();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(55 * m * (1 + 0.12 * p0), T);
    o.frequency.linearRampToValueAtTime(55 * m * 1.12, T + rem);
    lf.type = 'lowpass';
    lf.frequency.value = 500;
    og.gain.setValueAtTime(0.05, T);
    og.gain.linearRampToValueAtTime(0.12, T + rem);
    o.connect(lf);
    lf.connect(og);
    og.connect(g);
    o.start(T);
    this.nodes.push(o);
  }
}; /* drone que sobe */
Mus.hit = function (t, s, p) {
  const n = [41.2, 41.2, 41.2, 49, 41.2, 41.2, 55, 49],
    b = n[(s >> 1) % 8];
  if (s % 4 === 0) {
    this.osc('sine', 160, 42, t, 0.2, 1.1, 400);
    this.noise(t, 0.02, 0.25, 'highpass', 4000, 0.7);
  }
  if (s % 2 === 1 || s % 4 === 2) this.osc('sawtooth', b, b, t, 0.12, 0.5, 250 + p * 1100);
  if (s % 8 === 4 && p > 0.1) this.noise(t, 0.14, 0.35 + 0.2 * p, 'bandpass', 1900, 0.8);
  if (p > 0.35 && s % 2 === 0) {
    const a = [329.6, 392, 493.9, 587.3, 493.9, 392][(s >> 1) % 6];
    this.osc('triangle', a, a, t, 0.14, 0.05 + 0.1 * p, 3000);
  }
  if (p > 0.6) this.noise(t, 0.03, 0.07 + 0.06 * p, 'highpass', 7500, 0.7);
  if (s % 16 === 0) {
    const a = 1760 * (1 + p * 0.2);
    this.osc('sawtooth', a, a * 1.01, t, 0.9, 0.02 + 0.03 * p, 2500);
  }
};
Mus.tick = function (rem) {
  const A = Sfx.ac,
    p = Math.min(1, Math.max(0, 1 - rem / 10)),
    d = 60 / (124 + p * 36) / 4;
  while (this.next < A.currentTime + 0.25) {
    this.hit(this.next, this.step++, p);
    this.next += d;
  }
};
Mus.stop = function () {
  if (!this.on) return;
  this.on = 0;
  const T = Sfx.ac.currentTime;
  try {
    this.g.gain.cancelScheduledValues(T);
    this.g.gain.setValueAtTime(Math.max(0.001, this.g.gain.value), T);
    this.g.gain.exponentialRampToValueAtTime(0.0008, T + 0.25);
  } catch (e) {}
  for (const n of this.nodes)
    try {
      n.stop(T + 0.3);
    } catch (e) {}
  this.nodes = [];
};
Mus.update = function () {
  const live =
    Sfx.ok() &&
    Bomb.pl &&
    !Round.over &&
    Bomb.t > 0 &&
    Bomb.t <= 10 &&
    !Menu.on &&
    !Pause.on &&
    !Training.on;
  if (live) {
    if (!this.on) this.start(Bomb.t);
    this.tick(Bomb.t);
  } else this.stop();
};
{
  const u3 = updateCamera;
  updateCamera = function () {
    u3();
    Mus.update();
  };
}
