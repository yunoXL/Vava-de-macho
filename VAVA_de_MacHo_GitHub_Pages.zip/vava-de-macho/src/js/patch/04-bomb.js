/* ---------- BOMBA: plantar, desarmar, explodir ---------- */
function mkSpike() {
  const g = new THREE.Group(),
    dk = new THREE.MeshStandardMaterial({ color: 0x1b1f26, roughness: 0.45, metalness: 0.7 }),
    rd = new THREE.MeshStandardMaterial({
      color: 0x6a0f16,
      emissive: 0xff2233,
      emissiveIntensity: 0.8
    }),
    led = new THREE.Mesh(
      new THREE.SphereGeometry(0.07, 8, 6),
      new THREE.MeshBasicMaterial({ color: 0xff3344 })
    );
  const c = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.5), dk),
    b = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.26, 0.5, 8), dk),
    r = new THREE.Mesh(new THREE.TorusGeometry(0.23, 0.03, 6, 16), rd);
  c.position.y = 0.06;
  b.position.y = 0.3;
  r.rotation.x = Math.PI / 2;
  r.position.y = 0.45;
  led.position.y = 0.62;
  g.add(c, b, r, led);
  g.userData.led = led;
  return g;
}
Fx.spk = function (dt) {
  const act = Bomb.act && Hp.v > 0 && !Menu.on;
  if (!act) {
    if (this.sv) {
      camera.remove(this.sv.g);
      this.sv = null;
      showVM();
    }
    return;
  }
  if (!this.sv) {
    const g = new THREE.Group(),
      sp = mkSpike(),
      h = mkHand('r', 1);
    sp.scale.setScalar(0.5);
    h.position.set(0.18, -0.16, 0.25);
    g.add(sp, h);
    camera.add(g);
    this.sv = { g, sp, h, t: 0, m: Bomb.act };
  }
  const S = this.sv;
  S.t += dt;
  hideVM(1);
  if (Weapon.vm) Weapon.vm.visible = false;
  const pl = Bomb.act === 1,
    p = Math.min(1, pl ? Bomb.prog / BOMB.plant : Bomb.dp / BOMB.defuse),
    w = sm(Math.max(0, (p - 0.12) / 0.88)),
    a = sm(Math.min(1, S.t / 0.25));
  if (pl) {
    S.g.position.set(
      0.12 + Math.sin(S.t * 38) * 0.004 * p,
      -0.7 + 0.45 * a - 0.5 * w,
      -0.5 - 0.1 * w
    );
    S.g.rotation.x = -0.5 * w;
    camera.position.y -= 0.5 * sm(Math.min(1, p * 3));
  } else {
    S.g.position.set(Math.sin(S.t * 22) * 0.01, -0.75 + 0.2 * a, -0.55);
    S.g.rotation.x = -0.4;
    S.g.rotation.z = Math.sin(S.t * 14) * 0.05;
    S.h.position.set(0.18 + Math.sin(S.t * 18) * 0.04, -0.16, 0.25 + Math.cos(S.t * 18) * 0.03);
    if (rnd() < dt * 8)
      puff(
        1,
        [0x52ffa3, 0xffffff],
        camera.localToWorld(new V3(0, -0.5, -0.7)),
        0.6,
        1,
        0.3,
        0.04,
        1
      );
  }
  S.sp.userData.led.visible = Math.sin(S.t * (8 + 22 * p)) > 0;
  S.sp.userData.led.material.color.setHex(pl ? 0xff3344 : 0x52ffa3);
};
{
  const op = Bomb.plant;
  Bomb.plant = function (site, rem, x, z, y) {
    const had = this.pl;
    op.call(this, site, rem, x, z, y);
    if (had || !this.pl || !this.g) return;
    const g = this.g,
      y0 = g.position.y,
      px = this.pl.x,
      pz = this.pl.z;
    Abil.add(new THREE.Group(), 0.8, e => {
      const k = e.t / 0.8;
      g.position.y = y0 + 0.6 * Math.pow(1 - k, 2) * Math.abs(Math.cos(k * Math.PI * 2.5));
    });
    ring(px, pz, 0xff3344, 3.2, 0.9);
    puff(12, [0x8a7a66, 0x6a5e50], new V3(px, 0.2, pz), 3, 0.8, 0.8, 0.3);
    Fx.shake = Math.max(Fx.shake, 0.15);
  };
}
Fx.explode = function (x, z, R) {
  const o = new THREE.Vector3(x, 1, z),
    mk = (geo, mat, y) => {
      const m = new THREE.Mesh(geo, mat);
      m.position.set(x, y == null ? 1 : y, z);
      return m;
    };
  const flash = mk(new THREE.SphereGeometry(1, 20, 14), bm2(0xffffff, 1, 1));
  Abil.add(flash, 0.3, e => {
    const k = e.t / 0.3;
    e.m.scale.setScalar(0.5 + R * 0.6 * k);
    e.m.material.opacity = 1 - k;
  });
  const fire = mk(new THREE.SphereGeometry(1, 24, 16), bm2(0xff7a1a, 0.9, 1));
  Abil.add(fire, 0.7, e => {
    const k = e.t / 0.7;
    e.m.scale.setScalar(0.5 + R * (1 - Math.pow(1 - k, 3)));
    e.m.material.opacity = 0.9 * (1 - k * k);
  });
  ring(x, z, 0xffc070, R * 2.1, 0.9, 0.1);
  ring(x, z, 0xff5a1a, R * 1.4, 0.7, 0.2);
  const rg = new THREE.BoxGeometry(0.14, 0.14, 1);
  for (let i = 0; i < 54; i++) {
    const d = new V3(rnd() - 0.5, rnd() * 0.7, rnd() - 0.5).normalize(),
      m = new THREE.Mesh(rg, bm2(i % 2 ? 0xffd070 : 0xff6a20, 1, 1)),
      L = R * (0.7 + rnd() * 0.7);
    m.position.copy(o);
    m.lookAt(o.clone().add(d));
    Abil.add(m, 0.55, e => {
      const k = e.t / 0.55,
        r = 1 - Math.pow(1 - k, 3);
      e.m.scale.z = Math.max(0.01, L * 0.5 * Math.sin(Math.min(1, k * 1.6) * Math.PI * 0.9));
      e.m.position.copy(o).addScaledVector(d, L * r);
      e.m.material.opacity = 1 - k;
    });
  }
  puff(46, [0x3a2a20, 0x6a4a30, 0xff8a30], o, 26, 9, 1.6, 0.25, 0, 20);
  const ball = mk(
      new THREE.SphereGeometry(1, 32, 24),
      new THREE.MeshBasicMaterial({
        color: 0x000000,
        transparent: true,
        opacity: 0.98,
        depthWrite: true
      }),
      R * 0.3
    ),
    R2 = R * 0.9;
  ball.renderOrder = 30;
  const rim = mk(
    new THREE.SphereGeometry(1, 28, 20),
    new THREE.MeshBasicMaterial({
      color: 0xff5a1a,
      transparent: true,
      opacity: 0.5,
      side: THREE.BackSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    }),
    R * 0.3
  );
  Abil.add(ball, 5, e => {
    const g = Math.min(1, e.t / 0.9),
      f = Math.min(1, (5 - e.t) / 1.2),
      s = R2 * (1 - Math.pow(1 - g, 3)) * (0.4 + 0.6 * f) + 0.1;
    e.m.scale.setScalar(s);
    e.m.material.opacity = 0.98 * Math.min(1, f * 1.4);
  });
  Abil.add(rim, 5, e => {
    const g = Math.min(1, e.t / 0.9),
      f = Math.min(1, (5 - e.t) / 1.2),
      s =
        (R2 * (1 - Math.pow(1 - g, 3)) * (0.4 + 0.6 * f) + 0.1) *
        (1.05 + 0.02 * Math.sin(e.t * 20));
    e.m.scale.setScalar(s);
    e.m.material.opacity = 0.5 * f * (1 - Math.min(1, e.t / 2.5) * 0.7);
  });
  const sc = mk(new THREE.CircleGeometry(R * 0.8, 32), bm2(0x050403, 0.8), 0.05);
  sc.rotation.x = -Math.PI / 2;
  Abil.add(sc, 14, e => {
    e.m.material.opacity = 0.8 * (1 - e.t / 14);
  });
  this.shake = Math.max(
    this.shake,
    Math.max(0.4, 1.6 * (1 - Math.min(1, Math.hypot(pos.x - x, pos.z - z) / (R * 3))))
  );
};
Bomb.boom = function () {
  const p = this.pl,
    R = BOMB.boom;
  Round.finish(Game.side === 'atk', 'SPIKE DETONADA', 2800);
  Sfx.bomb('boom');
  Fx.explode(p.x, p.z, R);
  if (this.g) this.g.visible = false;
  const d = Math.hypot(pos.x - p.x, pos.z - p.z);
  if (d < R) {
    Abil.rc = null;
    Hp.v = 0;
    Hud.hp(0);
    Hud.hurt(90);
  } else if (d < R * 2.2) {
    Abil.fl = 0.8;
    Abil.fr = 1.1;
  }
};
