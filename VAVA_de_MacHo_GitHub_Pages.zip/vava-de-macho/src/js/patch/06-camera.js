/* linha de visão 2D contra as paredes (segs), respeitando altura do topo, portas abertas e barreiras */
function wallBetween(a, bx, by, bz) {
  const dx = bx - a.x,
    dz = bz - a.z;
  for (const s of segs) {
    if (s[4] >= 0 && !barriersActive) continue;
    if (s[5] && !s[5].solid) continue;
    const ex = s[2] - s[0],
      ez = s[3] - s[1],
      den = dx * ez - dz * ex;
    if (Math.abs(den) < 1e-9) continue;
    const t = ((s[0] - a.x) * ez - (s[1] - a.z) * ex) / den,
      u = ((s[0] - a.x) * dz - (s[1] - a.z) * dx) / den;
    if (t < 0 || t > 1 || u < 0 || u > 1) continue;
    const y = a.y + (by - a.y) * t,
      top = s[6] !== undefined ? s[6] : WALL_H;
    if (y < top) return true;
  }
  return false;
}
/* ---------- CÂMERA: morte, tremor, escalada ---------- */
const ca = $('dthfx'),
  sk = $('smkIn');
Fx.cam = function () {
  const now = performance.now(),
    dt = Math.min(0.05, (now - this.l) / 1000);
  this.l = now;
  if (!Menu.on && Hp.v <= 0 && !Abil.rc) {
    if (!this.dead) {
      this.dead = 1;
      this.dt = 0;
      this.sd = rnd() < 0.5 ? -1 : 1;
      Sfx.death();
      hideVM(1);
      if (Weapon.vm) Weapon.vm.visible = false;
      puff(10, [0x8a7a66], new V3(pos.x, 0.2, pos.z), 3, 0.6, 0.7, 0.25);
    }
    this.dt += dt;
    const k = Math.min(1, this.dt / 0.9),
      e = 1 - Math.pow(1 - k, 3);
    camera.position.y = pos.y - (pos.y - 0.3) * e;
    camera.rotation.z = 1.25 * e * this.sd;
    camera.rotation.x = Math.max(-1.45, camera.rotation.x - 0.5 * e);
    camera.position.x += Math.cos(yaw) * 0.25 * e * this.sd;
    camera.position.z -= Math.sin(yaw) * 0.25 * e * this.sd;
    ca.style.opacity = Math.min(1, e * 1.1);
    renderer.domElement.style.filter =
      'grayscale(' + (e * 0.9).toFixed(2) + ') brightness(' + (1 - 0.45 * e).toFixed(2) + ')';
  } else {
    if (this.dead) {
      this.dead = 0;
      camera.rotation.z = 0;
      ca.style.opacity = 0;
      renderer.domElement.style.filter = '';
      if (Weapon.vm) Weapon.vm.visible = true;
    }
    if (Mt.m) {
      camera.rotation.x += Math.sin(Mt.m.k * Math.PI) * 0.07;
      camera.rotation.z = Math.sin(Mt.m.k * Math.PI) * 0.025 * (Mt.m.tx > Mt.m.sx ? 1 : -1);
    }
    if (this.shake > 0.002) {
      const s = this.shake;
      camera.position.x += (rnd() - 0.5) * s * 0.18;
      camera.position.y += (rnd() - 0.5) * s * 0.18;
      camera.rotation.z += (rnd() - 0.5) * s * 0.04;
      camera.rotation.x += (rnd() - 0.5) * s * 0.02;
      this.shake *= Math.exp(-5 * dt);
    } else if (!Mt.m) camera.rotation.z = 0;
    this.spk(dt);
    Mt.hands(dt);
    this.hand(dt);
    this.walls(dt);
  }
  if (Mv.dt > 0 && Mv.ghost <= 0 && rnd() < 0.6)
    puff(
      1,
      Game.agent === 'jett' ? 0xdfe8f0 : 0xa678ff,
      new V3(pos.x, 1, pos.z),
      0.4,
      0,
      0.35,
      0.25,
      1
    );
  const fv = $('fxv');
  sk.style.opacity = 0;
  if (fv && fv.dataset.k === 'sm') fv.style.opacity = 0; /* por dentro enxerga o vazio da casca */
  /* NOME NA CABEÇA: só do MESMO time e sem parede/porta/barreira entre você e ele (inimigos e bots nunca mostram) */
  {
    const av = Net.av,
      nt = av && av.userData.nameTag;
    if (nt) {
      const ally = !!Net.ps && Net.ps === Game.side && !(Net.tg && Net.tg.g);
      nt.visible =
        ally &&
        !Menu.on &&
        av.visible &&
        !wallBetween(camera.position, av.position.x, av.position.y + 2.1, av.position.z);
    }
  }
  const av = Net.av;
  if (av) {
    const u = av.userData;
    if (Net.tg) {
      const b = this.blocked(
        camera.position,
        new V3(av.position.x, av.position.y + 1.2, av.position.z)
      );
      u.smk = b && !Net.tg.g;
      av.visible = !Net.tg.g && !b;
    }
    if (u.die) {
      u.die.t += dt;
      const k = Math.min(1, u.die.t / 0.7);
      av.rotation.order = 'YXZ';
      av.rotation.x = (-Math.PI / 2) * k * k;
      if (k >= 1 && !u.die.g) {
        u.die.g = 1;
        Sfx.thud(av.position);
        puff(8, [0x8a7a66], new V3(av.position.x, 0.2, av.position.z), 2.5, 0.5, 0.6, 0.2);
      }
      if (!Net.dead && u.die.t > 0.5) {
        u.die = null;
        av.rotation.x = 0;
      }
    }
  }
};
{
  const uc = updateCamera;
  updateCamera = function () {
    uc();
    Fx.cam();
  };
}
{
  const nf = Net.fire;
  Net.fire = function (...a) {
    const av = this.av,
      hid = av && av.userData.smk;
    if (hid) av.visible = true;
    try {
      return nf.apply(this, a);
    } finally {
      if (hid) av.visible = false;
    }
  };
}
{
  const r = Net.recv;
  Net.recv = function (m) {
    r.call(this, m);
    if (m.t === 'k' && this.av) this.av.userData.die = { t: 0, g: 0 };
  };
}
