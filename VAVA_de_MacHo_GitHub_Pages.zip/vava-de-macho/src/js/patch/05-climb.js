/* ---------- SUBIR: pulo balístico estilo CS/Valorant (sem animação de puxar) ---------- */
const Mt = { m: null, b: null };
window.Mt99 = Mt;
Mt.hands = function () {};
function cands() {
  const L = [];
  for (const b of BOXES)
    L.push([
      [
        [b[0], b[1]],
        [b[2], b[1]],
        [b[2], b[3]],
        [b[0], b[3]]
      ],
      b[4]
    ]);
  for (const q of POLYS) L.push(q);
  return L;
}
Mt.find = function () {
  const fx = -Math.sin(yaw),
    fz = -Math.cos(yaw),
    ix = (keys.d ? 1 : 0) - (keys.a ? 1 : 0),
    iy = (keys.w ? 1 : 0) - (keys.s ? 1 : 0),
    mx = Math.cos(yaw) * ix + fx * iy,
    mz = -Math.sin(yaw) * ix + fz * iy;
  let best = null,
    bd = 1.3;
  for (const [P, top] of cands()) {
    if (top < Mv.h + 1.15 || top - Mv.h > 4.9 || inPoly(pos.x, pos.z, P)) continue;
    let md = 1e9,
      cx = 0,
      cz = 0;
    for (let i = 0; i < P.length; i++) {
      const a = P[i],
        b = P[(i + 1) % P.length],
        dx = b[0] - a[0],
        dz = b[1] - a[1];
      let t = ((pos.x - a[0]) * dx + (pos.z - a[1]) * dz) / (dx * dx + dz * dz || 1);
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const qx = a[0] + dx * t,
        qz = a[1] + dz * t,
        d = Math.hypot(pos.x - qx, pos.z - qz);
      if (d < md) {
        md = d;
        cx = qx;
        cz = qz;
      }
    }
    if (md >= bd) continue;
    const dx = cx - pos.x,
      dz = cz - pos.z,
      l = Math.hypot(dx, dz) || 1;
    if (Math.max((dx * fx + dz * fz) / l, (dx * mx + dz * mz) / l) < 0.25) continue;
    let gx = 0,
      gz = 0;
    for (const q of P) {
      gx += q[0];
      gz += q[1];
    }
    gx /= P.length;
    gz /= P.length;
    let ux = gx - cx,
      uz = gz - cz;
    const ul = Math.hypot(ux, uz) || 1;
    ux /= ul;
    uz /= ul;
    let tx = cx + ux * 0.55,
      tz = cz + uz * 0.55;
    if (!inPoly(tx, tz, P)) {
      tx = gx;
      tz = gz;
    }
    best = { top, tx, tz };
    bd = md;
  }
  return best;
};
/* subir = só física do pulo: sem impulso extra */
