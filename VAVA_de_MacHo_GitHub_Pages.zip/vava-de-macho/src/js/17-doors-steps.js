const Doors = {
  list: [],
  tint(d) {
    const r = d.hp / 500;
    d.mat.color.setRGB(1, 0.4 + 0.6 * r, 0.4 + 0.6 * r);
  } /* fica avermelhada conforme toma tiros */,
  apply(d) {
    const k = Math.min(1, Math.max(0, d.k));
    d.m.scale.y = Math.max(0.001, 1 - k);
    d.m.position.y = (WALL_H * (1 - k)) / 2;
    d.m.visible = k < 0.98;
    d.solid = k < 0.5;
    const T = Weapon.targets,
      i = T.indexOf(d.m);
    if (k < 0.9 && i < 0) T.push(d.m);
    else if (k >= 0.9 && i >= 0) T.splice(i, 1);
  },
  reset() {
    for (const d of this.list) {
      d.state = 'open';
      d.hp = 500;
      d.k = 1;
      d.tt = 0;
      this.tint(d);
      this.apply(d);
    }
  },
  update(dt) {
    for (const d of this.list) {
      const g = d.state === 'closed' ? 0 : 1,
        sp = (d.state === 'broken' ? 3 : 2.2) * dt;
      d.k += Math.sign(g - d.k) * Math.min(Math.abs(g - d.k), sp);
      this.apply(d);
      d.lamp.visible = d.state === 'closed' && Math.floor(performance.now() / 300) % 2 === 0;
      d.lamp.material.color.setHex(d.hp < 150 ? 0xff3b30 : 0xffc21a);
    }
  },
  toggle(d) {
    if (d.state === 'broken' || performance.now() - d.tt < 700) return;
    d.tt = performance.now();
    d.state = d.state === 'open' ? 'closed' : 'open';
    toast('Porta ' + d.name + (d.state === 'closed' ? ' fechada' : ' aberta'));
  },
  hit(o, dmg) {
    const d = o.userData.door,
      s = o.userData.sw;
    if (d) {
      if (d.state !== 'closed') return;
      d.hp -= dmg;
      if (d.hp <= 0) {
        d.hp = 0;
        d.state = 'broken';
        toast('Porta ' + d.name + ' destruída');
      }
      this.tint(d);
    } else if (s) this.toggle(s);
  }
};
/* passos por superfície (sintetizados com WebAudio): pedra, mármore, grama, grelha de ferro, tijolo, metal (B), azulejo (Mercado) */
const Steps = {
  ac: null,
  nb: null,
  d: 0,
  T: {
    stone: ['bandpass', 1500, 1, 0.16, 0.07, 0],
    marble: ['bandpass', 3200, 2, 0.2, 0.06, 1],
    grass: ['lowpass', 650, 0.7, 0.12, 0.15, 0],
    iron: ['bandpass', 4200, 7, 0.28, 0.09, 0],
    brick: ['lowpass', 1400, 0.8, 0.14, 0.08, 0],
    metal: ['bandpass', 2600, 4, 0.2, 0.07, 0],
    tile: ['bandpass', 5200, 3, 0.22, 0.04, 0]
  },
  surf(px, pz) {
    const x = (px === undefined ? pos.x : px) / S,
      y = (pz === undefined ? pos.z : pz) / S,
      P = LAYOUT.props || {};
    if (P.grates && P.grates.some(g => Math.abs(x - g[0]) < 22 && Math.abs(y - g[1]) < 22))
      return 'iron';
    if (P.grass && inPoly(x, y, P.grass)) return 'grass';
    if (inPoly(x, y, LAYOUT.plantA)) return 'marble';
    if (P.wine && inPoly(x, y, P.wine)) return 'brick';
    if (inPoly(x, y, LAYOUT.plantB)) return 'metal';
    for (const c of LAYOUT.ceilings || []) if (c.snd && inPoly(x, y, c.p)) return c.snd;
    return 'stone';
  },
  play(s, v) {
    Sfx.step(s, v || 1);
  },
  update(dt) {
    if (Mv.h > (Mv.G || 0) + 0.01 || Mv.ghost > 0 || Round.phase === undefined) {
      this.d = 0;
      return;
    }
    if (Mv.quiet) return;
    const sp = Math.hypot(vel.x, vel.z);
    if (sp < 2.2) return;
    this.d += sp * dt;
    if (this.d >= 1.75) {
      this.d = 0;
      this.play(this.surf(), Math.min(1.2, sp / SPEED));
    }
  }
};
