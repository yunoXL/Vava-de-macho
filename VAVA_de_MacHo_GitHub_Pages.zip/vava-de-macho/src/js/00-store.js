/* ========= ARMAZENAMENTO POR CONTA =========
   Tudo que o jogo salva (perfil, configurações, faca) passa por aqui.
   Convidado usa as chaves normais; conta online usa a chave + "@id" e avisa o servidor (Auth) para guardar no banco. */
const Store = {
  KEYS: ['vdh_prof', 'vdh_cfg', 'vdh_knife'] /* o que vai para o banco da conta */,
  ns: '' /* '' = convidado · '@id' = conta */,
  hook: null /* chamado quando algo da conta muda (Auth envia ao servidor) */,
  get(k) {
    try {
      return localStorage.getItem(k + this.ns);
    } catch (_) {
      return null;
    }
  },
  set(k, v) {
    try {
      localStorage.setItem(k + this.ns, v);
    } catch (_) {}
    if (this.ns && this.hook) this.hook();
  }
};
