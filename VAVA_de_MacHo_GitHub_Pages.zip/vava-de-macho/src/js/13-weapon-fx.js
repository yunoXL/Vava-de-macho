const Recoil = {
  p: 0,
  y: 0,
  tp: 0,
  ty: 0,
  last: -9 /* offset visual separado de yaw/pitch (entrada do jogador) */,
  kick(w, n, sf, ads) {
    const r = w.recoil,
      m = (1 + (r.mv - 1) * sf) * (ads ? r.ads : 1);
    this.tp = Math.min(0.35, this.tp + rad(r.v * (1 + r.ramp * Math.min(n - 1, 12)) * m));
    this.ty = Math.max(
      -0.2,
      Math.min(0.2, this.ty + rad(r.h * (Math.sin(n * 1.9) * 0.7 + Math.random() * 0.6 - 0.3) * m))
    );
    this.last = performance.now() / 1000;
  },
  update(dt, w) {
    const T = performance.now() / 1000;
    if (T - this.last > (w.auto ? 1.2 / w.rate : 0.1)) {
      const d = Math.exp(-w.recoil.rec * dt);
      this.tp *= d;
      this.ty *= d;
    }
    const k = 1 - Math.exp(-28 * dt);
    this.p += (this.tp - this.p) * k;
    this.y += (this.ty - this.y) * k;
  },
  zero() {
    this.p = this.y = this.tp = this.ty = 0;
  }
};

/* aplica uma mira (objeto no formato de CROSS) em um elemento .xc / #cross (jogo e prévia usam o mesmo) */
function xApply(e, c, gap) {
  const s = e.style;
  s.setProperty('--c', c.color);
  s.setProperty('--t', c.thick + 'px');
  s.setProperty('--l', c.len + 'px');
  s.setProperty('--ds', (c.dotS || 2) + 'px');
  s.setProperty('--a', (c.alpha === undefined ? 100 : c.alpha) / 100);
  s.setProperty('--ol', c.out === false ? 'none' : '0 0 0 1px rgba(0,0,0,.75)');
  if (gap !== undefined) s.setProperty('--g', gap + 'px');
  e.classList.toggle('nd', !c.dot);
  e.classList.toggle('nl', c.lines === false);
}
/* HTML pronto de uma mira (para prévias e cartões de mira) */
function xHtml(c) {
  return '<div class="xc" data-x="' + encodeURIComponent(JSON.stringify(c)) + '"><i class="u"></i><i class="d"></i><i class="l"></i><i class="r"></i><b></b></div>';
}
/* depois de colocar xHtml na tela, chame isto para pintar as miras */
function xPaint(root) {
  root.querySelectorAll('.xc[data-x]').forEach(e => {
    try {
      const c = JSON.parse(decodeURIComponent(e.dataset.x));
      xApply(e, c, c.gap);
    } catch (_) {}
  });
}
const Cross = {
  g: -1,
  init() {
    xApply($$('cross'), CROSS);
    this.g = -1;
  },
  update(spDeg) {
    /* mesmo valor de abertura usado no raio do disparo */
    const g =
      CROSS.gap + ((Math.tan(rad(spDeg)) / Math.tan(rad(camera.fov / 2))) * innerHeight) / 2;
    if (Math.abs(g - this.g) > 0.25) {
      this.g = g;
      $$('cross').style.setProperty('--g', g.toFixed(1) + 'px');
    }
  }
};

const RAY = new THREE.Raycaster();
RAY.far = 150;
const FX = {
  p: [],
  i: 0,
  init() {
    for (let k = 0; k < 8; k++) {
      const m = new THREE.Mesh(
        new THREE.SphereGeometry(0.07, 6, 6),
        new THREE.MeshBasicMaterial({ color: 0xffd45a, transparent: true })
      );
      m.visible = false;
      m.life = 0;
      scene.add(m);
      this.p.push(m);
    }
  },
  hit(pt) {
    const m = this.p[this.i++ % 8];
    m.position.copy(pt);
    m.life = 0.25;
    m.visible = true;
  },
  update(dt) {
    for (const m of this.p)
      if (m.life > 0) {
        m.life -= dt;
        m.material.opacity = Math.max(0, m.life * 4);
        if (m.life <= 0) m.visible = false;
      }
  }
};

/* traços de tiro estilo CS: um risco fino e brilhante (núcleo claro + halo na cor da arma) que corre do cano até o impacto */
const TRG = new THREE.BoxGeometry(1, 1, 1),
  TR_SPEED = 420;
const Tracer = {
  p: [],
  i: 0,
  init() {
    for (let k = 0; k < 32; k++) {
      const mk = (c, o) =>
          new THREE.Mesh(
            TRG,
            new THREE.MeshBasicMaterial({
              color: c,
              transparent: true,
              opacity: o,
              blending: THREE.AdditiveBlending,
              depthWrite: false
            })
          ),
        g = new THREE.Group(),
        core = mk(0xfff4cc, 1),
        glow = mk(0xffb347, 0.5);
      core.scale.set(0.016, 0.016, 1);
      glow.scale.set(0.07, 0.07, 1);
      g.add(glow, core);
      g.visible = false;
      g.userData = {
        core,
        glow,
        o: new THREE.Vector3(),
        d: new THREE.Vector3(),
        D: 0,
        t: 0,
        tl: 0
      };
      scene.add(g);
      this.p.push(g);
    }
  },
  fire(o, e, id) {
    if (!this.p.length) return;
    const d = e.clone().sub(o),
      D = d.length();
    if (D < 0.4) return;
    const g = this.p[this.i++ % this.p.length],
      u = g.userData,
      c = GP[id] ? GP[id].g : 0xffd27a;
    u.o.copy(o);
    u.d.copy(d).divideScalar(D);
    u.D = D;
    u.t = 0;
    u.v = Math.max(90, Math.min(TR_SPEED, D / 0.07));
    u.tl = Math.min(8, D * 0.6 + 1.5);
    u.glow.material.color.set(c);
    u.core.material.color.set(c).lerp(new THREE.Color(0xffffff), 0.7);
    g.position.copy(o);
    g.lookAt(o.clone().add(u.d));
    g.visible = true;
    this.upd(g, 0);
  },
  upd(g, dt) {
    const u = g.userData;
    u.t += dt;
    const run = u.t * u.v,
      head = Math.min(u.D, run),
      tail = Math.min(head, Math.max(0, run - u.tl));
    if (tail >= u.D - 0.01 && run > u.D) {
      g.visible = false;
      return;
    }
    const len = Math.max(0.15, head - tail);
    g.position.copy(u.o).addScaledVector(u.d, tail + len / 2);
    u.core.scale.z = u.glow.scale.z = len;
    const f = 1 - Math.max(0, (tail / u.D - 0.7) / 0.3);
    u.core.material.opacity = f;
    u.glow.material.opacity = 0.5 * f;
  },
  update(dt) {
    for (const g of this.p) if (g.visible) this.upd(g, dt);
  }
};

/* animações do viewmodel: estado simples e serializável (type,t,seq) — base para replicar em multiplayer via MAP.onAnim / Anim.snapshot() */
const ANIM_Z = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
const KEYS = {
  /* [tempo, px,py,pz, rx,ry,rz, afastar mão esquerda] */
  inspect: [
    [0, 0, 0, 0, 0, 0, 0, 0],
    [0.35, -0.04, 0.05, 0.02, 0.35, 0.55, -0.45, 1],
    [1.1, -0.03, 0.06, 0.03, 0.25, 1.25, -0.95, 1],
    [1.8, 0, 0.05, 0.03, 0.7, -0.7, 0.55, 1],
    [2.4, 0, 0.01, 0, 0.1, 0, 0, 0.4],
    [2.8, 0, 0, 0, 0, 0, 0, 0]
  ],
  inspectK: [
    [0, 0, 0, 0, 0, 0, 0, 0],
    [0.25, -0.02, 0.04, 0.03, -0.22, 0.22, 0, 1],
    [0.8, -0.02, 0.05, 0.04, -0.28, 0.28, -3.14, 1],
    [1.35, -0.02, 0.05, 0.04, -0.28, 0.28, -6.28, 1],
    [1.9, 0, 0, 0, 0, 0, -6.28, 0]
  ],
  equip: [
    [0, 0, -0.4, 0.05, 0.9, 0, 0, 0],
    [0.4, 0, 0, 0, 0, 0, 0, 0]
  ]
};
/* ===== inspecionar FACAS: uma animação única por faca (tecla F) =====
   kf(t,{...}) -> [t, px,py,pz, rx,ry,rz, lh, kx,ky, ha,hb, lin]   (rx/ry = rig inteiro · rz/kx/ky = só a faca · ha/hb = cabos da butterfly · lin=1: trecho sem suavização)
   A Faca Tática mantém a animação original (KEYS.inspectK: giro completo no eixo do cabo). */
const kf = (t, o, lin) => {
  o = o || {};
  return [
    t,
    o.px || 0,
    o.py || 0,
    o.pz || 0,
    o.rx || 0,
    o.ry || 0,
    o.rz || 0,
    o.lh || 0,
    o.kx || 0,
    o.ky || 0,
    o.ha || 0,
    o.hb || 0,
    lin ? 1 : 0
  ];
};
const PI2 = Math.PI * 2;
KEYS.inspect_karambit = [
  kf(0),
  kf(0.25, { px: -0.08, py: 0.06, rx: -0.12, lh: 1 }),
  kf(0.45, {
    px: -0.1,
    py: 0.07,
    rx: -0.12,
    lh: 1,
    kx: -1.2
  }) /* giro no anel: 2 voltas em volta do dedo */,
  kf(1.3, { px: -0.1, py: 0.07, rx: -0.12, lh: 1, kx: -11.4 }, 1),
  kf(1.65, { px: -0.06, py: 0.04, rx: -0.06, lh: 1, kx: -PI2 * 2 }),
  kf(2.2, { kx: -PI2 * 2 })
]; /* termina em -4π = pose neutra (sem desenrolar) */
KEYS.inspect_kukri = [
  kf(0),
  kf(0.4, { py: 0.05, pz: 0.02, rx: -0.3, lh: 1, kx: 1.0 }),
  kf(0.55, { py: 0.06, rx: -0.34, lh: 1, kx: 1.15 }),
  kf(0.68, { py: -0.04, pz: -0.06, rx: 0.14, lh: 1, kx: -0.75 }) /* duas machadadas pesadas */,
  kf(0.85, { py: -0.02, pz: -0.04, rx: 0.1, lh: 1, kx: -0.55 }),
  kf(1.1, { py: 0.05, pz: 0.02, rx: -0.3, lh: 1, kx: 1.0 }),
  kf(1.22, { py: -0.05, pz: -0.07, rx: 0.16, lh: 1, kx: -0.85 }),
  kf(1.4, { py: -0.02, pz: -0.04, rx: 0.1, lh: 1, kx: -0.6 }),
  kf(2.0)
];
KEYS.inspect_kunai = [
  kf(0),
  kf(0.2, { py: 0.02, rx: -0.1, lh: 1 }),
  kf(0.4, {
    py: 0.14,
    pz: 0.02,
    rx: -0.2,
    lh: 1,
    rz: -1.6,
    kx: 0.25
  }) /* arremesso para cima + 2 giros rápidos + pega */,
  kf(0.95, { py: 0.07, rx: -0.1, lh: 1, rz: -10.2, kx: -0.15 }, 1),
  kf(1.2, { py: -0.02, lh: 1, rz: -PI2 * 2 }),
  kf(1.45, { py: 0.01, lh: 0.4, rz: -PI2 * 2 }),
  kf(1.9, { rz: -PI2 * 2 })
];
KEYS.inspect_tanto = [
  kf(0),
  kf(0.35, { px: 0.05, rx: 0.15, ry: -0.45, lh: 1, kx: 0.2 }),
  kf(
    0.6,
    { px: -0.06, rx: 0.2, ry: 0.75, pz: -0.04, lh: 1, kx: -0.35 },
    0
  ) /* corte diagonal + virada da lâmina */,
  kf(0.9, { px: -0.04, rx: 0.12, ry: 0.55, lh: 1, kx: -0.2 }),
  kf(1.15, { rx: 0.05, ry: 0.2, lh: 1 }),
  kf(1.5, { py: 0.03, lh: 1, rz: Math.PI }),
  kf(1.9, { lh: 0.5, rz: PI2 }),
  kf(2.3, { rz: PI2 })
];
KEYS.inspect_butterfly = [
  kf(0),
  kf(0.3, {
    py: 0.03,
    rx: -0.12,
    lh: 1
  }) /* clássica do balisong: fecha os cabos, gira e abre de novo (cabos sempre no mesmo sentido) */,
  kf(0.8, { py: 0.04, rx: -0.14, lh: 1, ha: Math.PI }),
  kf(1.2, { py: 0.04, rx: -0.14, lh: 1, ha: Math.PI, hb: -Math.PI, kx: 0.15 }),
  kf(1.45, { py: 0.05, rx: -0.16, lh: 1, ha: Math.PI, hb: -Math.PI, kx: 0.25 }),
  kf(2.05, { py: 0.03, rx: -0.1, lh: 1, ha: PI2 + 0.14, hb: -PI2 - 0.14, kx: -0.2 }),
  kf(2.3, { py: 0.02, lh: 1, ha: PI2, hb: -PI2, kx: -0.05 }),
  kf(2.5, { ha: PI2, hb: -PI2 }),
  kf(2.8, { ha: PI2, hb: -PI2 })
];
const KPIV = {
  karambit: [0, 0, 0.111],
  kunai: [0, 0, 0.107]
}; /* ponto de giro (anel) em coords da faca, relativo ao centro do cabo */
const Anim = {
  type: '',
  t: 0,
  seq: 0,
  emit(type) {
    window.MAP && MAP.onAnim && MAP.onAnim({ type, weapon: Weapon.cur, seq: this.seq });
  },
  start(type) {
    if (type === 'inspect' && (Weapon.rl > 0 || Weapon.held || Shop.on)) return;
    this.type = type;
    this.t = 0;
    this.seq++;
    this.emit(type);
  },
  stop() {
    this.type = '';
  },
  snapshot() {
    return { weapon: Weapon.cur, type: this.type, t: +this.t.toFixed(2), seq: this.seq };
  },
  pose(dt) {
    if (!this.type) return ANIM_Z;
    this.t += dt;
    const K =
        this.type === 'inspect' && Weapon.w().melee
          ? KEYS['inspect_' + Weapon.cur] || KEYS.inspectK
          : KEYS[this.type],
      e = K[K.length - 1][0];
    if (this.t >= e) {
      this.type = '';
      return ANIM_Z;
    }
    let i = 0;
    while (K[i + 1][0] < this.t) i++;
    const a = K[i],
      b = K[i + 1],
      u = (this.t - a[0]) / (b[0] - a[0]),
      k = b[12] === 1 ? u : u * u * (3 - 2 * u);
    return a.map((v, j) => v + (b[j] - v) * k);
  }
};
/* viewmodel por arma: p=posição na câmera · r=rotação base · s=escala. Faca: grande, inclinada para o centro; armas: mais baixas, levemente giradas para dentro */
const VMB = {
  def: { p: [0.2, -0.2, -0.4], r: [0, 0.045, 0], s: 0.55 },
  classic: { p: [0.19, -0.19, -0.39], r: [0, 0.04, 0], s: 0.62 },
  ghost: { p: [0.19, -0.19, -0.39], r: [0, 0.04, 0], s: 0.62 },
  frenzy: { p: [0.19, -0.19, -0.39], r: [0, 0.04, 0], s: 0.62 },
  sheriff: { p: [0.19, -0.19, -0.39], r: [0, 0.04, 0], s: 0.62 },
  operator: { p: [0.2, -0.2, -0.38], r: [0, 0.03, 0], s: 0.5 },
  shorty: { p: [0.19, -0.19, -0.39], r: [0, 0.04, 0], s: 0.62 },
  bandit: { p: [0.19, -0.19, -0.39], r: [0, 0.04, 0], s: 0.62 },
  bucky: { p: [0.2, -0.2, -0.4], r: [0, 0.04, 0], s: 0.52 },
  judge: { p: [0.2, -0.2, -0.4], r: [0, 0.04, 0], s: 0.54 },
  bulldog: { p: [0.2, -0.2, -0.4], r: [0, 0.045, 0], s: 0.55 },
  guardian: { p: [0.2, -0.2, -0.4], r: [0, 0.04, 0], s: 0.5 },
  marshal: { p: [0.2, -0.2, -0.38], r: [0, 0.03, 0], s: 0.5 },
  outlaw: { p: [0.2, -0.2, -0.38], r: [0, 0.03, 0], s: 0.5 },
  ares: { p: [0.2, -0.21, -0.4], r: [0, 0.04, 0], s: 0.5 },
  odin: { p: [0.2, -0.21, -0.4], r: [0, 0.04, 0], s: 0.46 },
  knife: { p: [0.3, -0.27, -0.5], r: [0.22, 1.12, -0.22], s: 1.05 },
  karambit: { p: [0.3, -0.27, -0.5], r: [0.22, 1.1, -0.22], s: 1.05 },
  kukri: { p: [0.3, -0.27, -0.5], r: [0.22, 1.12, -0.22], s: 0.95 },
  kunai: { p: [0.3, -0.27, -0.5], r: [0.22, 1.12, -0.22], s: 1.1 },
  tanto: { p: [0.3, -0.27, -0.5], r: [0.22, 1.12, -0.22], s: 1.0 },
  butterfly: { p: [0.3, -0.27, -0.5], r: [0.22, 1.12, -0.22], s: 1.0 }
};
const Weapon = {
  cur: 'classic',
  ammo: {},
  held: 0,
  semi: 0,
  cd: 0,
  rl: 0,
  n: 0,
  last: -9,
  bloom: 0,
  ads: 0,
  vm: null,
  vk: 0,
  targets: [],
  w() {
    return WR[this.cur];
  },
  give(id) {
    const w = WR[id];
    this.ammo[id] = { mag: w.mag, res: w.res };
  },
  refill() {
    for (const id in Inv.owned) this.give(id);
  },
  equip(id) {
    if (!Inv.owned[id]) return false;
    if (!this.ammo[id]) this.give(id);
    this.cur = id;
    this.rl = 0;
    this.n = 0;
    this.cd = 0.2;
    this.bloom = 0;
    this.bq = 0;
    if (WR[id].scope) {
      Scope.Z = WR[id].zoom || [2.5, 5]; /* níveis de zoom desta luneta */
      Scope.zi = 0;
    }
    Inv.slots[WR[id].slot] = id;
    this.buildVM();
    Anim.start('equip');
    Sfx.equip(id);
    Hud.weapon();
    return true;
  },
  buildVM() {
    if (this.vm) camera.remove(this.vm);
    const w = this.w(),
      M = GUNP[w.id],
      rig = new THREE.Group();
    this.kspin = null;
    this.kha = this.khb = null;
    this.kpv = KPIV[w.id] ? new THREE.Vector3(...KPIV[w.id]) : null;
    if (w.melee) {
      const kp = new THREE.Group(),
        bf = w.id === 'butterfly',
        kg = bf ? partsToGroup(GUNP.butterfly.bl, gunTab(w.id)) : gunModel(w);
      kp.position.set(0, HY, 0);
      kg.position.set(0, -HY, 0);
      kp.add(kg);
      rig.add(kp);
      this.kspin = kp;
      if (bf) {
        for (const sx of [1, -1]) {
          const h = partsToGroup(GUNP.butterfly.hd(sx), gunTab(w.id));
          h.position.set(0, 0, BFZ);
          kp.add(h);
          if (sx > 0) this.kha = h;
          else this.khb = h;
        }
      }
    } /* butterfly: cabos A/B giram no pino (eixo X) */ else
      rig.add(
        gunModel(w)
      ); /* faca: só ela gira no inspecionar (eixo do cabo), o braço fica parado */

    const rh = mkHand(w.melee ? 'f' : 'r', !w.melee);
    rh.position.set(M.hp[0], M.hp[1], M.hp[2]);
    rig.add(rh);
    this.lh = null;
    this.fl = null;
    this.flt = 0;
    if (M.lh) {
      const lh = mkHand('l');
      lh.position.set(M.lh[0], M.lh[1], M.lh[2]);
      rig.add(lh);
      this.lh = lh;
      this.lhy = lh.position.y;
    }
    if (M.mz) {
      const f = mkFlash();
      f.position.set(M.mz[0], M.mz[1], M.mz[2]);
      rig.add(f);
      this.fl = f;
    } /* clarão do cano */
    const B = (this.vb = VMB[w.id] || VMB.def);
    rig.scale.setScalar(B.s);
    camera.add(rig);
    this.vm = rig;
    if (this.lhm) {
      camera.remove(this.lhm);
      this.lhm = null;
    }
    if (w.melee) {
      const g = new THREE.Group();
      g.add(mkHand('o'));
      g.scale.setScalar(1.15);
      g.position.set(-0.3, -0.3, -0.5);
      g.rotation.set(0.3, -0.75, 0.25);
      camera.add(g);
      this.lhm = g;
    }
  },
  muzzleW() {
    const M = GUNP[this.cur];
    if (!this.vm || !M.mz) return camera.position.clone();
    camera.updateMatrixWorld(true);
    return this.vm.localToWorld(new THREE.Vector3(M.mz[0], M.mz[1], M.mz[2]));
  },
  trig(d) {
    if (d && Shop.on) d = 0;
    this.held = d;
    if (d) this.semi = 0.25;
  },
  reload() {
    const w = this.w(),
      a = this.ammo[this.cur];
    if (this.rl > 0 || a.mag >= w.mag || a.res <= 0) return;
    this.rl = w.rld1 && a.mag > 0 ? w.rld1 : w.rld; /* Outlaw: mais rápida com 1 bala */
    Anim.stop();
    Anim.emit('reload');
    Sfx.reload(w);
    Hud.ammo();
  },
  sf() {
    return Math.min(1, Math.hypot(vel.x, vel.z) / SPEED);
  },
  cast(hs, w) {
    for (const x of hs) {
      const p = x.object.userData.pen;
      if (p === 1 || (p === 2 && w.pen === 'alta')) continue;
      Doors.hit(x.object, w.dmg);
      return x;
    }
    return undefined;
  } /* madeira: todos atravessam · radianite: só penetração alta */,
  spread() {
    const w = this.w(),
      p = Accuracy.mv();
    const hip = w.hip === undefined ? 5 : w.hip,
      tg = w.tight ? 1 - w.tight * Math.min(1, Math.max(0, this.n - 1) / 12) : 1; /* Ares: fecha no tiro contínuo */
    return (
      (w.sp + this.bloom + (w.scope ? (Scope.on ? p * 3 : hip) : 0)) *
      (1 + p * (w.recoil.mv - 1) * 2) *
      Accuracy.stance() *
      (this.ads ? w.recoil.ads : 1) *
      tg
    );
  } /* p = penalidade de movimento (Accuracy): parado 0 · andando ~0,26 · correndo 1 · no ar 2 */,
  update(dt) {
    if (Mv.ghost > 0 || Bomb.act || Hp.v <= 0 || Round.done) {
      this.held = 0;
      this.semi = 0;
    }
    if ((Abil.kn > 0 && Abil.knives(dt)) || (Abil.lg && Abil.lightning(dt))) return;
    const w = this.w(),
      a = this.ammo[this.cur],
      T = performance.now() / 1000;
    this.cd -= dt;
    this.semi -= dt;
    this.bloom *= Math.exp(-w.recoil.rec * 0.5 * dt);
    if (this.rl > 0) {
      this.rl -= dt;
      if (this.rl <= 0) {
        const f = Math.min(w.mag - a.mag, a.res);
        a.mag += f;
        a.res -= f;
        this.rl = 0;
        Hud.ammo();
      }
    } else if (w.melee) {
      if (this.cd <= 0 && (this.held || this.semi > 0)) this.stab(w);
    } else if (this.bq > 0) {
      if (this.cd <= 0) {
        if (a.mag > 0) this.shoot(w, a, T, 1);
        else this.bq = 0;
      } /* rajada do Bulldog: os próximos tiros saem sozinhos */
    } else if (this.cd <= 0 && ((this.held && w.auto) || this.semi > 0)) {
      if (a.mag <= 0) {
        this.semi = 0;
        this.reload();
        if (this.rl <= 0) {
          this.cd = 0.3;
          Sfx.empty();
        }
      } else this.shoot(w, a, T);
    }
    this.vk = Math.max(0, this.vk - dt * 0.6);
    if (this.vm) {
      if (this.fl) {
        this.flt = Math.max(0, this.flt - dt);
        this.fl.visible = this.flt > 0;
        if (this.flt > 0) {
          this.fl.rotation.z = Math.random() * 6.28;
          this.fl.scale.setScalar(0.7 + Math.random() * 0.7);
        }
      }
      const P = Anim.pose(dt);
      const bf = this.sf() * (Mv.air ? 0 : 1);
      this.bt = (this.bt || 0) + dt * (5 + bf * 5);
      const bk = 1 - Math.exp(-14 * dt);
      this.bx = (this.bx || 0) + (Math.sin(this.bt) * 0.012 * bf - (this.bx || 0)) * bk;
      this.by =
        (this.by || 0) +
        (-Math.abs(Math.cos(this.bt)) * 0.014 * bf - (Mv.air ? 0.02 : 0) - (this.by || 0)) * bk;
      const B = this.vb || VMB.def;
      const bpx = w.melee
        ? Math.min(B.p[0], Math.tan(rad(camera.fov * 0.5)) * camera.aspect * Math.abs(B.p[2]) * 0.6)
        : B.p[0]; /* faca: em tela vertical o punho ficava fora da imagem */
      this.vm.position.set(
        bpx + P[1] + this.bx,
        B.p[1] + 0.02 - (this.rl > 0 ? 0.12 : 0) + P[2] + this.by,
        B.p[2] + this.vk + P[3]
      );
      this.vm.rotation.set(B.r[0] + P[4], B.r[1] + P[5], B.r[2] + (this.kspin ? 0 : P[6]));
      if (this.kspin) {
        const ks = this.kspin;
        ks.rotation.set(P[8] || 0, P[9] || 0, P[6]);
        ks.position.set(0, HY, 0);
        if (this.kpv)
          ks.position.add(
            this.kpv.clone().sub(this.kpv.clone().applyEuler(ks.rotation))
          ); /* giro em volta do anel */
        if (this.kha) {
          this.kha.rotation.x = P[10] || 0;
          this.khb.rotation.x = P[11] || 0;
        }
      }
      if (this.lhm) {
        this.lhm.visible = this.vm.visible;
        this.lhm.position.set(
          -0.21 + P[1] * 0.4 + this.bx * 0.8 - P[7] * 0.1,
          -0.25 + P[2] * 0.4 + this.by * 0.8 - P[7] * 0.18 + (this.vk > 0 ? -this.vk * 0.8 : 0),
          -0.43 + this.vk * 0.9 + P[3] * 0.4
        );
      }
      if (this.lh) this.lh.position.y = this.lhy - P[7] * 0.15;
    }
  },
  stab(w) {
    Sfx.shot('knife');
    this.cd = 1 / w.rate;
    this.semi = 0;
    this.vk = 0.18;
    Anim.stop();
    Anim.emit('fire');
    const d = new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
    RAY.set(camera.position, d);
    RAY.far = 2.6;
    const h = RAY.intersectObjects(this.targets, false)[0];
    RAY.far = 150;
    if (h) {
      FX.hit(h.point);
      window.MAP &&
        MAP.onHit &&
        MAP.onHit({ point: h.point, object: h.object, damage: w.dmg * Mv.dmg, weapon: w.id });
    }
    Net.fire(camera.position, d, w.dmg * Mv.dmg, h ? h.distance : 1e9, w.melee ? 2.6 : 150);
  },
  shoot(w, a, T, cont) {
    Scope.kick = 1;
    if (Training.on && !w.melee) {
      Training.st.shots++;
      Training.refresh();
    }
    Sfx.shot(w.id);
    Anim.stop();
    Anim.emit('fire');
    a.mag--;
    /* cadência: mirando (Ares/Odin) ou após 8 tiros seguidos (Odin) pode mudar */
    const rate = this.ads && w.arate ? w.arate : w.spool && this.n >= 8 ? w.spool : w.rate;
    this.cd = 1 / rate;
    this.semi = 0;
    if (w.burst && this.ads) {
      if (cont) this.bq--;
      else this.bq = Math.min(w.burst, a.mag + 1) - 1;
      if (this.bq <= 0) this.cd = Math.max(this.cd, 0.4); /* pausa entre rajadas */
    } else this.bq = 0;
    if (T - this.last > Math.max(0.35, 2 / w.rate)) this.n = 0;
    this.n++;
    this.last = T;
    const np = w.pel || 1,
      mz = this.muzzleW(),
      mvd = Mv.dmg;
    for (let i = 0; i < np; i++) {
      /* cada projétil (shotgun) tem o seu próprio desvio dentro do cone */
      const q = rad(this.spread()) * Math.sqrt(Math.random()),
        th = Math.random() * 6.283;
      const d = new THREE.Vector3(Math.tan(q) * Math.cos(th), Math.tan(q) * Math.sin(th), -1)
        .normalize()
        .applyQuaternion(camera.quaternion);
      RAY.set(camera.position, d);
      const h = this.cast(RAY.intersectObjects(this.targets, false), w);
      let dm = w.dmg * mvd,
        hd = (w.head || w.dmg * 3) * mvd;
      if (h && w.fall) {
        /* shotgun: o dano cai com a distância (até 20%) */
        const f = 1 - 0.8 * Math.min(1, Math.max(0, (h.distance - w.fall[0]) / (w.fall[1] - w.fall[0])));
        dm *= f;
        hd *= f;
      }
      if (h) {
        FX.hit(h.point);
        window.MAP &&
          MAP.onHit &&
          MAP.onHit({ point: h.point, object: h.object, damage: dm, head: hd, weapon: w.id });
      }
      if (i < 6)
        Tracer.fire(
          mz.clone().addScaledVector(d, 0.3),
          h ? h.point.clone() : camera.position.clone().addScaledVector(d, 150),
          w.id
        );
      Net.fire(camera.position, d, dm, h ? h.distance : 1e9, w.melee ? 2.6 : 150, {
        head: hd,
        q: i
      }); /* q>0: o outro lado não repete som/clarão a cada projétil */
    }
    this.flt = 0.05;
    Recoil.kick(w, this.n, this.sf(), this.ads); /* um único kick por disparo */
    this.bloom = Math.min(3, this.bloom + w.recoil.v * 0.5);
    this.vk = 0.05 + w.recoil.v * 0.012;
    Hud.ammo();
  }
};
