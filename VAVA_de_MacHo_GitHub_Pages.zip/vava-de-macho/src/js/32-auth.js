/* ========= LOGIN E CONTA =========
   O login é a PRIMEIRA tela: depois dele vem a tela de carregamento e o menu.
   A conta mora no servidor (server/server.js guarda tudo em server/data/db.json).
   O que é salvo na conta: perfil/estatísticas/skins, configurações (mira, teclas, vídeo…) e a faca.
   Sem servidor no ar dá para entrar como CONVIDADO (salva só neste navegador, como antes). */
const Auth = {
  user: null /* {id, name} da conta atual (null = convidado) */,
  tok: null,
  mode: 'in',
  tm: 0,
  busy: 0,
  cb: null,

  /* endereço da API (mesmo servidor do jogo) */
  base() {
    return (
      (SERVER.secure ? 'https://' : 'http://') +
      SERVER.host +
      (SERVER.secure && !location.port ? '' : ':' + SERVER.port)
    );
  },
  /* chamada à API; erro com .off = servidor não respondeu */
  call(path, method, body, keep) {
    const ctl = new AbortController(),
      t = setTimeout(() => ctl.abort(), 7000),
      h = { 'Content-Type': 'application/json' };
    if (this.tok) h.Authorization = 'Bearer ' + this.tok;
    return fetch(this.base() + path, {
      method: method || 'GET',
      headers: h,
      body: body ? JSON.stringify(body) : undefined,
      signal: ctl.signal,
      keepalive: !!keep
    }).then(
      r =>
        r
          .json()
          .catch(() => ({}))
          .then(j => {
            clearTimeout(t);
            if (!r.ok) {
              const e = new Error(j.error || 'Erro ' + r.status);
              e.status = r.status;
              throw e;
            }
            return j;
          }),
      () => {
        clearTimeout(t);
        const e = new Error('Servidor não encontrado');
        e.off = 1;
        throw e;
      }
    );
  },

  /* sessão guardada neste navegador (para o botão CONTINUAR) */
  saved() {
    try {
      const s = JSON.parse(localStorage.getItem('vdh_sess') || 'null');
      return s && s.tok ? s : null;
    } catch (_) {
      return null;
    }
  },
  forget() {
    try {
      localStorage.removeItem('vdh_sess');
    } catch (_) {}
  },

  msg(t, ok) {
    const m = $$('lMsg');
    m.textContent = t || '';
    m.className = ok ? 'ok' : '';
  },
  srv(t, ok) {
    const s = $$('lSrv');
    s.textContent = t;
    s.className = ok ? 'on' : '';
  },
  setMode(m) {
    this.mode = m;
    [...$$('lTabs').children].forEach(b => b.classList.toggle('on', b.dataset.m === m));
    $$('lPass2').style.display = m === 'up' ? '' : 'none';
    $$('lGo').textContent = m === 'up' ? 'CRIAR CONTA' : 'ENTRAR';
    $$('lPass').autocomplete = m === 'up' ? 'new-password' : 'current-password';
    this.msg('');
  },

  /* envia o formulário (entrar ou criar conta) */
  submit() {
    if (this.busy) return;
    const name = $$('lUser').value.trim(),
      pass = $$('lPass').value;
    if (!/^[A-Za-z0-9_]{3,16}$/.test(name))
      return this.msg('Usuário: 3 a 16 letras, números ou _ (sem espaço)');
    if (pass.length < 6) return this.msg('A senha precisa ter pelo menos 6 caracteres');
    if (this.mode === 'up' && pass !== $$('lPass2').value) return this.msg('As senhas não são iguais');
    this.busy = 1;
    $$('lGo').disabled = true;
    this.msg(this.mode === 'up' ? 'Criando conta…' : 'Entrando…', 1);
    this.tok = null;
    this.call(this.mode === 'up' ? '/api/register' : '/api/login', 'POST', { name, pass })
      .then(j => this.enter(j.user, j.token))
      .catch(e => {
        this.busy = 0;
        $$('lGo').disabled = false;
        this.msg(e.off ? 'Servidor offline. Rode "npm start" ou jogue como convidado.' : e.message);
      });
  },

  /* conta confirmada: baixa os dados da conta e segue para o carregamento */
  enter(user, tok) {
    this.user = user;
    this.tok = tok;
    try {
      localStorage.setItem('vdh_sess', JSON.stringify({ tok, id: user.id, name: user.name }));
    } catch (_) {}
    Store.ns = '@' + user.id;
    this.pull().then(() => {
      Store.hook = () => this.queue();
      this.leave();
    });
  },
  /* sem conta: usa só o armazenamento deste navegador */
  guest() {
    this.user = null;
    this.tok = null;
    Store.ns = '';
    Store.hook = null;
    this.leave();
  },
  /* esconde o login e chama o carregamento */
  leave() {
    const el = $$('login');
    if (el) el.remove();
    this.bindMenu();
    this.cb && this.cb(this.user);
  },

  /* baixa os dados da conta (se este navegador ficou com alteração não enviada, envia a local) */
  pull() {
    let dirty = 0;
    try {
      dirty = localStorage.getItem('vdh_dirty' + Store.ns);
    } catch (_) {}
    if (dirty) return this.push();
    return this.call('/api/data')
      .then(j => {
        const d = (j && j.data) || {};
        Store.KEYS.forEach(k => {
          try {
            if (typeof d[k] === 'string') localStorage.setItem(k + Store.ns, d[k]);
            else localStorage.removeItem(k + Store.ns);
          } catch (_) {}
        });
      })
      .catch(() => {}); /* sem resposta: segue com o que já tem guardado aqui */
  },
  /* manda os dados para o servidor (um pouco depois da última mudança) */
  queue() {
    try {
      localStorage.setItem('vdh_dirty' + Store.ns, '1');
    } catch (_) {}
    clearTimeout(this.tm);
    this.tm = setTimeout(() => this.push(), 1500);
  },
  push(keep) {
    if (!this.user) return Promise.resolve();
    clearTimeout(this.tm);
    const data = {};
    Store.KEYS.forEach(k => {
      const v = Store.get(k);
      if (v !== null) data[k] = v;
    });
    return this.call('/api/data', 'PUT', { data }, keep)
      .then(() => {
        try {
          localStorage.removeItem('vdh_dirty' + Store.ns);
        } catch (_) {}
      })
      .catch(e => {
        if (e.status === 401) return; /* sessão vencida: o próximo login envia */
        this.tm = setTimeout(() => this.push(), 15000); /* tenta de novo */
      });
  },

  /* botão SAIR / ENTRAR do menu */
  bindMenu() {
    const b = $$('mOut');
    b.textContent = this.user ? 'SAIR' : 'ENTRAR';
    b.title = this.user ? 'Sair da conta ' + this.user.name : 'Voltar para o login';
    b.onclick = () => this.logout();
    addEventListener('pagehide', () => {
      if (this.user && this.dirtyNow()) this.push(true);
    });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.user && this.dirtyNow()) this.push(true);
    });
  },
  dirtyNow() {
    try {
      return !!localStorage.getItem('vdh_dirty' + Store.ns);
    } catch (_) {
      return false;
    }
  },
  logout() {
    const go = () => {
      this.forget();
      location.reload();
    };
    if (!this.user) return go();
    this.push().then(() => {
      this.call('/api/logout', 'POST').then(go, go);
    });
  },

  /* monta a tela de login e liga os botões */
  init(cb) {
    this.cb = cb;
    $$('lTabs').onclick = e => {
      const b = e.target.closest('button');
      if (b) this.setMode(b.dataset.m);
    };
    $$('lGo').onclick = () => this.submit();
    ['lUser', 'lPass', 'lPass2'].forEach(
      id =>
        ($$(id).onkeydown = e => {
          if (e.key === 'Enter') this.submit();
        })
    );
    $$('lGuest').onclick = () => this.guest();
    $$('lOther').onclick = () => {
      this.forget();
      this.tok = null;
      $$('lCont').style.display = 'none';
      $$('lForm').style.display = '';
      $$('lUser').focus();
    };
    this.setMode('in');
    /* servidor no ar? e já existe uma conta salva neste navegador? */
    this.srv('PROCURANDO SERVIDOR…');
    const s = this.saved();
    if (s) this.tok = s.tok;
    this.call(s ? '/api/me' : '/status')
      .then(j => {
        this.srv('SERVIDOR ONLINE', 1);
        if (s && j && j.user) {
          $$('lContName').textContent = j.user.name.toUpperCase();
          $$('lCont').style.display = '';
          $$('lForm').style.display = 'none';
          $$('lContBtn').onclick = () => {
            if (this.busy) return;
            this.busy = 1;
            this.enter(j.user, s.tok);
          };
        }
      })
      .catch(e => {
        this.tok = null;
        if (e.off) {
          this.srv('SERVIDOR OFFLINE · entre como convidado ou rode npm start');
        } else {
          this.srv('SERVIDOR ONLINE', 1);
          this.forget(); /* sessão vencida: pede login de novo */
        }
      });
    $$('lUser').focus();
  }
};
