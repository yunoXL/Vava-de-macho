/* ========= LOOP ========= */
let last = performance.now(),
  acc = 0,
  frameCount = 0,
  SHD = 0;
/* ========= CONFIG v0.92: teclas, mira, FPS ilimitado e nome ========= */
const KB_DEF = {
  forward: 'w',
  back: 's',
  left: 'a',
  right: 'd',
  jump: ' ',
  crouch: 'control',
  walk: 'shift',
  reload: 'r',
  shop: 'b',
  map: 'm',
  inspect: 'f',
  fire: 'j',
  ads: 'k',
  slot1: '1',
  slot2: '2',
  slot3: '3',
  ab0: 'c',
  ab1: 'q',
  ab2: 'e',
  ab3: 'x',
  bomb: '4'
};
const KB_NAME = {
  forward: 'ANDAR PARA FRENTE',
  back: 'ANDAR PARA TRÁS',
  left: 'ESQUERDA',
  right: 'DIREITA',
  jump: 'PULAR',
  crouch: 'AGACHAR',
  walk: 'ANDAR DEVAGAR',
  reload: 'RECARREGAR',
  shop: 'LOJA',
  map: 'MAPA',
  inspect: 'INSPECIONAR ARMA',
  fire: 'ATIRAR',
  ads: 'MIRAR',
  slot1: 'PISTOLA',
  slot2: 'ARMA PRINCIPAL',
  slot3: 'FACA',
  ab0: 'HABILIDADE 1',
  ab1: 'HABILIDADE 2',
  ab2: 'HABILIDADE 3',
  ab3: 'ULTIMATE',
  bomb: 'PLANTAR / DESARMAR SPIKE'
};
const FPSU = { cap: 0, free: 0, pend: 0, sa: 0, mc: new MessageChannel() };
FPSU.mc.port1.onmessage = () => {
  FPSU.pend = 0;
  animate(performance.now());
};
const setFps = v => {
  v = +v;
  FPSU.free = v < 0 ? 1 : 0;
  FPSU.cap = v > 0 ? v : 0;
};
function sched() {
  if (FPSU.pend) return;
  FPSU.pend = 1;
  if (FPSU.free && !document.hidden) FPSU.mc.port2.postMessage(0);
  else
    requestAnimationFrame(t => {
      FPSU.pend = 0;
      animate(t);
    });
} /* um único laço por vez: sem duplicar ao trocar o limite */ /* FPS livre: sem esperar o vsync do requestAnimationFrame */
const keyLab = k => (k === ' ' ? 'ESPAÇO' : k === 'control' ? 'CTRL' : k.toUpperCase());
const KB = {
  b: Object.assign({}, KB_DEF),
  rev: {},
  cap: null,
  rebuild() {
    this.rev = {};
    for (const a in this.b) this.rev[this.b[a]] = KB_DEF[a];
  },
  canon(e) {
    const k = e.key.toLowerCase();
    if (k in this.rev) return this.rev[k];
    return Object.values(KB_DEF).includes(k) ? null : k;
  } /* tecla padrão já remapeada não faz mais nada */,
  set(a, k) {
    const o = this.b[a],
      x = Object.keys(this.b).find(z => this.b[z] === k);
    if (x) this.b[x] = o;
    this.b[a] = k;
    this.rebuild();
  },
  render() {
    const el = document.getElementById('kb');
    el.innerHTML = Object.keys(KB_DEF)
      .map(
        a =>
          '<div class="kr"><span>' +
          KB_NAME[a] +
          '</span><button data-a="' +
          a +
          '">' +
          (this.cap === a ? 'PRESSIONE…' : keyLab(this.b[a])) +
          '</button></div>'
      )
      .join('');
    document.querySelectorAll('.ab').forEach((e, i) => {
      const t = e.querySelector('i');
      if (t && this.b['ab' + i] && /^[A-Z0-9]{1,6}$/.test(t.textContent))
        t.textContent = keyLab(this.b['ab' + i]);
    });
  }
};
const CFG2 = {
  load() {
    try {
      return JSON.parse(Store.get('vdh_cfg') || '{}');
    } catch (_) {
      return {};
    }
  },
  save() {
    Store.set(
      'vdh_cfg',
      JSON.stringify({
        kb: KB.b,
        cross: CROSS,
        xs: Settings.xs,
        s: SETX,
        fpsl: String(FPSU.free ? -1 : FPSU.cap),
        name: document.getElementById('mName').value
      })
    );
  }
};
function myName() {
  let code = '#0001';
  try {
    code = Profile.code(); /* código único do perfil */
  } catch (_) {}
  return (
    ((document.getElementById('mName').value || '').replace(/[^\w ÀÁ-ÿ.\-]/g, '').trim() ||
      'JOGADOR') + code
  );
}

/* ===== modo de jogo + escolha de lado (depois do agente, máx. 5 por lado) ===== */
const MAX_SIDE = 5;
let MODE = 'local';
function menuMode() {
  const c = MODE === 'comp';
  $$('mGo').style.display = c ? 'none' : '';
  $$('mMp').style.display = c ? '' : 'none';
  $$('mGo').textContent = MODE === 'treino' ? 'INICIAR TREINO' : 'INICIAR PARTIDA';
}
const SideSel = {
  on: false,
  open(cb) {
    this.on = true;
    this.cb = cb;
    this.upd();
    $$('sideSel').classList.add('on');
  },
  count() {
    const o = Net.ps;
    return { atk: o === 'atk' ? 1 : 0, def: o === 'def' ? 1 : 0 };
  } /* jogadores já na sala por lado */,
  upd() {
    const c = this.count();
    $$('ssA').textContent = c.atk + '/' + MAX_SIDE;
    $$('ssD').textContent = c.def + '/' + MAX_SIDE;
    $$('ssB').children[0].classList.toggle('full', c.atk >= MAX_SIDE);
    $$('ssB').children[1].classList.toggle('full', c.def >= MAX_SIDE);
  },
  pick(s) {
    if (this.count()[s] >= MAX_SIDE) {
      toast('Esse lado está cheio (máx. ' + MAX_SIDE + ')');
      return;
    }
    this.on = false;
    $$('sideSel').classList.remove('on');
    Net.send({ t: 'side', s });
    const cb = this.cb;
    this.cb = null;
    cb && cb(s);
  }
};
function menuInit2() {
  $$('ssB').onclick = e => {
    const b = e.target.closest('button');
    if (b && SideSel.on) SideSel.pick(b.dataset.s);
  };
  document.querySelectorAll('#mMain .mc[data-m]').forEach(
    b =>
      (b.onclick = () => {
        if (Menu.q) return;
        MODE = b.dataset.m;
        document
          .querySelectorAll('#mMain .mc[data-m]')
          .forEach(x => x.classList.toggle('on', x === b));
        menuMode();
      })
  );
  const r = Net.recv.bind(Net);
  Net.recv = m => {
    if (m && m.t === 'side') {
      Net.ps = m.s;
      if (SideSel.on) SideSel.upd();
      return;
    }
    r(m);
  };
  menuMode();
}
function cfgInit() {
  menuInit2();
  const C = CFG2.load(),
    nm = document.getElementById('mName');
  if (C.kb) Object.assign(KB.b, C.kb);
  if (C.cross) Object.assign(CROSS, C.cross);
  if (C.xs) Settings.xs = C.xs;
  if (C.s) Object.assign(SETX, C.s);
  if (C.fpsl !== undefined) setFps(C.fpsl);
  if (Auth.user) {
    nm.value = Auth.user.name; /* conta online: o nome é o da conta */
    nm.readOnly = true;
    nm.title = 'Nome da sua conta';
  } else if (C.name) nm.value = C.name;
  KB.rebuild();
  nm.oninput = () => CFG2.save();
  addEventListener(
    'keydown',
    e => {
      if (!KB.cap) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      if (e.key !== 'Escape' && e.key !== 'Tab') KB.set(KB.cap, e.key.toLowerCase());
      KB.cap = null;
      KB.render();
      CFG2.save();
    },
    true
  );
  Settings.init(); /* monta o painel de configurações (ESC e aba do menu) */
}
/* resolução dinâmica: baixa a escala de render se o FPS cair e sobe de volta quando sobra desempenho */
const AutoRes = {
  bad: 0,
  good: 0,
  need: 6,
  tick(fps) {
    if (!SETX.adr || Menu.on || Pause.on || document.hidden) {
      this.bad = this.good = 0;
      return;
    }
    const tg = FPSU.cap && FPSU.cap < 60 ? FPSU.cap : 60;
    if (fps < tg * 0.8) {
      this.good = 0;
      if (++this.bad >= 2 && pixelRatio > 0.61) {
        this.set(Math.max(0.6, pixelRatio - 0.15));
        this.bad = 0;
        this.need = 15;
      }
    } else if (fps >= tg * 0.97 && pixelRatio < prCap - 0.01) {
      this.bad = 0;
      if (++this.good >= this.need) {
        this.set(Math.min(prCap, pixelRatio + 0.1));
        this.good = 0;
      }
    } else this.bad = this.good = 0;
  },
  set(v) {
    pixelRatio = v;
    handleResize();
  }
};
function animate(now) {
  sched();
  if (FPSU.cap && now - last < 1000 / FPSU.cap - 1.5) return; /* limite de FPS escolhido */
  if ((Menu.on || Pause.on || Round.done) && now - last < 32)
    return; /* menu/pausa: 30 FPS bastam */
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  if (Menu.on) {
    yaw += dt * 0.12;
    pitch = -0.06;
    updateCamera();
  } else if (!Pause.on) {
    FPSU.sa += dt;
    if (FPSU.sa >= 1 / 240) {
      const d = FPSU.sa;
      FPSU.sa = 0;
      updateMovement(d);
      Game.update(d);
    }
    updateCamera();
  } /* simulação em passo mínimo de 1/240 s: física e timers estáveis em FPS altíssimo */
  Scope.update(dt);
  Sfx.update();
  barrierFade = BarrierController.k;
  const t = now / 1000;
  if (now - SHD > 33) {
    SHD = now;
    renderer.shadowMap.needsUpdate = true;
  }
  for (const b of barrierObjs) {
    b.visible = barrierFade > 0.01;
    b.material.uniforms.uTime.value = t;
    b.material.uniforms.uFade.value = barrierFade;
  }
  for (const p of postObjs) {
    p.visible = barrierFade > 0.01;
    p.material.opacity = 0.9 * barrierFade;
  }
  if (Stage.on) Stage.render(dt); /* palco 3D do agente */
  else renderer.render(scene, camera);
  acc += dt;
  frameCount++;
  if (acc >= 1) {
    const fps = Math.round(frameCount / acc);
    document.getElementById('fps').textContent = fps + ' FPS';
    AutoRes.tick(fps);
    acc = 0;
    frameCount = 0;
  }
}
