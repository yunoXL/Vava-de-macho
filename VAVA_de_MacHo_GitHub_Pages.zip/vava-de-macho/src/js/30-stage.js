/* ========= PALCO 3D DO AGENTE (tela de escolha de agente) =========
   Segunda cena só para o palco: fundo escuro, luz de destaque na cor do agente e o boneco parado respirando.
   Ao clicar em um agente, o 3D troca e faz um efeito (giro, anel de luz e zoom de câmera). */
const Stage = {
  on: false,
  sc: null,
  cam: null,
  g: null,
  id: null,
  t: 0,
  kick: 0 /* 1 → 0: tempo do efeito depois do clique */,
  zoom: 4.8,
  /* monta a cena uma vez (luzes, chão, anel) */
  build() {
    const sc = (this.sc = new THREE.Scene());
    sc.background = new THREE.Color(0x07090d);
    sc.fog = new THREE.Fog(0x07090d, 6, 14);
    sc.add(new THREE.HemisphereLight(0x8fa0c0, 0x10131a, 0.55));
    const key = new THREE.DirectionalLight(0xffffff, 0.9);
    key.position.set(2.5, 3.5, 4);
    sc.add(key);
    this.rim = new THREE.PointLight(0xffffff, 2.2, 9);
    this.rim.position.set(-2, 2.2, -2.2);
    sc.add(this.rim);
    this.fill = new THREE.PointLight(0xffffff, 1.2, 7);
    this.fill.position.set(2.2, 0.4, 1.8);
    sc.add(this.fill);
    const floor = new THREE.Mesh(
      new THREE.CircleGeometry(3.2, 48),
      new THREE.MeshStandardMaterial({ color: 0x12161d, roughness: 0.85, metalness: 0.2 })
    );
    floor.rotation.x = -Math.PI / 2;
    sc.add(floor);
    this.ring = new THREE.Mesh(
      new THREE.RingGeometry(0.62, 0.68, 64),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8 })
    );
    this.ring.rotation.x = -Math.PI / 2;
    this.ring.position.y = 0.01;
    sc.add(this.ring);
    this.cam = new THREE.PerspectiveCamera(32, 1, 0.1, 40);
  },
  /* troca o agente mostrado (com a skin escolhida na aba AGENTES) */
  set(id) {
    if (!this.sc) this.build();
    if (this.g) this.sc.remove(this.g);
    this.g = null;
    this.id = id;
    if (!id) return;
    this.g = Skins.run(id, Skins.sel(id), () => mkBody(id, 0, 0, 'classic'));
    this.sc.add(this.g);
    const c = hexc(Skins.colors(id, Skins.sel(id)).a);
    [this.rim, this.fill, this.ring.material].forEach(o => o.color.set(c));
  },
  show(id) {
    this.on = true;
    document.body.classList.add('stage');
    this.set(id);
  },
  hide() {
    this.on = false;
    document.body.classList.remove('stage', 'stagebad');
    this.bad = 0;
  },
  /* efeito ao clicar: giro, anel de luz e zoom */
  react() {
    this.kick = 1;
  },
  /* chamada a cada frame no lugar da cena do jogo; se der erro, mostra fundo escuro (nunca o mapa) */
  render(dt) {
    try {
      this.draw(dt);
    } catch (e) {
      if (!this.bad) console.error('Palco 3D:', e);
      this.bad = 1;
      document.body.classList.add('stagebad');
    }
  },
  draw(dt) {
    if (!this.sc) this.build();
    this.t += dt;
    const k = (this.kick = Math.max(0, this.kick - dt / 1.4)),
      e = k * k * (3 - 2 * k) /* suaviza o efeito */,
      w = renderer.domElement.clientWidth || innerWidth,
      h = renderer.domElement.clientHeight || innerHeight;
    if (this.g) {
      this.g.rotation.y = Math.PI - 0.55 + Math.sin(this.t * 0.6) * 0.08 + e * Math.PI * 2;
      this.g.scale.set(1, 1 + Math.sin(this.t * 1.9) * 0.008, 1); /* respirando */
    }
    this.ring.scale.setScalar(1 + (1 - k) * 0.0 + e * 1.6);
    this.ring.material.opacity = 0.35 + 0.5 * e;
    this.rim.intensity = 2.2 + e * 5;
    this.zoom += ((k > 0 ? 3.8 : 4.8) - this.zoom) * Math.min(1, dt * 5);
    this.cam.aspect = w / h;
    this.cam.updateProjectionMatrix();
    this.cam.position.set(0, 1.15, this.zoom);
    this.cam.lookAt(0, 0.78, 0); /* boneco um pouco acima do centro: os botões ficam embaixo */
    renderer.render(this.sc, this.cam);
  }
};
