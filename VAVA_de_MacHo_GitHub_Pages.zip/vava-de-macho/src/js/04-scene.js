/* ========= CENA ========= */
function initScene() {
  const canvas = document.getElementById('c');
  renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: false,
    powerPreference: 'high-performance'
  });
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.shadowMap.autoUpdate = false;
  renderer.shadowMap.needsUpdate = true; /* sombra atualizada a ~30 Hz (ver animate), não a cada quadro */
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0xd9e4ec);
  scene.fog = new THREE.Fog(0xd9e4ec, FOG_N, FOG_F);
  camera = new THREE.PerspectiveCamera(80, 1, 0.08, 290);
  camera.rotation.order = 'YXZ';
  pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
  prCap = pixelRatio;
  createMaterials();
  createLighting();
  createMapGeometry();
  createControls();
  handleResize();
  resetPlayer('ATTACKER_SPAWN');
  Game.init();
}
function createLighting() {
  scene.add(new THREE.HemisphereLight(0xbfe0ff, 0xc9b48c, 1.0));
  sun = new THREE.DirectionalLight(0xffe3b0, 1.25);
  const cx = (LAYOUT.center ? LAYOUT.center[0] : 1100) * S,
    cz = (LAYOUT.center ? LAYOUT.center[1] : 850) * S;
  sun.position.set(cx - 34, 78, cz + 26);
  sun.target.position.set(cx, 0, cz);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  const sc = sun.shadow.camera;
  sc.left = -86;
  sc.right = 86;
  sc.top = 86;
  sc.bottom = -86;
  sc.near = 5;
  sc.far = 200;
  sun.shadow.bias = -0.0006;
  sun.shadow.normalBias = 0.04;
  scene.add(sun, sun.target);
  const pa = new THREE.PointLight(0xffc27a, 0.8, 28);
  pa.position.set(LAYOUT.sites.A[0] * S, 3.5, LAYOUT.sites.A[1] * S);
  const pb = new THREE.PointLight(0xffc27a, 0.8, 28);
  pb.position.set(LAYOUT.sites.B[0] * S, 3.5, LAYOUT.sites.B[1] * S);
  scene.add(pa, pb);
}
function extrude(shape, h, mat) {
  const g = new THREE.ExtrudeGeometry(shape, { depth: h, bevelEnabled: false });
  g.rotateX(-Math.PI / 2);
  const m = new THREE.Mesh(g, mat);
  m.castShadow = m.receiveShadow = true;
  scene.add(m);
  return m;
}
const BOXES = [],
  POLYS =
    []; /* POLYS: [[x,z]...em metros, topo] objetos sólidos escaláveis */ /* [x1,z1,x2,z2,topo] em metros: caixas escaláveis */
/* floorAt() agora vive no bloco MOVIMENTO E COLISÃO (Terrain.ground) */
function addEdges(pts, bi = -1, top) {
  if (
    (top !== undefined && bi < 0 && pts.length !== 4) ||
    (top !== undefined && bi < 0 && pts.length === 4 && !window.__box)
  )
    POLYS.push([pts.map(p => [p[0] * S, p[1] * S]), top]);
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i],
      b = pts[(i + 1) % pts.length];
    segs.push([a[0] * S, a[1] * S, b[0] * S, b[1] * S, bi, null, top]);
  }
}
