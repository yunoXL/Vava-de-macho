/* ========= INICIALIZAÇÃO DO JOGO (roda por último, depois de todos os módulos) ========= */
$$('meOk').onclick = () => {
  Round.done = 0;
  $$('mEnd').classList.remove('on');
  Menu.show();
};
$$('tRs').onclick = () => Training.resetStats();
$$('tTg').onclick = () => Training.resetTargets();
/* Ordem de abertura: LOGIN → tela de carregamento → jogo.
   O mapa só é gerado depois do login (startGame), escondido atrás da tela de carregamento. */
function startGame() {
  KPick.load(); /* faca escolhida da conta (ou do convidado) */
  initScene();
  Pause.init();
  Menu.init();
  Agents.init();
  ArMenu.init();
  Updates.init();
  Tabs.init();
  Profile.init();
  MapSelect.init(); /* depois de Agents.init: garante que o Enter da seleção de mapa não confirme o agente junto */
  requestAnimationFrame(animate);
  Loader.done(); /* jogo pronto: a tela de carregamento some (após no mínimo 2,5 s) */
  window.MAP = {
    MAP_DATA,
    MapSelect,
    selectMap,
    Hp,
    Abil,
    Agents,
    AGENTS,
    Pause,
    Menu,
    Net,
    SERVER,
    Anim,
    Hud,
    LAYOUT,
    setBarriersActive,
    resetPlayer,
    Round,
    Econ,
    Inv,
    Weapon,
    WeaponRegistry,
    CFG,
    CROSS,
    BarrierController,
    Shop
  };
  MAP.onHit = e => {
    if (Training.on) Training.hit(e);
  }; /* acertos em bots/placas do campo de treino */
}
Auth.init(() => {
  Loader.show(); /* a tela de carregamento aparece e só então o jogo começa a ser montado */
  let go = 0;
  const run = () => {
    if (go) return;
    go = 1;
    startGame();
  };
  requestAnimationFrame(() => setTimeout(run, 30));
  setTimeout(run, 400); /* garantia se a aba estiver em segundo plano */
});
