const Game = {
  side: 'atk',
  init() {
    Weapon.targets = scene.children
      .filter(o => o.isMesh && o.material.isMeshStandardMaterial && !o.material.transparent)
      .concat(EXTRA);
    scene.add(camera);
    FX.init();
    Tracer.init();
    Cross.init();
    Shop.init();
    document.addEventListener('mousedown', e => {
      if (!document.pointerLockElement) return;
      if (Abil.click(e)) return;
      if (e.button === 0) Weapon.trig(1);
      else if (e.button === 2) {
        if (!Abil.slide()) Weapon.ads = 1;
      }
    });
    document.addEventListener('mouseup', e => {
      if (e.button === 0) Weapon.trig(0);
      else if (e.button === 2) Weapon.ads = 0;
    });
    document.addEventListener('contextmenu', e => e.preventDefault());
    addEventListener('keyup', e => {
      const i = 'cqex'.indexOf(e.key.toLowerCase());
      if (i >= 0 && e.key.length === 1) Abil.release(i);
    });
    Weapon.equip('classic');
    Round.start();
  },
  setSide(s) {
    this.side = s;
    Shop.render();
  },
  resetRound() {
    Doors.reset();
    Abil.reset();
    resetPlayer(this.side === 'atk' ? 'ATTACKER_SPAWN' : 'DEFENDER_SPAWN');
    Hp.v = 100;
    Hud.hp(100);
    Weapon.refill();
    Weapon.rl = 0;
    Recoil.zero();
    Hud.weapon();
    Hud.arm();
    Hud.cred();
  },
  slot(s) {
    const id = Inv.slots[s];
    if (!id) return; /* vaga vazia: nada acontece */
    if (s !== 'mel' && Weapon.cur === id) return this.slot('mel'); /* mesma tecla de novo = faca */
    Weapon.equip(id);
    Hud.flash();
    Shop.render();
  },
  key(e) {
    if (Menu.on || Pause.on || Round.done) return;
    const k = e.key.toLowerCase();
    if (k === 'b') Shop.toggle();
    else if (k === 'm') {
      if (!Training.on) Mini.toggle();
    } else if (Training.on && k === 't') Training.resetStats();
    else if (Training.on && k === 'y') Training.resetTargets();
    else if (k === 'r') Weapon.reload();
    else if (k === '1') this.slot('sec');
    else if (k === '2') this.slot('pri');
    else if (k === '3') this.slot('mel');
    else if (k === 'f') Anim.start('inspect');
    else if (k === 'j') {
      if (!e.repeat && !Abil.click({ button: 0 })) Weapon.trig(1);
    } else if (k === 'k') {
      if (!e.repeat && !Abil.slide()) Weapon.ads = 1;
    } else if (!e.repeat && k.length === 1 && 'cqex'.indexOf(k) >= 0) Abil.cast('cqex'.indexOf(k));
  },
  update(dt) {
    BarrierController.update(dt);
    Round.update(dt);
    Weapon.update(dt);
    Abil.update(dt);
    Doors.update(dt);
    Bomb.update(dt);
    Steps.update(dt);
    Net.tick(dt);
    Tracer.update(dt);
    Training.tick(dt);
    Mini.update(dt);
    Board.tick(dt);
    Recoil.update(dt, Weapon.w());
    Cross.update(Weapon.spread());
    FX.update(dt);
  }
};
