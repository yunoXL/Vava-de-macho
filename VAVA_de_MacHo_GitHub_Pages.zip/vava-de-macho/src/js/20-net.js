/* ========= TELA PRINCIPAL + "puxar partida" ========= */
/* servidor: se o HTML for aberto pelo próprio servidor (http://host:porta) usa o mesmo endereço; abrindo o arquivo direto (file://) tenta localhost:3000 */
const SERVER = {
  host: (location.protocol.indexOf('http') === 0 && location.hostname) || 'localhost',
  port: (location.protocol.indexOf('http') === 0 && location.port) || 3000,
  secure: location.protocol === 'https:'
};
const Net = {
  agk: null,
  tag: null,
  AGC: { phoenix: 0xff7a2f, neon: 0x8a5cff, jett: 0x9ed8ff, omen: 0x4a2a7a, yoru: 0x4fa8ff },
  c: null,
  peer: null,
  av: null,
  acc: 0,
  tg: null,
  dead: 0,
  url() {
    return (
      (SERVER.secure ? 'wss://' : 'ws://') +
      SERVER.host +
      (SERVER.secure && !location.port ? '' : ':' + SERVER.port)
    );
  },
  /* SERVIDOR LOCAL: conecta no server/server.js (WebSocket). O servidor casa 2 jogadores por sala e repassa as mensagens.
     Sem servidor no ar → cai para partida offline (como antes). */
  join(o) {
    /* GitHub Pages é estático: não existe WebSocket de matchmaking neste domínio.
       O modo P2P manual (PeerJS) continua disponível em host()/enter(). */
    if (window.VDH_STATIC_HOSTING || location.hostname.endsWith('github.io') || location.hostname.endsWith('githubusercontent.com')) {
      return Promise.reject(new Error('Matchmaking automático ainda não está configurado para esta hospedagem. Use CRIAR SALA X1 / ENTRAR NA SALA ou jogue no modo local.'));
    }
    return new Promise(res => {
      let done = 0,
        ws = null,
        tm = 0;
      const fin = r => {
          if (done) return;
          done = 1;
          clearTimeout(tm);
          res(r);
        },
        off = () => {
          try {
            ws && ws.close();
          } catch (_) {}
          fin({ mode: 'local', ...o });
        };
      tm = setTimeout(off, 2500);
      try {
        ws = new WebSocket(this.url());
      } catch (e) {
        return off();
      }
      ws.onerror = off;
      ws.onclose = () => {
        if (!done) off();
      };
      ws.onmessage = ev => {
        let m;
        try {
          m = JSON.parse(ev.data);
        } catch (_) {
          return;
        }
        if (m && m.t === 'hi' && !done) {
          this.bindWS(ws);
          fin({ mode: 'ws', room: m.room, peer: !!m.peer, ...o });
        }
      };
    });
  },
  bindWS(ws) {
    const h = {},
      c = {
        open: true,
        send(m) {
          if (ws.readyState === 1) ws.send(JSON.stringify(m));
        },
        on(e, f) {
          h[e] = f;
        },
        close() {
          try {
            ws.close();
          } catch (_) {}
        }
      };
    ws.onmessage = ev => {
      let m;
      try {
        m = JSON.parse(ev.data);
      } catch (_) {
        return;
      }
      if (m.t === 'peer') {
        toast('Adversário conectou');
        if (Game.side) Net.send({ t: 'side', s: Game.side });
      } else if (m.t === 'left') {
        toast('Adversário saiu');
        if (this.av) {
          scene.remove(this.av);
          this.av = null;
        }
        this.tg = null;
        this.ps = null;
      } else if (m.t !== 'hi' && h.data) h.data(m);
    };
    ws.onclose = () => {
      c.open = false;
      h.close && h.close();
    };
    ws.onerror = () => {};
    this.ws = ws;
    this.bind(c);
  },
  host(show) {
    return new Promise((res, rej) => {
      const code = Math.random().toString(36).slice(2, 6).toUpperCase();
      this.peer = new Peer('mapafps-' + code);
      this.peer.on('open', () => show(code));
      this.peer.on('error', rej);
      this.peer.on('connection', c => {
        this.bind(c);
        c.on('open', () => res({ mode: 'p2p', side: 'atk' }));
      });
    });
  },
  enter(code, show) {
    return new Promise((res, rej) => {
      this.peer = new Peer();
      this.peer.on('error', rej);
      this.peer.on('open', () => {
        show('CONECTANDO À SALA ' + code.toUpperCase() + '…');
        const c = this.peer.connect('mapafps-' + code.toUpperCase().trim());
        this.bind(c);
        c.on('open', () => res({ mode: 'p2p', side: 'def' }));
      });
    });
  },
  bind(c) {
    this.c = c;
    c.on('data', m => this.recv(m));
    c.on('close', () => {
      if (this.c === c) {
        toast('Seu amigo saiu');
        Menu.show();
      }
    });
  },
  send(m) {
    this.c && this.c.open && this.c.send(m);
  },
  close() {
    if (this.av) {
      scene.remove(this.av);
      this.av = null;
    }
    const p = this.peer,
      w = this.ws;
    this.c = null;
    this.peer = null;
    this.ws = null;
    if (w)
      try {
        w.close();
      } catch (_) {}
    this.tg = null;
    this.agk = null;
    this.skk = 0;
    this.wpk = null;
    this.tag = null;
    this.dead = 0;
    p && p.destroy();
  },
  muzzleP() {
    const a = this.av;
    if (!a || !a.visible || !a.userData.dyn) return null;
    const M = GUNP[a.userData.gid];
    if (!M || !M.mz) return null;
    a.updateMatrixWorld(true);
    return a.localToWorld(
      new THREE.Vector3(
        AV_AT[0] + M.mz[0] * M.as,
        AV_AT[1] + M.mz[1] * M.as,
        AV_AT[2] + M.mz[2] * M.as
      )
    );
  },
  mkAv() {
    const g = SKIN_RUN(this.agk, this.skk | 0, () => mkBody(this.agk || 'phoenix', 0, 1, this.wpk));
    scene.add(g);
    this.av = g;
    return g;
  },
  skin(id) {
    this.agk = id;
    if (this.av) {
      const q = this.av.position.clone(),
        r = this.av.rotation.y,
        v = this.av.visible;
      scene.remove(this.av);
      this.mkAv();
      this.av.position.copy(q);
      this.av.rotation.y = r;
      this.av.visible = v;
    }
  },
  fire(o, d, dmg, wall, far, x) {
    if (!this.c || this.dead) return;
    x = x || {};
    const dn = d.clone().normalize(),
      L = Math.min(wall, far);
    this.send({ t: 'f', o: o.toArray(), d: dn.toArray(), l: L, k: x.k || 0, w: Weapon.cur, q: x.q || 0 });
    if (!this.av || !this.av.visible) return;
    this.av.updateMatrixWorld(true);
    const h = new THREE.Raycaster(o.clone(), dn, 0, L).intersectObjects(
      this.av.children.filter(o => o.userData.p),
      false
    )[0];
    if (h) {
      const q = h.object.userData.p,
        v = q === 'h' ? x.head || Math.min(150, dmg * 3) : q === 'l' ? x.leg || dmg * 0.85 : dmg;
      this.send({ t: 'h', d: Math.round(v) });
      this.lastHead = q === 'h' ? performance.now() : 0; /* para contar headshot no abate */
      FX.hit(h.point);
      Sfx.hit(q === 'h');
      Hud.hitmark(q === 'h');
    }
  },
  recv(m) {
    if (m.t === 's') {
      if (!this.av) this.mkAv();
      if (m.wp && GUNP[m.wp]) this.wpk = m.wp;
      if (m.a !== this.agk || (m.sk | 0) !== (this.skk | 0)) {
        this.skk = m.sk | 0; /* skin do outro jogador */
        this.skin(m.a);
      } else if (this.wpk && this.av.userData.gid !== this.wpk)
        SKIN_RUN(this.agk, this.skk | 0, () =>
          setBodyGun(this.av, this.agk || 'phoenix', this.wpk, 0, 1)
        );
      this.tg = m;
      this.av.visible = !m.g;
      Sfx.peer(m);
    } else if (m.t === 'c') {
      const a = ABI[m.ag] && ABI[m.ag][m.i];
      if (a) Abil.rfx(a, m.i, m);
    } else if (m.t === 'f') {
      if (!m.k && !m.q)
        Sfx.shot(WR[m.w] && WR[m.w].melee ? 'knife' : m.w || 'vandal', new THREE.Vector3(...m.o));
      const o = new THREE.Vector3(...m.o),
        e = o.clone().addScaledVector(new THREE.Vector3(...m.d), m.l);
      if (m.k) {
        const t = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.02, m.l), bm(0xffd27a, 0.8));
        t.position.copy(o.clone().add(e).multiplyScalar(0.5));
        t.lookAt(e);
        if (m.k === 1) Abil.knife(o.clone(), e.clone());
        else if (m.k === 2) Abil.beam(o.clone(), e.clone());
        Abil.add(t, 0.1, q => {
          q.m.material.opacity = 0.8 * (1 - q.t / 0.1);
        });
      } else if (!(WR[m.w] && WR[m.w].melee)) {
        const a = this.av,
          mz = this.muzzleP();
        Tracer.fire(mz || o, e, m.w || 'vandal');
        if (a && a.userData.fl && !m.q) {
          a.userData.fl.visible = true;
          a.userData.flt = 0.06;
        }
      }
    } else if (m.t === 'bp') {
      if (!Round.over && Round.phase === 'live') Bomb.plant(m.s, 1, m.x, m.z, m.y);
    } else if (m.t === 'bd') {
      if (Bomb.pl && !Round.over) Bomb.done();
    } else if (m.t === 'h') Hp.hit(m.d);
    else if (m.t === 'k' && !this.dead) {
      Stats.me.k++;
      Stats.op.d++;
      Profile.rec(Game.agent, 'k');
      if (this.lastHead && performance.now() - this.lastHead < 3000) Profile.rec(Game.agent, 'h');
      this.lastHead = 0;
      this.dead = 1;
      setTimeout(() => {
        this.dead = 0;
      }, 2600);
      Round.elim(Game.side === 'atk' ? 'def' : 'atk');
    }
  },
  died() {
    if (!this.c || this.dead) return;
    Stats.me.d++;
    Stats.op.k++;
    Profile.rec(Game.agent, 'd');
    this.dead = 1;
    this.send({ t: 'k' });
    setTimeout(() => {
      this.dead = 0;
    }, 2600);
    Round.elim(Game.side);
  },
  tick(dt) {
    if (!this.c) return;
    this.acc += dt;
    if (this.acc > 0.05) {
      this.acc = 0;
      this.send({
        t: 's',
        x: pos.x,
        y: pos.y + 0.62 * Mv.cr,
        z: pos.z,
        w: yaw,
        g: Mv.ghost > 0 ? 1 : 0,
        a: Game.agent || 'phoenix',
        sk: Skins.sel(Game.agent || 'phoenix'),
        q: Mv.quiet ? 1 : 0,
        c: Mv.cr > 0.5 ? 1 : 0,
        j: Mv.air ? 1 : 0,
        wp: Weapon.cur
      });
    }
    if (this.av && this.tg) {
      const k = 1 - Math.exp(-18 * dt),
        a = this.av,
        t = this.tg;
      const ox = a.position.x,
        oz = a.position.z;
      a.position.x += (t.x - a.position.x) * k;
      a.position.z += (t.z - a.position.z) * k;
      a.position.y += (Math.max(0, t.y - EYE) - a.position.y) * k;
      a.rotation.y = t.w;
      a.scale.y += ((t.c ? 0.72 : 1) - a.scale.y) * k;
      if (a.visible && dt > 0) {
        const ev = Math.min(1, dt * 20);
        a.userData.vx =
          (a.userData.vx || 0) + ((a.position.x - ox) / dt - (a.userData.vx || 0)) * ev;
        a.userData.vz =
          (a.userData.vz || 0) + ((a.position.z - oz) / dt - (a.userData.vz || 0)) * ev;
        animAv(a, dt, a.userData.vx, a.userData.vz, { air: !!t.j, crouch: !!t.c });
      }
      const u = a.userData;
      if (u.fl && u.flt > 0) {
        u.flt -= dt;
        u.fl.visible = u.flt > 0;
        u.fl.rotation.z = Math.random() * 6.28;
      }
    }
  }
};
