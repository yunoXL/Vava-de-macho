/* ========= CONTROLES ========= */
function createControls() {
  const look = document.getElementById('look');
  look.addEventListener('pointerdown', () => {
    renderer.domElement.requestPointerLock && renderer.domElement.requestPointerLock();
  }); /* clique trava o mouse */
  /* TOUCH: arrastar um dedo na tela gira a câmera (mesma sensibilidade do slider, um pouco maior) */
  let tid = null,
    lx = 0,
    ly = 0;
  look.style.touchAction = 'none';
  look.addEventListener('pointerdown', e => {
    if (e.pointerType === 'mouse' || tid !== null) return;
    tid = e.pointerId;
    lx = e.clientX;
    ly = e.clientY;
    try {
      look.setPointerCapture(e.pointerId);
    } catch (_) {}
  });
  look.addEventListener('pointermove', e => {
    if (e.pointerId !== tid) return;
    const dx = e.clientX - lx,
      dy = e.clientY - ly;
    lx = e.clientX;
    ly = e.clientY;
    if (Menu.on || Pause.on || Shop.on) return;
    if (Abil.ae && Abil.ae.ch < 0) {
      Abil.ae.tx += dx * 0.1;
      Abil.ae.tz += dy * 0.1;
      return;
    }
    yaw -= dx * sens * 0.9 * Scope.sk;
    pitch -= dy * sens * 0.9 * Scope.sk * (SETX.inv ? -1 : 1);
    clampPitch();
  });
  for (const ev of ['pointerup', 'pointercancel'])
    look.addEventListener(ev, e => {
      if (e.pointerId === tid) tid = null;
    });
  document.addEventListener('mousemove', e => {
    if (document.pointerLockElement) {
      if (Abil.ae && Abil.ae.ch < 0) {
        Abil.ae.tx += e.movementX * 0.1;
        Abil.ae.tz += e.movementY * 0.1;
        return;
      }
      yaw -= e.movementX * sens * 0.6 * Scope.sk;
      pitch -= e.movementY * sens * 0.6 * Scope.sk * (SETX.inv ? -1 : 1);
      clampPitch();
    }
  });
  addEventListener('keydown', e => {
    if (e.key === 'Tab') {
      e.preventDefault();
      Board.show(1);
    }
    if (e.ctrlKey && e.key !== 'Control' && document.pointerLockElement) e.preventDefault();
    if (e.target && e.target.type === 'text') return;
    const ck = KB.canon(e);
    if (ck === null) return;
    keys[ck] = true;
    Game.key({ key: ck, repeat: e.repeat });
  });
  addEventListener('keyup', e => {
    keys[e.key.toLowerCase()] = false;
    const ck = KB.canon(e);
    if (ck !== null) keys[ck] = false;
    if (ck === 'j') Weapon.trig(0);
    else if (ck === 'k') Weapon.ads = 0;
    if (e.key === 'Tab') Board.show(0);
  });
  addEventListener('blur', () => {
    Board.show(0);
    for (const k in keys) keys[k] = false;
    Weapon.trig(0);
  });
  sens = 0.005; /* sensibilidade, FOV e volume são ligados em Settings (31-settings.js) */
  addEventListener('resize', handleResize);
}
function clampPitch() {
  pitch = Math.max(-1.4, Math.min(1.4, pitch));
}
function setQuality(q) {
  quality = q;
  sun.castShadow = q > 0 && !!SETX.shadow;
  pixelRatio = prCap = q === 2 ? Math.min(devicePixelRatio || 1, 2) : q === 1 ? 1 : 0.75;
  document
    .querySelectorAll('#pQ button')
    .forEach(b => b.classList.toggle('on', +b.dataset.q === q));
  handleResize();
}
function resetPlayer(key) {
  const s = LAYOUT.spawns[key];
  pos.set(s.pos[0] * S, EYE, s.pos[1] * S);
  vel.set(0, 0, 0);
  yaw = s.yaw;
  pitch = 0;
  Move.reset();
}
function handleResize() {
  const w = innerWidth,
    h = innerHeight;
  renderer.setPixelRatio(pixelRatio);
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
