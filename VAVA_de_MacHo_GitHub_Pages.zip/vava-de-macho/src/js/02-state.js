/* ========= ESTADO ========= */
let renderer,
  scene,
  camera,
  sun,
  tex = {},
  mats = {};
const segs = []; // [ax,az,bx,bz,indiceBarreira]
const barrierObjs = [],
  postObjs = [];
let barriersActive = true,
  barrierFade = 1;
let quality = 2,
  pixelRatio = 1,
  prCap = 1;
const pos = new THREE.Vector3(),
  vel = new THREE.Vector3();
let yaw = 0,
  pitch = 0,
  sens = 0.005,
  keys = {};
const V = p => new THREE.Vector2(p[0] * S, -p[1] * S);
