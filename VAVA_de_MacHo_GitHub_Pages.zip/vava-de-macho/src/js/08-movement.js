/* ========= MOVIMENTO E COLISÃO (melhoria 1) =========
   Camadas separadas, todas orquestradas por updateMovement(dt):
   MOVE (parâmetros) · Terrain (chão, rampas, teto) · Crouch (cápsula) · checkCollisions (paredes)
   · moveGround / moveAir (velocidade) · Move.step (pulo + vertical) · CamRig (câmera) · Accuracy (dispersão)
   Estado público preservado: pos, vel, Mv.{h,G,vy,air,cr,gm,walk,quiet,dx,dz,dt,ghost,speed}. */
/*MOVE-BEGIN*/
const MOVE = {
  H: 1.8,
  HC: 1.18,
  EYE_TOP: 0.15 /* cápsula: em pé 1,80 m · agachado 1,18 m · olho = topo − 0,15 m (1,65 m / 1,03 m) */,
  STEP: 0.35,
  SUPPORT: 0.15,
  LAND_TOL: 0.05 /* degrau máximo · margem de apoio na borda · tolerância de pouso no ar (m) */,
  WALK: 0.57,
  CROUCH: 0.42 /* fração da velocidade de corrida (SPEED) */,
  ACCEL: 50,
  DECEL: 42,
  BRAKE: 85,
  TURN: 16 /* acelerar · parar sem input · frear (counter-strafe) [m/s²] · giro máx. da velocidade no chão [rad/s] */,
  CT_DOWN: 0.16,
  CT_UP: 0.18 /* s: duração de agachar / levantar */,
  G: 30,
  JUMP_H: 1.4,
  JETT_H: 1.92,
  TERM: 40,
  JUMP_KEEP: 1,
  JUMP_CD: 0,
  JUMP_BUF: 0.12 /* sem perda ao pular e sem espera após pousar: dá p/ encadear bhop (1 toque de espaço por pulo) */,
  AIR_ACCEL: 75,
  AIR_WISH: 0.55,
  AIR_MAXK: 1.55,
  AIR_MIN: 0.3 /* ar: aceleração (m/s²) · velocidade desejada máx. p/ strafe (m/s) · teto de velocidade (× corrida) · deriva mínima */,
  REACH: 1.3,
  REACH_MIN: 0.25,
  GRAB_R: 0.35,
  MANTLE_T: 0.3 /* subir em quinas: alcance acima dos pés (m) · desnível mínimo · distância extra da borda · duração (s) */,
  LAND_MIN: 4,
  LAND_LOSS: 0.02,
  LAND_LOSS_MAX: 0.3,
  CAM_STEP_K: 16,
  CAM_STEP_MIN: 0.03,
  LAND_K: 220,
  LAND_C: 24,
  LAND_AMP: 0.16,
  LAND_VMAX: 1.5,
  ACC_DEAD: 0.1,
  ACC_AIR: 2,
  ACC_RISE: 12,
  ACC_RECOVER: 5,
  ACC_CROUCH: 0.25,
  DT: 1 / 120 /* passo máximo da física: independe do FPS */
};
MOVE.JUMP_V = Math.sqrt(2 * MOVE.G * MOVE.JUMP_H);
MOVE.JETT_V = Math.sqrt(2 * MOVE.G * MOVE.JETT_H);
MOVE.ABIL_VS = Math.sqrt(
  MOVE.G / 22
); /* habilidades foram calibradas com g=22: mantém a mesma altura */
const ssm = p => p * p * (3 - 2 * p);

/* --- Terreno: caixas, polígonos, rampas e teto --- */
const Terrain = {
  ramps: [],
  /* maior superfície de apoio sob (x,z) cujo topo está até h+tol (degraus e rampas entram via tol) */
  ground(x, z, h, tol) {
    let g = 0;
    const lim = h + tol,
      M = MOVE.SUPPORT;
    for (const b of BOXES) {
      const t = b[4];
      if (t > g && t <= lim && x > b[0] - M && x < b[2] + M && z > b[1] - M && z < b[3] + M) g = t;
    }
    for (const q of POLYS) {
      const t = q[1];
      if (t > g && t <= lim && inPoly(x, z, q[0])) g = t;
    }
    for (const r of this.ramps) {
      const t = this.rampH(r, x, z);
      if (t > g && t <= lim) g = t;
    }
    return g;
  },
  rampH(r, x, z) {
    if (x < r.x1 || x > r.x2 || z < r.z1 || z > r.z2) return -1;
    const t = r.ax === 'x' ? (x - r.x1) / (r.x2 - r.x1) : (z - r.z1) / (r.z2 - r.z1);
    return r.h0 + (r.h1 - r.h0) * t;
  },
  /* rampa retangular (m): altura vai de h0 (menor coordenada do eixo) a h1 (maior). Laterais e topo viram paredes. */
  addRamp(xa, za, xb, zb, ax, h0, h1) {
    const r = {
      x1: Math.min(xa, xb),
      z1: Math.min(za, zb),
      x2: Math.max(xa, xb),
      z2: Math.max(za, zb),
      ax,
      h0,
      h1
    };
    this.ramps.push(r);
    const top = Math.max(h0, h1),
      S_ = (a, b, c, d) => segs.push([a, b, c, d, -1, null, top]);
    if (ax === 'x') {
      S_(r.x1, r.z1, r.x2, r.z1);
      S_(r.x1, r.z2, r.x2, r.z2);
      const xe = h1 >= h0 ? r.x2 : r.x1;
      S_(xe, r.z1, xe, r.z2);
    } /* laterais + extremidade alta */ else {
      S_(r.x1, r.z1, r.x1, r.z2);
      S_(r.x2, r.z1, r.x2, r.z2);
      const ze = h1 >= h0 ? r.z2 : r.z1;
      S_(r.x1, ze, r.x2, ze);
    }
    return r;
  },
  /* menor teto sobre a cápsula (centro + 4 pontos do raio) */
  headroom(x, z) {
    const r = RADIUS * 0.8;
    let c = ceilH(x, z),
      t;
    t = ceilH(x + r, z);
    if (t < c) c = t;
    t = ceilH(x - r, z);
    if (t < c) c = t;
    t = ceilH(x, z + r);
    if (t < c) c = t;
    t = ceilH(x, z - r);
    if (t < c) c = t;
    return c;
  }
};
function floorAt(x, z) {
  return Terrain.ground(x, z, Mv.h, MOVE.LAND_TOL);
} /* compatibilidade */

/* --- Agachamento: altura da cápsula animada; câmera e colisão leem o mesmo valor (Mv.cr) --- */
const Crouch = {
  p: 0,
  update(h, want, room) {
    const M = MOVE;
    this.p = want ? Math.min(1, this.p + h / M.CT_DOWN) : Math.max(0, this.p - h / M.CT_UP);
    const need = Math.min(
      1,
      Math.max(0, (M.H - (room - 0.01)) / (M.H - M.HC))
    ); /* agachamento mínimo que o teto permite */
    if (ssm(this.p) < need) {
      let lo = 0,
        hi = 1;
      for (let i = 0; i < 12; i++) {
        const m = (lo + hi) / 2;
        if (ssm(m) < need) lo = m;
        else hi = m;
      }
      this.p = hi;
    }
    Mv.cr = ssm(this.p);
  },
  height() {
    return MOVE.H - (MOVE.H - MOVE.HC) * Mv.cr;
  } /* altura atual da cápsula (m) */
};

/* --- Câmera: suaviza degraus e amortece o impacto de pouso (sem balanço de caminhada) --- */
const CamRig = {
  step: 0,
  land: 0,
  landV: 0,
  update(h) {
    this.step *= Math.exp(-MOVE.CAM_STEP_K * h);
    this.landV += (-MOVE.LAND_K * this.land - MOVE.LAND_C * this.landV) * h;
    this.land += this.landV * h;
  },
  stepBy(dh) {
    if (Math.abs(dh) > MOVE.CAM_STEP_MIN)
      this.step = Math.max(-MOVE.STEP, Math.min(MOVE.STEP, this.step + dh));
  },
  impact(fall) {
    this.landV -= Math.min(MOVE.LAND_VMAX, fall * MOVE.LAND_AMP);
  },
  y() {
    return this.step + this.land;
  },
  zero() {
    this.step = this.land = this.landV = 0;
  }
};

/* --- Colisão horizontal: cápsula (círculo de raio RADIUS) contra segmentos; coleta normais p/ cortar a velocidade --- */
const WN = new Float32Array(16);
let wnN = 0;
function checkCollisions(p) {
  const tol = Move.gr
    ? MOVE.STEP
    : MOVE.LAND_TOL; /* no chão sobe degraus ≤ STEP · no ar só passa se os pés já estão no topo */
  for (let it = 0; it < 4; it++) {
    let moved = false;
    for (const s of segs) {
      if (s[4] >= 0 && !barriersActive) continue;
      if (s[5] && !s[5].solid) continue; /* porta aberta ou destruída */
      if (s[6] !== undefined && Mv.h >= s[6] - tol)
        continue; /* pés já no nível do topo: sobe na caixa/degrau */
      if (
        (p.x < s[0] - RADIUS && p.x < s[2] - RADIUS) ||
        (p.x > s[0] + RADIUS && p.x > s[2] + RADIUS) ||
        (p.z < s[1] - RADIUS && p.z < s[3] - RADIUS) ||
        (p.z > s[1] + RADIUS && p.z > s[3] + RADIUS)
      )
        continue; /* descarte rápido: segmento longe */
      const abx = s[2] - s[0],
        abz = s[3] - s[1];
      let t = ((p.x - s[0]) * abx + (p.z - s[1]) * abz) / (abx * abx + abz * abz);
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      const cx = s[0] + abx * t,
        cz = s[1] + abz * t;
      let dx = p.x - cx,
        dz = p.z - cz;
      const d = Math.hypot(dx, dz);
      if (d < RADIUS) {
        if (d < 1e-6) {
          const l = Math.hypot(abx, abz);
          dx = -abz / l;
          dz = abx / l;
        } else {
          dx /= d;
          dz /= d;
        }
        p.x = cx + dx * (RADIUS + 0.002);
        p.z = cz + dz * (RADIUS + 0.002);
        moved = true;
        if (
          wnN < 8 &&
          !(
            wnN > 0 &&
            Math.abs(WN[wnN * 2 - 2] - dx) < 0.001 &&
            Math.abs(WN[wnN * 2 - 1] - dz) < 0.001
          )
        ) {
          WN[wnN * 2] = dx;
          WN[wnN * 2 + 1] = dz;
          wnN++;
        }
      }
    }
    if (!moved) break;
  }
}

/* --- Velocidade no chão: aceleração/frenagem lineares, counter-strafe e giro limitado (não trava em parede) --- */
function moveGround(h, wx, wz, sp) {
  const M = MOVE;
  if (wx === 0 && wz === 0) {
    /* sem input: desacelera linearmente */
    const s = Math.hypot(vel.x, vel.z);
    if (s > 0) {
      const k = Math.max(0, s - M.DECEL * h) / s;
      vel.x *= k;
      vel.z *= k;
    }
    return;
  }
  const s0 = Math.hypot(vel.x, vel.z);
  let al = vel.x * wx + vel.z * wz,
    px = vel.x - al * wx,
    pz = vel.z - al * wz,
    rem = h,
    q = Math.hypot(px, pz);
  if (al < 0) {
    const need = -al / M.BRAKE;
    if (need >= h) {
      al += M.BRAKE * h;
      rem = 0;
    } else {
      al = 0;
      rem = h - need;
    }
  } /* counter-strafe: freia o movimento contrário primeiro */
  if (rem > 0) {
    if (q > 1e-9 && al >= 0) {
      const s = Math.hypot(al, q),
        f = Math.max(0, Math.atan2(q, al) - M.TURN * rem);
      al = s * Math.cos(f);
      const nq = s * Math.sin(f);
      px *= nq / q;
      pz *= nq / q;
    } /* gira rumo à direção desejada, sem perder módulo */
    if (al < sp) al = Math.min(sp, al + M.ACCEL * rem);
    else al = Math.max(sp, al - M.DECEL * rem); /* acelera ao alvo (ou reduz se andou/agachou) */
  }
  vel.x = wx * al + px;
  vel.z = wz * al + pz;
  const s1 = Math.hypot(vel.x, vel.z),
    lim = Math.max(sp, s0);
  if (s1 > lim) {
    const k = lim / s1;
    vel.x *= k;
    vel.z *= k;
  } /* nunca ganha velocidade além do alvo */
}
/* --- Velocidade no ar (strafe estilo Source): A/D + giro do mouse somam velocidade; W sozinho não acelera; teto em Move.cap --- */
function moveAir(h, wx, wz) {
  const M = MOVE;
  if (wx === 0 && wz === 0) return;
  const add =
    M.AIR_WISH -
    (vel.x * wx +
      vel.z * wz); /* só acelera enquanto a velocidade NA direção desejada for menor que AIR_WISH */
  if (add > 0) {
    const a = Math.min(add, M.AIR_ACCEL * h);
    vel.x += wx * a;
    vel.z += wz * a;
  }
  const s = Math.hypot(vel.x, vel.z);
  if (s > Move.cap) {
    const k = Move.cap / s;
    vel.x *= k;
    vel.z *= k;
  }
}

/* --- Estado e passo fixo da física (pulo, gravidade, pouso, degraus, teto) --- */
const Move = {
  gr: 1,
  jprev: 0,
  jbuf: 0,
  jcd: 0,
  cap: 0,
  mt: null,
  I: { wx: 0, wz: 0, wk: 0, cw: 0, DD: false, jt: false },
  reset() {
    this.mt = null;
    this.gr = 1;
    this.jprev = 0;
    this.jbuf = 0;
    this.jcd = 0;
    this.cap = 0;
    Mv.h = 0;
    Mv.vy = 0;
    Mv.G = 0;
    Mv.air = 0;
    Mv.cr = 0;
    Crouch.p = 0;
    CamRig.zero();
    Accuracy.pen = 0;
  },
  leave(jumped) {
    this.gr = 0;
    Mv.air = 1;
    if (jumped) {
      vel.x *= MOVE.JUMP_KEEP;
      vel.z *= MOVE.JUMP_KEEP;
    } /* preserva parte do impulso */
    this.cap = Math.max(
      Math.hypot(vel.x, vel.z),
      MOVE.AIR_MIN * SPEED * Mv.speed,
      MOVE.AIR_MAXK * SPEED * Mv.speed
    );
  },
  land(fall) {
    const M = MOVE;
    if (fall > 3) Sfx.land(fall, Mv.quiet);
    if (fall > M.LAND_MIN) {
      CamRig.impact(fall);
      if (this.jbuf <= 0) {
        const l = 1 - Math.min(M.LAND_LOSS_MAX, (fall - M.LAND_MIN) * M.LAND_LOSS);
        vel.x *= l;
        vel.z *= l;
      }
    } /* pouso com pulo já apertado (bhop) não perde velocidade */
    this.jcd = M.JUMP_CD;
  },
  /* --- Subir em objetos: no ar, perto de uma quina até MOVE.REACH acima dos pés, você se agarra e sobe (pulo + andar p/ o objeto) --- */
  ledge() {
    const M = MOVE,
      fx = -Math.sin(yaw),
      fz = -Math.cos(yaw),
      I = this.I;
    let best = null,
      bd = RADIUS + M.GRAB_R;
    const lo = Mv.h + M.REACH_MIN,
      hi = Mv.h + M.REACH,
      ch = M.HC + 0.05,
      P4 = [
        [0, 0],
        [0, 0],
        [0, 0],
        [0, 0]
      ];
    const test = (P, top) => {
      if (top < lo || top > hi) return;
      let md = 1e9,
        cx = 0,
        cz = 0;
      for (let i = 0; i < P.length; i++) {
        const a = P[i],
          b = P[(i + 1) % P.length],
          dx = b[0] - a[0],
          dz = b[1] - a[1];
        let t = ((pos.x - a[0]) * dx + (pos.z - a[1]) * dz) / (dx * dx + dz * dz || 1);
        t = t < 0 ? 0 : t > 1 ? 1 : t;
        const qx = a[0] + dx * t,
          qz = a[1] + dz * t,
          d = Math.hypot(pos.x - qx, pos.z - qz);
        if (d < md) {
          md = d;
          cx = qx;
          cz = qz;
        }
      }
      if (md >= bd || inPoly(pos.x, pos.z, P)) return;
      const dx = cx - pos.x,
        dz = cz - pos.z,
        l = Math.hypot(dx, dz) || 1,
        dn = dx / l,
        dm = dz / l;
      if (Math.max(dn * fx + dm * fz, I.wx * dn + I.wz * dm) < 0.35)
        return; /* só se estiver olhando/andando para a quina */
      let tx = cx + dn * 0.55,
        tz = cz + dm * 0.55;
      if (!inPoly(tx, tz, P)) {
        let gx = 0,
          gz = 0;
        for (const q of P) {
          gx += q[0];
          gz += q[1];
        }
        tx = gx / P.length;
        tz = gz / P.length;
        if (!inPoly(tx, tz, P)) return;
      }
      if (Terrain.headroom(tx, tz) - top < ch) return; /* sem espaço em cima */
      best = { top, tx, tz };
      bd = md;
    };
    for (const b of BOXES) {
      if (
        b[4] < lo ||
        b[4] > hi ||
        pos.x < b[0] - bd ||
        pos.x > b[2] + bd ||
        pos.z < b[1] - bd ||
        pos.z > b[3] + bd
      )
        continue;
      P4[0][0] = b[0];
      P4[0][1] = b[1];
      P4[1][0] = b[2];
      P4[1][1] = b[1];
      P4[2][0] = b[2];
      P4[2][1] = b[3];
      P4[3][0] = b[0];
      P4[3][1] = b[3];
      test(P4, b[4]);
    }
    for (const q of POLYS) test(q[0], q[1]);
    return best;
  },
  step(h) {
    const M = MOVE,
      I = this.I,
      gh = Mv.ghost ? 1 : 0;
    this.jbuf = Math.max(0, this.jbuf - h);
    this.jcd = Math.max(0, this.jcd - h);
    /* subida em andamento: sobe na vertical e depois avança para cima do objeto */
    if (this.mt) {
      const m = this.mt;
      m.t += h;
      const k = Math.min(1, m.t / M.MANTLE_T),
        kv = ssm(Math.min(1, k * 1.7)),
        kh = ssm(Math.max(0, (k - 0.35) / 0.65));
      Mv.h = m.sh + (m.top - m.sh) * kv;
      pos.x = m.sx + (m.tx - m.sx) * kh;
      pos.z = m.sz + (m.tz - m.sz) * kh;
      vel.set(0, 0, 0);
      Mv.vy = 0;
      Mv.air = 1;
      this.gr = 0;
      pos.y = Mv.h + Crouch.height() - M.EYE_TOP;
      CamRig.update(h);
      if (k >= 1) {
        this.mt = null;
        checkCollisions(pos);
        Mv.h = m.top;
        Mv.G = m.top;
        this.gr = 1;
        Mv.air = 0;
        this.jcd = M.JUMP_CD;
        pos.y = Mv.h + Crouch.height() - M.EYE_TOP;
      }
      return;
    }
    /* agachamento (cápsula) respeitando o teto */
    const hr = gh ? 35 : Terrain.headroom(pos.x, pos.z);
    Crouch.update(h, I.cw, hr - Mv.h);
    const base = I.wk ? M.WALK : 1,
      sm = base + (M.CROUCH - base) * Mv.cr;
    Mv.gm = sm;
    const sp = SPEED * Mv.speed * sm * (Weapon.w().spd || 1); /* Ares/Odin andam um pouco mais devagar */
    /* impulso vertical externo (habilidade) tira do chão */
    if (this.gr && Mv.vy > 0) this.leave(false);
    /* pulo: um por toque, só no chão, com pequena recuperação após pousar */
    if (this.gr && this.jbuf > 0 && this.jcd <= 0 && !I.DD && !gh) {
      Mv.vy = I.jt ? M.JETT_V : M.JUMP_V;
      this.jbuf = 0;
      this.leave(true);
      Sfx.jump(Mv.quiet);
    }
    /* no ar, de frente para uma quina ao alcance: agarra e sobe */
    if (!this.gr && !gh && Mv.vy > -6 && !I.DD) {
      const L = this.ledge();
      if (L) {
        this.mt = { sx: pos.x, sz: pos.z, sh: Mv.h, top: L.top, tx: L.tx, tz: L.tz, t: 0 };
        Sfx.mantle && Sfx.mantle();
        return;
      }
    }
    /* velocidade horizontal */
    if (this.gr) moveGround(h, I.wx, I.wz, sp);
    else moveAir(h, I.wx, I.wz);
    /* deslocamento em micro-passos (nunca atravessa parede) + remoção da velocidade contra a parede */
    const dx = (vel.x + Mv.dx) * h,
      dz = (vel.z + Mv.dz) * h,
      n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / 0.1));
    wnN = 0;
    for (let i = 0; i < n; i++) {
      pos.x += dx / n;
      pos.z += dz / n;
      if (!gh) checkCollisions(pos);
    }
    if (!gh && wnN > 0) {
      for (let k = 0; k < wnN; k++) {
        const nx = WN[k * 2],
          nz = WN[k * 2 + 1],
          vn = vel.x * nx + vel.z * nz;
        if (vn < 0) {
          vel.x -= vn * nx;
          vel.z -= vn * nz;
        }
      }
    }
    Abil.block();
    /* vertical: no chão acompanha degraus/rampas; no ar gravidade (Verlet) e pouso */
    const G = gh ? 0 : Terrain.ground(pos.x, pos.z, Mv.h, this.gr ? M.STEP : M.LAND_TOL);
    Mv.G = G;
    if (this.gr) {
      if (G >= Mv.h - M.STEP - 1e-6) {
        CamRig.stepBy(Mv.h - G);
        Mv.h = G;
        Mv.vy = 0;
      } /* gruda no terreno (sobe/desce degrau, segue rampa) */ else {
        Mv.vy = 0;
        this.leave(false);
      } /* saiu da borda: cai */
    }
    if (!this.gr) {
      let nh = Mv.h + Mv.vy * h - 0.5 * M.G * h * h,
        nv = Mv.vy - M.G * h;
      if (I.jt && keys[' '] && nv < -1.6) nv = -1.6; /* Jett: segurando espaço no ar, ela flutua */
      if (nv < -M.TERM) nv = -M.TERM;
      if (nh <= G && nv <= 0) {
        const fall = -nv;
        Mv.h = G;
        Mv.vy = 0;
        this.gr = 1;
        Mv.air = 0;
        this.land(fall);
      } else {
        Mv.h = nh;
        Mv.vy = nv;
        const ch = Crouch.height();
        if (Mv.vy > 0 && Mv.h + ch > hr) {
          Mv.h = hr - ch;
          Mv.vy = 0;
        }
      } /* bate a cabeça no teto */
    }
    Mv.air = this.gr ? 0 : 1;
    pos.y = Mv.h + Crouch.height() - M.EYE_TOP;
    CamRig.update(h);
  }
};

function updateMovement(dt) {
  if (Abil.ae && Abil.ae.ch < 0) {
    vel.set(0, 0, 0);
    Accuracy.update(dt);
    return;
  }
  dt = Math.min(dt, 0.05);
  const fx = -Math.sin(yaw),
    fz = -Math.cos(yaw),
    rx = Math.cos(yaw),
    rz = -Math.sin(yaw);
  const DD = Hp.v <= 0 || Round.done;
  let ix = DD ? 0 : (keys.d ? 1 : 0) - (keys.a ? 1 : 0),
    iy = DD ? 0 : (keys.w ? 1 : 0) - (keys.s ? 1 : 0);
  const m = Math.hypot(ix, iy);
  if (m > 1) {
    ix /= m;
    iy /= m;
  }
  let wx = rx * ix + fx * iy,
    wz = rz * ix + fz * iy;
  const wl = Math.hypot(wx, wz);
  if (wl > 0.01) {
    wx /= wl;
    wz /= wl;
  } else {
    wx = wz = 0;
  }
  const wk = keys.shift && !Mv.ghost ? 1 : 0,
    cw = keys.control ? 1 : 0;
  Mv.walk = wk; /* SHIFT = andar devagar e silencioso · CTRL = agachar */
  const I = Move.I;
  I.wx = wx;
  I.wz = wz;
  I.wk = wk;
  I.cw = cw;
  I.DD = DD;
  I.jt = Game.agent === 'jett';
  const jk = !!keys[' '] && !DD && !Mv.ghost;
  if (jk && !Move.jprev) Move.jbuf = MOVE.JUMP_BUF;
  Move.jprev = jk; /* pulo por toque (sem bunny hop automático) */
  if (Mv.dt > 0) {
    Mv.dt -= dt;
    if (Mv.dt <= 0) Mv.dx = Mv.dz = 0;
  }
  const n = Math.max(1, Math.ceil(dt / MOVE.DT)),
    h = dt / n;
  for (let i = 0; i < n; i++) Move.step(h);
  Mv.quiet = wk || cw || Mv.cr > 0.4 ? 1 : 0;
  const st = Mv.cr > 0.5 ? 'AGACHADO' : wk ? 'ANDANDO' : '';
  if (st !== Mv.stt) {
    Mv.stt = st;
    const se = document.getElementById('stance');
    if (se) {
      se.textContent = st;
      se.classList.toggle('on', !!st);
    }
  }
  Accuracy.update(dt);
}
function updateCamera() {
  if (Abil.ae && Abil.ae.ch < 0) {
    camera.position.set(Abil.ae.tx, 75, Abil.ae.tz);
    camera.rotation.set(-Math.PI / 2, 0, 0);
    return;
  }
  camera.position.set(pos.x, pos.y + CamRig.y(), pos.z);
  camera.rotation.y = yaw + Recoil.y + Scope.sx;
  camera.rotation.x = Math.max(-1.45, Math.min(1.45, pitch + Recoil.p + Scope.sy));
}

/* --- Precisão: velocidade real → penalidade suave; recupera progressivamente ao parar (usado por Weapon.spread) --- */
const Accuracy = {
  pen: 0,
  update(dt) {
    const M = MOVE;
    let t;
    if (Mv.air && !Mv.ghost) t = M.ACC_AIR; /* pulando: bastante reduzida */
    else {
      const f = Math.min(
        1,
        Math.max(0, (Math.hypot(vel.x, vel.z) / SPEED - M.ACC_DEAD) / (1 - M.ACC_DEAD))
      );
      t = f * f;
    } /* parado 0 · andando ~0,26 · correndo 1 */
    if (t > this.pen) this.pen = Math.min(t, this.pen + M.ACC_RISE * dt);
    else this.pen = Math.max(t, this.pen - M.ACC_RECOVER * dt);
  },
  mv() {
    return this.pen;
  },
  stance() {
    return 1 - MOVE.ACC_CROUCH * Mv.cr;
  } /* agachado = dispersão menor */
};
/*MOVE-END*/
