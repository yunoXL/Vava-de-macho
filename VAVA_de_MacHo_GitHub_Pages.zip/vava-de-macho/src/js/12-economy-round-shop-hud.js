const Econ = {
  c: CFG.startCredits,
  add(n) {
    this.c = Math.min(CFG.creditCap, this.c + n);
    Hud.cred();
  },
  spend(n) {
    if (n > this.c) return false;
    this.c -= n;
    Hud.cred();
    return true;
  },
  reward(win) {
    if (win === true) this.add(CFG.winReward);
    else if (win === false) this.add(CFG.lossReward);
  }
};
const Inv = {
    owned: { classic: 1, knife: 1 },
    slots: { pri: null, sec: 'classic', mel: 'knife' },
    armor: 0
  },
  SLOTN = { mel: 3, pri: 2, sec: 1 };

const BarrierController = {
  k: 1,
  opening: false,
  reset() {
    this.k = 1;
    this.opening = false;
    setBarriersActive(true);
  },
  open() {
    if (this.opening || !barriersActive) return;
    this.opening = true;
  } /* uma única vez por rodada */,
  update(dt) {
    if (!this.opening) return;
    this.k = Math.max(0, this.k - dt / CFG.barrierFade);
    if (this.k <= 0) {
      this.opening = false;
      setBarriersActive(false);
    }
  }
}; /* colisão cai junto com o visual */

let bnT;
function banner(m, ms) {
  const b = $$('banner');
  b.textContent = m;
  b.classList.add('on');
  clearTimeout(bnT);
  bnT = setTimeout(() => b.classList.remove('on'), ms || 2400);
}
const WIN_ROUNDS = 13,
  OT_AT = 12; /* vence quem chegar a 13; em 12x12 vai à prorrogação: vence quem fizer 2 rodadas seguidas */
const Round = {
  phase: 'buy',
  t: CFG.buyTime,
  rt: CFG.roundTime,
  n: 0,
  k: '',
  score: { a: 0, e: 0 },
  ot: 0,
  ots: 0,
  otw: null,
  over: 0,
  done: 0,
  tk: 0,
  reset() {
    this.n = 0;
    this.score = { a: 0, e: 0 };
    this.ot = 0;
    this.ots = 0;
    this.otw = null;
    this.over = 0;
    this.done = 0;
  },
  start() {
    this.phase = 'buy';
    this.t = CFG.buyTime;
    this.rt = CFG.roundTime;
    this.n++;
    this.k = '';
    this.over = 0;
    this.tk++;
    Bomb.reset();
    BarrierController.reset();
    Game.resetRound();
    this.show();
    Shop.render();
  },
  update(dt) {
    if (Training.on || this.done) return;
    if (this.phase !== 'buy') {
      if (!Bomb.pl && !this.over) {
        this.rt = Math.max(0, this.rt - dt);
        if (this.rt <= 0) this.finish(Game.side === 'def', 'TEMPO ESGOTADO');
      }
      return this.show();
    }
    this.t -= dt;
    if (this.t <= 0) {
      this.t = 0;
      this.phase = 'live';
      BarrierController.open();
      banner('FASE DE COMPRA ENCERRADA', 2400);
      Shop.render();
    }
    this.show();
  },
  show() {
    const buy = this.phase === 'buy',
      pl = !!Bomb.pl,
      k = buy ? Math.ceil(this.t) : -1,
      v = pl ? Math.ceil(Math.max(0, Bomb.t)) : buy ? k : Math.ceil(this.rt),
      key = (pl ? 'p' : buy ? 'b' : 'l') + v;
    if (key === this.k) return;
    this.k = key;
    const cls = pl ? 'rd' : !buy || k >= 10 ? 'wh' : k >= 4 ? 'yl' : 'rd';
    $$('tm').firstChild.nodeValue = fmtT(v);
    $$('tm').className = 'tm ' + cls;
    $$('sct').textContent = pl
      ? 'SPIKE PLANTADA'
      : buy
        ? 'COMPRAR — ' + k + 's'
        : 'FASE DE COMPRA ENCERRADA';
    $$('sct').className = cls;
  },
  /* eliminação: v = lado de quem morreu ('atk'|'def') */
  elim(v) {
    if (this.over || this.done || Training.on) return;
    if (v === 'def') this.finish(Game.side === 'atk', 'DEFENSORES ELIMINADOS');
    else if (!Bomb.pl) this.finish(Game.side === 'def', 'ATACANTES ELIMINADOS');
  } /* atacante morto com spike plantada: a rodada continua */,
  finish(win, msg, ms) {
    if (this.over || this.done || Training.on) return;
    this.over = 1;
    Bomb.stop();
    ms = ms || 2400;
    banner(msg + ' · ' + (win ? 'RODADA VENCIDA' : 'RODADA PERDIDA'), ms);
    const tk = this.tk;
    setTimeout(() => {
      if (this.tk !== tk || Menu.on || this.done) return;
      this.end(win);
    }, ms);
  },
  end(win) {
    if (win === true) this.score.a++;
    else if (win === false) this.score.e++;
    Hud.score();
    Econ.reward(win);
    const w = this.judge(win);
    if (w) {
      this.matchEnd(w);
      return;
    }
    this.start();
  },
  judge(win) {
    const a = this.score.a,
      e = this.score.e;
    if (!this.ot) {
      if (a >= WIN_ROUNDS) return 'a';
      if (e >= WIN_ROUNDS) return 'e';
      if (a === OT_AT && e === OT_AT) {
        this.ot = 1;
        this.ots = 0;
        this.otw = null;
        banner('PRORROGAÇÃO · QUEM FIZER 2 SEGUIDAS VENCE', 3200);
      }
      return 0;
    }
    const w = win ? 'a' : 'e';
    if (this.otw === w) this.ots++;
    else {
      this.otw = w;
      this.ots = 1;
    }
    return this.ots >= 2 ? w : 0;
  },
  matchEnd(w) {
    this.done = 1;
    Weapon.trig(0);
    Bomb.stop();
    document.exitPointerLock && document.exitPointerLock();
    const win = w === 'a';
    if (win) Profile.rec(Game.agent, 'w'); /* vitória */
    $$('meT').textContent = win ? 'VITÓRIA' : 'DERROTA';
    $$('meT').style.color = win ? '#5fe39a' : '#ff4655';
    $$('meS').textContent = this.score.a + ' x ' + this.score.e + (this.ot ? ' · PRORROGAÇÃO' : '');
    $$('mEnd').classList.add('on');
  }
};

const ICON = {
  light:
    '<svg viewBox="0 0 64 64" fill="none" stroke="#38e1ff" stroke-width="3" stroke-linejoin="round"><path d="M32 5l22 8v16c0 14-9 25-22 30C19 54 10 43 10 29V13z" fill="rgba(56,225,255,.16)"/><path d="M32 20l3.5 7.5 8 .9-6 5.4 1.7 8L32 37.6 24.8 41.8l1.7-8-6-5.4 8-.9z" fill="#38e1ff" stroke="none"/></svg>',
  heavy:
    '<svg viewBox="0 0 64 64" fill="none" stroke="#c18cff" stroke-width="3" stroke-linejoin="round"><path d="M32 5l22 8v16c0 14-9 25-22 30C19 54 10 43 10 29V13z" fill="rgba(193,140,255,.18)"/><path d="M32 17v10M20 27l12 7 12-7M20 36l12 7 12-7"/></svg>'
};
/* disposição igual ao menu de compra do Valorant: SIDEARM | PRIMARY (3 colunas) | ESCUDOS */
const SHOP_SIDE = [['PISTOLAS', 'Pistolas']],
  SHOP_PRIM = [
    [
      ['SMGS', 'SMGs'],
      ['SHOTGUNS', 'Shotguns']
    ],
    [['RIFLES', 'Rifles']],
    [
      ['SNIPERS', 'Snipers'],
      ['PESADAS', 'Heavy']
    ]
  ];
const hex6 = c => '#' + c.toString(16).padStart(6, '0'),
  rgba6 = (c, a) =>
    'rgba(' + ((c >> 16) & 255) + ',' + ((c >> 8) & 255) + ',' + (c & 255) + ',' + a + ')';
const Shop = {
  on: 0,
  init() {
    $$('sb').onclick = e => {
      const c = e.target.closest('.cd');
      if (!c) return;
      if (c.dataset.w) this.buy(c.dataset.w);
      else if (c.dataset.a !== undefined) {
        Abil.buyCharge(+c.dataset.a);
        this.render();
      } else this.shield(c.dataset.s);
    };
    $$('sx').onclick = () => this.toggle(0);
    $$('sb').onmouseover = e => {
      const c = e.target.closest('.cd[data-w]');
      if (c) this.info(c.dataset.w);
    };
    $$('sb').onmouseleave = () => this.info(Weapon.cur);
    $$('sb').oncontextmenu = e => {
      const c = e.target.closest('.cd[data-w]');
      e.preventDefault();
      if (c) this.sell(c.dataset.w);
    };
  },
  toggle(v) {
    this.on = v === undefined ? !this.on : v;
    $$('shop').classList.toggle('on', !!this.on);
    if (this.on) {
      Weapon.trig(0);
      document.exitPointerLock && document.exitPointerLock();
      this.render();
    }
  },
  ok(w) {
    return w.melee || (w.price > 0 && (Training.on || w.side === 'both' || w.side === Game.side));
  } /* restrição vale só para comprar */,
  /* cartão de arma (igual ao Valorant: silhueta grande, nome e preço embaixo, borda verde-água quando comprada) */
  card(w, open) {
    const own = Inv.owned[w.id],
      eq = Weapon.cur === w.id,
      c = own ? 'own' : !open || w.price > Econ.c ? 'no' : '';
    return (
      '<div class="cd ' +
      c +
      (eq ? ' eq' : '') +
      '" data-w="' +
      w.id +
      '"><img src="' +
      Thumb.get(w.id) +
      '"><div class="ct"><b>' +
      w.name +
      '</b><span>' +
      (own ? 'COMPRADA' : w.price ? '¤' + fmt(w.price) : 'GRÁTIS') +
      '</span></div></div>'
    );
  },
  /* grupo com título (SMGS, RIFLES…) e os cartões do mais barato ao mais caro */
  grp(label, cat, open) {
    const L = Object.values(WR)
      .filter(w => !w.melee && w.cat === cat && (Inv.owned[w.id] || this.ok(w)))
      .sort((a, b) => a.price - b.price);
    if (!L.length) return '';
    return (
      '<div class="vg" style="flex:' +
      L.length +
      ' 1 0"><div class="vh">' +
      label +
      '</div><div class="vl">' +
      L.map(w => this.card(w, open)).join('') +
      '</div></div>'
    );
  },
  /* barra de estatísticas embaixo (passe o mouse num cartão; sem mouse mostra a arma na mão) */
  info(id) {
    const w = WR[id],
      el = $$('sdt');
    if (!w || !el) return;
    this.sel = id;
    const st = (l, v) => '<div class="si"><small>' + l + '</small><b>' + v + '</b></div>';
    if (w.melee) {
      el.innerHTML =
        '<div class="sn"><b>' + w.name + '</b><small>FACA</small></div>' + st('DANO', w.dmg);
      return;
    }
    const pel = w.pel || 1,
      lg = Math.round(w.dmg * 0.85);
    el.innerHTML =
      '<div class="sn"><b>' +
      w.name +
      '</b><small>' +
      w.cat.toUpperCase() +
      '</small></div>' +
      st('DANO · CABEÇA / CORPO / PERNA', w.head + ' / ' + w.dmg + ' / ' + lg + (pel > 1 ? ' ×' + pel : '')) +
      st('CADÊNCIA', w.rate + '/s' + (w.auto ? ' · AUTO' : ' · SEMI')) +
      st('MUNIÇÃO', w.mag + ' / ' + w.res) +
      st('RECARGA', w.rld + 's') +
      st('PENETRAÇÃO', w.pen.toUpperCase()) +
      '<div class="sh2">CLIQUE ESQ.: COMPRAR<br>CLIQUE DIR.: VENDER</div>';
  },
  render() {
    if (!this.on) return;
    const open = Round.phase === 'buy',
      tab = t => '<div class="vt"><i></i>' + t + '</div>';
    $$('sCr').textContent = fmt(Econ.c);
    const side = SHOP_SIDE.map(([l, c]) => this.grp(l, c, open)).join(''),
      prim = SHOP_PRIM.map(
        col => '<div class="vk">' + col.map(([l, c]) => this.grp(l, c, open)).join('') + '</div>'
      ).join('');
    /* escudos: dois cartões altos */
    const sh = Object.keys(SH)
      .map(k => {
        const s = SH[k],
          own = Inv.armor >= s.val,
          c = own ? 'own' : !open || s.price > Econ.c ? 'no' : '';
        return (
          '<div class="cd sd ' +
          c +
          '" data-s="' +
          k +
          '">' +
          ICON[k] +
          (own ? '<em>' + Math.min(Inv.armor, s.val) + '/' + s.val + '</em>' : '') +
          '<div class="ct"><b>' +
          s.n.toUpperCase() +
          '</b><span>' +
          (own ? 'COMPRADO' : '¤' + fmt(s.price)) +
          '</span></div></div>'
        );
      })
      .join('');
    $$('sb').innerHTML =
      '<div class="vb"><div class="vc vs">' +
      tab('PISTOLA') +
      '<div class="vk">' +
      side +
      '</div></div><div class="vc vp">' +
      tab('PRIMÁRIA') +
      '<div class="vr">' +
      prim +
      '</div></div><div class="vc vd">' +
      tab('ESCUDOS') +
      '<div class="vk"><div class="vg" style="flex:2 1 0"><div class="vh">CONTRA TODO DANO</div><div class="vl">' +
      sh +
      '</div></div></div></div></div>' +
      this.abilCol(open);
    this.info(WR[this.sel] && !WR[this.sel].melee ? this.sel : Weapon.cur);
  },
  /* habilidades do agente atual (smoke/flash são compradas em cargas) */
  abilCol(open) {
    const L = Abil.chgList();
    if (!L.length) return '';
    return (
      '<div class="vab"><div class="vh">HABILIDADES</div><div class="vl">' +
      L.map(i => {
        const a = Abil.ab[i],
          c = CHG[a.chg],
          n = Abil.st[i].n,
          full = n >= c.max,
          cls = full ? 'own' : !open || c.price > Econ.c ? 'no' : '',
          col = a.col || 0x52d6a3;
        return (
          '<div class="cd ab ' +
          cls +
          '" data-a="' +
          i +
          '"><svg viewBox="0 0 64 64" fill="none" stroke="' +
          hex6(col) +
          '" stroke-width="3" stroke-linejoin="round">' +
          IC[a.land && a.t === 'proj' ? a.land : a.t] +
          '</svg><div class="ct"><b>' +
          a.n.toUpperCase() +
          '</b><span>' +
          (full ? 'MÁXIMO' : '¤' + fmt(c.price)) +
          ' · ' +
          n +
          '/' +
          c.max +
          '</span></div></div>'
        );
      }).join('') +
      '</div></div>'
    );
  },
  /* vender (botão direito, só na fase de compra): devolve o preço cheio, como no Valorant */
  sell(id) {
    const w = WR[id];
    if (!w || w.melee || !Inv.owned[id]) return;
    if (Training.on) return toast('No treino as armas são livres');
    if (Round.phase !== 'buy') return toast('FASE DE COMPRA ENCERRADA');
    if (!w.price) return toast('Essa arma não pode ser vendida');
    Econ.add(w.price);
    delete Inv.owned[id];
    delete Weapon.ammo[id];
    if (Inv.slots[w.slot] === id) Inv.slots[w.slot] = w.slot === 'sec' ? 'classic' : null;
    if (Weapon.cur === id) Weapon.equip(Inv.slots.pri || Inv.slots.sec || Inv.slots.mel);
    Sfx.equip(id);
    Hud.flash();
    this.render();
  },
  buy(id) {
    const w = WR[id];
    if (w.melee) {
      KPick.id = id;
      Store.set('vdh_knife', id);
      Inv.owned[id] = 1;
      Weapon.give(id);
      Weapon.equip(id);
      Hud.flash();
      return this.render();
    } /* facas: grátis, trocam a qualquer hora */
    if (Inv.owned[id]) {
      Weapon.equip(id);
      Hud.flash();
      return this.render();
    }
    if (Round.phase !== 'buy') return toast('FASE DE COMPRA ENCERRADA');
    if (!this.ok(w)) return;
    if (!Econ.spend(w.price)) return toast('Créditos insuficientes');
    Inv.owned[id] = 1;
    Weapon.give(id);
    Weapon.equip(id);
    Hud.flash();
    this.render();
  },
  shield(k) {
    const s = SH[k];
    if (Round.phase !== 'buy') return toast('FASE DE COMPRA ENCERRADA');
    if (Inv.armor >= s.val) return toast('Armadura já equipada');
    if (!Econ.spend(s.price)) return toast('Créditos insuficientes');
    Inv.armor = Math.min(100, Math.max(Inv.armor, s.val));
    Hud.arm();
    this.render();
  }
};

const Hud = {
  cred() {
    $$('cred').textContent = fmt(Econ.c);
    if (Shop.on) Shop.render();
  },
  ammo() {
    const w = Weapon.w(),
      e = $$('am');
    if (w.melee) {
      e.innerHTML = '';
      return;
    }
    const a = Weapon.ammo[Weapon.cur];
    e.innerHTML =
      Weapon.rl > 0
        ? '<small>RECARREGANDO</small>'
        : '<b>' + a.mag + '</b><small>/ ' + a.res + '</small>';
  },
  weapon() {
    const w = Weapon.w();
    $$('cross').style.display = w.melee ? 'none' : '';
    this.ammo();
    if ($$('wlist').classList.contains('on')) this.list();
  },
  list() {
    let h = '';
    for (const s of ['sec', 'pri', 'mel']) {
      /* de cima para baixo: 1 pistola, 2 principal, 3 faca (igual às teclas) */
      const id = Inv.slots[s];
      if (!id) continue; /* sem arma na vaga = não aparece */
      h +=
        '<div class="wr' +
        (id === Weapon.cur ? ' sel' : '') +
        '"><div class="wc"><img src="' +
        Thumb.get(id) +
        '"><span class="nm">' +
        WR[id].name +
        '</span></div><i></i><em>' +
        SLOTN[s] +
        '</em></div>';
    }
    $$('wlist').innerHTML = h;
  },
  flash() {
    this.list();
    const e = $$('wlist');
    e.classList.add('on');
    clearTimeout(this.ft);
    this.ft = setTimeout(() => e.classList.remove('on'), 2500);
  },
  score() {
    $$('sA').textContent = Round.score.a;
    $$('sE').textContent = Round.score.e;
  },
  hp(v) {
    $$('hpn').textContent = Math.max(0, Math.round(v));
  },
  ability(i, o) {
    const e = $$('ab' + i);
    if (!e) return;
    o = o || {};
    e.querySelector('.ic').innerHTML = o.svg || '';
    e.classList.toggle('off', !o.ready);
  } /* ligue as habilidades aqui: Hud.ability(0,{svg:'<svg>…</svg>',ready:true}) */,
  arm() {
    $$('arm').textContent = Inv.armor;
    $$('armw').style.visibility = Inv.armor ? 'visible' : 'hidden';
  },
  hitmark(h) {
    const e = $$('hm');
    if (!e) return;
    e.firstElementChild.setAttribute('stroke', h ? '#ff3b3b' : '#fff');
    e.animate &&
      e.animate(
        [
          { opacity: 1, transform: 'scale(1.4)' },
          { opacity: 0, transform: 'scale(1)' }
        ],
        { duration: 280, easing: 'ease-out' }
      );
  },
  hurt(n) {
    const e = $$('hurt');
    e.animate &&
      e.animate([{ opacity: Math.min(1, 0.3 + n / 60) }, { opacity: 0 }], {
        duration: 650,
        easing: 'ease-out'
      });
  }
};
