/* ========= ESCOLHA DE AGENTE (antes de cada partida; não troca durante a partida) ========= */
const AGENTS = [
  {
    id: 'phoenix',
    name: 'Phoenix',
    role: 'Duelista',
    c: '#ff7a2f',
    d: 'O fogo é sua aliada. Cura-se em batalha e retorna à vida',
    i: '<path d="M32 6c4 10 14 14 14 28a14 14 0 0 1-28 0c0-8 5-11 7-17 3 3 4 6 4 9 3-5 4-12 3-20z"/>'
  },
  {
    id: 'neon',
    name: 'Neon',
    role: 'Duelista',
    c: '#a678ff',
    d: 'Energia em movimento. Corre e atordoa, velocidade letal',
    i: '<path d="M36 4L14 36h14l-4 24 26-34H34z"/>'
  },
  {
    id: 'jett',
    name: 'Jett',
    role: 'Duelista',
    c: '#4fa8ff',
    d: 'Ventos a seu favor. Salta, impulsiona e domina os ares',
    i: '<path d="M8 22h30a7 7 0 1 0-7-7M8 34h42a7 7 0 1 1-7 7M8 46h22"/>'
  },
  {
    id: 'omen',
    name: 'Omen',
    role: 'Controlador',
    c: '#8b93a7',
    d: 'Sombras caminham. Teleporta e obscurece a visão inimiga',
    i: '<path d="M32 5C19 9 15 22 15 34l-7 20 18-6h12l18 6-7-20C49 22 45 9 32 5z"/><path d="M25 30h4M35 30h4"/>'
  },
  {
    id: 'yoru',
    name: 'Yoru',
    role: 'Duelista',
    c: '#e5b93c',
    d: 'Engana e ataca pelas costas. Ilusões e portais confusos',
    i: '<ellipse cx="32" cy="32" rx="13" ry="26"/><ellipse cx="32" cy="32" rx="5" ry="13"/>'
  }
];
const Agents = {
  pick: null,
  cb: null,
  on: false,
  init() {
    $$('agGrid').innerHTML = AGENTS.map(
      (a, i) =>
        '<div class="ag" data-i="' +
        i +
        '" style="--c:' +
        a.c +
        '"><div class="pt"><svg viewBox="0 0 64 64">' +
        a.i +
        '</svg></div><b>' +
        a.name +
        '</b><i>' +
        a.role.toUpperCase() +
        '</i><p>' +
        a.d +
        '</p></div>'
    ).join('');
    try {
      const m = sessionStorage.getItem('agent'),
        i = AGENTS.findIndex(a => a.id === m);
      if (i >= 0) this.pick = i;
    } catch (e) {} /* lembra a escolha na sessão */
    $$('agGrid').onclick = e => {
      const c = e.target.closest('.ag');
      if (c) this.sel(+c.dataset.i, 1);
    };
    $$('agOk').onclick = () => this.ok();
    addEventListener('keydown', e => {
      if (!this.on) return;
      const k = e.key,
        n = this.pick;
      if (k === 'ArrowRight') this.sel(n === null ? 0 : Math.min(4, n + 1), 1);
      else if (k === 'ArrowLeft') this.sel(n === null ? 4 : Math.max(0, n - 1), 1);
      else if (k === 'Enter') this.ok();
      else if (/^[1-5]$/.test(k)) this.sel(+k - 1, 1);
      else if (k === 'Escape') this.cancel();
      else return;
      e.preventDefault();
    });
  },
  /* escolhe o agente i; fx=1 faz o efeito do palco 3D (clique/teclado) */
  sel(i, fx) {
    const changed = i !== this.pick;
    this.pick = i;
    [...$$('agGrid').children].forEach((c, j) => c.classList.toggle('on', j === i));
    $$('agOk').disabled = i === null;
    $$('agMsg').style.visibility = i === null ? 'visible' : 'hidden';
    this.info(i);
    if (this.on) {
      if (changed || !Stage.g) Stage.set(i === null ? null : AGENTS[i].id);
      if (fx && i !== null) Stage.react();
    }
  },
  /* painel com nome, função, descrição e habilidades do agente escolhido */
  info(i) {
    const a = i === null ? null : AGENTS[i];
    $$('agInfo').innerHTML = a
      ? '<small style="color:' +
        a.c +
        '">' +
        a.role.toUpperCase() +
        '</small><h2>' +
        a.name.toUpperCase() +
        '</h2><p>' +
        a.d +
        '</p>'
      : '';
  },
  open(cb) {
    this.on = true;
    this.cb = cb;
    $$('agents').classList.add('on');
    Stage.show(this.pick === null ? null : AGENTS[this.pick].id);
    this.sel(this.pick);
  },
  ok() {
    if (!this.on || this.pick === null) return;
    const a = AGENTS[this.pick],
      cb = this.cb;
    this.on = false;
    this.cb = null;
    $$('agents').classList.remove('on');
    Stage.hide();
    try {
      sessionStorage.setItem('agent', a.id);
    } catch (e) {}
    Game.agent = a.id;
    window.MAP && MAP.onAgent && MAP.onAgent(a);
    cb && cb();
  } /* gancho para habilidades/multiplayer */,
  cancel() {
    this.on = false;
    this.cb = null;
    $$('agents').classList.remove('on');
    Stage.hide();
    Menu.cancel();
  }
};
