/* ========= MENU DO ESC ========= */
const Pause = {
  on: false,
  lt: 0,
  init() {
    const lock = () =>
      renderer.domElement.requestPointerLock && renderer.domElement.requestPointerLock();
    $$('pRes').onclick = () => {
      this.hide();
      lock();
    };
    $$('pCfg').onclick = () => this.panel(1);
    $$('pBack').onclick = () => this.panel(0);
    $$('pExit').onclick = () => {
      this.hide();
      Menu.show();
    };
    document.addEventListener('pointerlockchange', () => {
      if (document.pointerLockElement) return;
      this.lt = performance.now();
      if (!Menu.on && !Shop.on && !this.on && !Round.done) this.show();
    }); /* ESC solta o mouse → abre o menu */
    addEventListener('keydown', e => {
      if (e.key !== 'Escape' || Menu.on || Round.done || performance.now() - this.lt < 250) return;
      if (Shop.on) Shop.toggle(0);
      else if (this.on) this.hide();
      else this.show();
    });
    cfgInit();
  },
  panel(c) {
    $$('pMain').style.display = c ? 'none' : '';
    $$('pSet').style.display = c ? '' : 'none';
    $$('pBox').classList.toggle('wide', !!c);
    if (c) Settings.mount($$('pSetHost'), 'inpause');
  },
  show() {
    this.on = true;
    this.panel(0);
    Weapon.trig(0);
    document.exitPointerLock && document.exitPointerLock();
    $$('pause').classList.add('on');
  },
  hide() {
    this.on = false;
    $$('pause').classList.remove('on');
  }
};
