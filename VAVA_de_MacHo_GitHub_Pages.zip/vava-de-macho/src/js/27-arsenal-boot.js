/* ========= ARSENAL (aba do menu principal): escolher a faca antes da partida ========= */
const ArMenu = {
  render() {
    const L = Object.values(WR).filter(w => w.melee);
    $$('arGrid').innerHTML = L.map(w => {
      const c = hex6(GP[w.id] ? GP[w.id].b : 0x7a8896);
      return (
        '<div class="ag' +
        (KPick.id === w.id ? ' on' : '') +
        '" data-id="' +
        w.id +
        '" style="--c:' +
        c +
        '"><div class="pt"><img src="' +
        Thumb.get(w.id) +
        '"></div><b>' +
        w.name +
        '</b><i>FACA</i><p>' +
        (KPick.id === w.id ? 'EQUIPADA' : 'Clique para equipar') +
        '</p></div>'
      );
    }).join('');
  },
  init() {
    $$('arGrid').onclick = e => {
      const c = e.target.closest('.ag');
      if (!c) return;
      const id = c.dataset.id;
      KPick.id = id;
      Store.set('vdh_knife', id);
      if (Inv.owned[id] === undefined) Inv.owned[id] = 1;
      Inv.slots.mel = id;
      this.render();
      toast('Faca equipada: ' + WR[id].name);
    };
  }
};
/* Tela de carregamento: aparece DEPOIS do login, cobre o tempo de gerar o mapa e some com fade quando
   passarem 2,5 s desde que apareceu E o jogo estiver pronto (vale o que demorar mais). */
const Loader = {
  MIN: 2500,
  /* mostra a tela de carregamento (depois do login) e marca a hora de início */
  show() {
    const el = $$('loader');
    window.__ldT0 = performance.now();
    if (el) el.classList.remove('hid');
  },
  done() {
    const el = $$('loader');
    if (!el) return;
    const t0 = window.__ldT0 || 0;
    const wait = Math.max(0, this.MIN - (performance.now() - t0));
    setTimeout(() => {
      el.classList.add('out');
      setTimeout(() => el.remove(), 700);
    }, wait);
  }
};
