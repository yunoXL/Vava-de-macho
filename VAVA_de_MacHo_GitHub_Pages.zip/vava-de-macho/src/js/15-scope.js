/* ========= LUNETA (Operator): botão direito = mira, roda do mouse = alterna 2.5x / 5x ========= */
const Scope = {
  on: 0,
  t: 0,
  base: 80,
  zi: 0,
  Z: [2.5, 5],
  sk: 1,
  kick: 0,
  sx: 0,
  sy: 0,
  ph: 0,
  vh: 0,
  ch: 0,
  update(dt) {
    const w = Weapon.w(),
      on =
        !Menu.on &&
        !Pause.on &&
        !Shop.on &&
        w.scope &&
        Weapon.ads &&
        Weapon.rl <= 0 &&
        !(Abil.ae && Abil.ae.ch < 0)
          ? 1
          : 0,
      el = $$('scope');
    if (on && !this.on) $$('scopeZ').textContent = this.Z[this.zi] + 'x';
    if (on !== this.on) Sfx.scope(on);
    this.on = on;
    this.t = Math.max(
      0,
      Math.min(1, this.t + (on ? dt / 0.14 : -dt / 0.09))
    ); /* entra em ~140ms, sai em ~90ms */
    const k = this.t * this.t * (3 - 2 * this.t);
    this.kick = Math.max(0, this.kick - dt * 6);
    if (this.t > 0) {
      el.style.display = 'block';
      el.style.opacity = (w.zo ? 0 : k).toFixed(3); /* Guardian: só zoom, sem a tela preta */
      el.style.transform = 'scale(' + (1.14 - 0.14 * k + this.kick * 0.02).toFixed(4) + ')';
    } else if (el.style.display !== 'none') el.style.display = 'none';
    const hide = !w.zo && this.t > 0.55; /* arma some quando a luneta já cobre a tela */
    if (hide !== !!this.vh) {
      this.vh = hide;
      if (Weapon.vm) Weapon.vm.visible = !hide && !(Abil.kn > 0 || Abil.lg);
    }
    if (hide && Weapon.vm && Weapon.vm.visible) Weapon.vm.visible = false;
    if (this.t > 0.02 && !w.zo) {
      this.ch = 1;
      $$('cross').style.display = 'none';
    } else if (this.ch) {
      this.ch = 0;
      Hud.weapon();
    }
    const tf = on ? this.base / this.Z[this.zi] : this.base; /* zoom suave */
    if (Math.abs(camera.fov - tf) > 0.05) {
      camera.fov += (tf - camera.fov) * (1 - Math.exp(-30 * dt));
      if (Math.abs(camera.fov - tf) < 0.05) camera.fov = tf;
      camera.updateProjectionMatrix();
    }
    this.sk = camera.fov / this.base; /* sensibilidade proporcional ao zoom */
    /* balanço leve de respiração, maior ao andar */
    this.ph += dt;
    const a = k * (0.0006 + Weapon.sf() * 0.0016) * (this.Z[this.zi] / 2.5);
    this.sx = (Math.sin(this.ph * 1.3) + Math.sin(this.ph * 2.9) * 0.4) * a;
    this.sy = Math.cos(this.ph * 1.7) * a * 0.8;
  },
  zoom() {
    if (!this.on) return;
    this.zi = (this.zi + 1) % this.Z.length;
    Sfx.scope(1);
    const z = $$('scopeZ');
    z.textContent = this.Z[this.zi] + 'x';
    z.animate &&
      z.animate(
        [
          { opacity: 1, transform: 'translateX(-50%) scale(1.5)' },
          { opacity: 0.7, transform: 'translateX(-50%) scale(1)' }
        ],
        { duration: 240, easing: 'ease-out' }
      );
  }
};
addEventListener(
  'wheel',
  e => {
    if (Scope.on && document.pointerLockElement) {
      e.preventDefault();
      Scope.zoom();
    }
  },
  { passive: false }
);
