/* ========= SISTEMAS DE JOGO: economia, rodadas, loja, armas, recoil, mira, controles =========
   Preços e lados de compra vêm do seu catálogo. Todo valor marcado PROVISÓRIO NÃO existia no projeto
   (não havia armas/economia): é só um ponto de partida jogável — ajuste aqui, em um único lugar. */
const rad = d => (d * Math.PI) / 180,
  $$ = id => document.getElementById(id),
  fmt = n => n.toLocaleString('pt-BR'),
  fmtT = s => Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
const CFG = {
  buyTime: 30,
  barrierFade: 0.8,
  startCredits: 800,
  winReward: 3000,
  lossReward: 1900,
  creditCap: 9000,
  roundTime: 100
}; /* PROVISÓRIO */
const CROSS = {
  color: '#ffffff',
  thick: 2,
  len: 9,
  gap: 3,
  dot: true,
  lines: true,
  out: true,
  alpha: 100,
  dotS: 2
};
/* id,nome,categoria,preço,lado,auto,cadência(tiros/s),carregador,reserva,recarga(s),dano,cabeça,penetração, recoil{v,h,rec,mv,ads,ramp}, abertura-base(°), cor */
const mk = (
  id,
  name,
  cat,
  price,
  side,
  auto,
  rate,
  mag,
  res,
  rld,
  dmg,
  head,
  pen,
  v,
  h,
  rec,
  mv,
  ads,
  ramp,
  sp,
  col
) => ({
  id,
  name,
  cat,
  price,
  side,
  auto,
  rate,
  mag,
  res,
  rld,
  dmg,
  head,
  pen,
  slot: cat === 'Pistolas' ? 'sec' : 'pri',
  recoil: { v, h, rec, mv, ads, ramp },
  sp,
  col
});
const WeaponRegistry = {
  /* PROVISÓRIO: cadência, carregador, reserva, recarga, dano, penetração e recoil */
  classic: mk(
    'classic',
    'Classic',
    'Pistolas',
    0,
    'both',
    0,
    6.75,
    12,
    36,
    1.75,
    26,
    78,
    'média',
    0.9,
    0.25,
    7,
    1.5,
    0.8,
    0.05,
    0.25,
    0x8a94a0
  ),
  ghost: mk(
    'ghost',
    'Ghost',
    'Pistolas',
    500,
    'both',
    0,
    6.75,
    13,
    39,
    1.5,
    30,
    105,
    'média',
    1,
    0.2,
    8,
    1.4,
    0.75,
    0.04,
    0.2,
    0x9aa7b4
  ),
  frenzy: mk(
    'frenzy',
    'Frenzy',
    'Pistolas',
    450,
    'both',
    1,
    10,
    15,
    45,
    1.5,
    26,
    78,
    'baixa',
    0.75,
    0.45,
    5,
    1.6,
    0.8,
    0.12,
    0.35,
    0xb08f6a
  ),
  sheriff: mk(
    'sheriff',
    'Sheriff',
    'Pistolas',
    800,
    'both',
    0,
    4,
    6,
    18,
    2.2,
    55,
    159,
    'média',
    2.2,
    0.3,
    9,
    1.5,
    0.7,
    0,
    0.15,
    0xc9a45a
  ),
  spectre: mk(
    'spectre',
    'Spectre',
    'SMGs',
    1600,
    'both',
    1,
    13.3,
    30,
    90,
    2.25,
    26,
    78,
    'baixa',
    0.45,
    0.25,
    6.5,
    1.3,
    0.8,
    0.07,
    0.3,
    0x6f8fa8
  ),
  stinger: mk(
    'stinger',
    'Stinger',
    'SMGs',
    1100,
    'both',
    1,
    16,
    20,
    60,
    2.25,
    27,
    67,
    'baixa',
    0.95,
    0.6,
    4,
    1.7,
    0.85,
    0.16,
    0.4,
    0xb5575a
  ),
  phantom: mk(
    'phantom',
    'Phantom',
    'Rifles',
    2900,
    'both',
    1,
    11,
    30,
    90,
    2.5,
    39,
    156,
    'média',
    0.5,
    0.22,
    6,
    1.4,
    0.75,
    0.07,
    0.2,
    0x5a7bb0
  ),
  vandal: mk(
    'vandal',
    'Vandal',
    'Rifles',
    2900,
    'both',
    1,
    9.75,
    25,
    75,
    2.5,
    40,
    160,
    'média',
    0.7,
    0.35,
    5,
    1.6,
    0.75,
    0.1,
    0.18,
    0xb0644a
  ),
  knife: {
    id: 'knife',
    name: 'Faca Tática',
    cat: 'Facas',
    price: 0,
    side: 'both',
    auto: 0,
    rate: 1.3,
    mag: 0,
    res: 0,
    rld: 0,
    dmg: 50,
    head: 50,
    pen: '—',
    slot: 'mel',
    recoil: { v: 0, h: 0, rec: 5, mv: 1, ads: 1, ramp: 0 },
    sp: 0,
    col: 0xc9d2da,
    melee: 1
  },
  operator: Object.assign(
    mk(
      'operator',
      'Operator',
      'Snipers',
      4700,
      'both',
      0,
      0.75,
      5,
      10,
      3.7,
      150,
      255,
      'alta',
      3,
      0.15,
      7,
      2.2,
      0.3,
      0,
      0.1,
      0x6a8a5a
    ),
    { scope: 1 }
  )
};
/* ===== armas que faltavam do Valorant (v0.0.10). Valores do jogo real (patch 12.x); PROVISÓRIO = estimado.
   Campos extras além do mk():  pel = projéteis por tiro (dmg/head valem POR projétil) · fall = [m cheio, m mínimo]
   (o dano cai até 20% entre as duas distâncias) · burst = tiros da rajada ao mirar · arate = cadência ao mirar ·
   spool = cadência após 8 tiros seguidos · tight = quanto a abertura fecha no tiro contínuo · zoom = níveis da luneta
   · zo = só zoom, sem a tela preta · hip = abertura sem mirar (luneta) · rld1 = recarga com 1 na câmara · spd = velocidade */
Object.assign(WeaponRegistry, {
  shorty: Object.assign(
    mk('shorty', 'Shorty', 'Pistolas', 300, 'both', 0, 3.3, 2, 6, 1.75, 12, 24, 'baixa', 0.6, 0.2, 6, 1.4, 0.9, 0, 3.4, 0xd08a3a),
    { pel: 12, fall: [7, 15] }
  ),
  bandit: mk('bandit', 'Bandit', 'Pistolas', 600, 'both', 0, 6, 8, 24, 1.5, 45, 140, 'média', 1.0, 0.3, 8, 1.5, 0.75, 0, 0.2, 0xe05a9a) /* dano PROVISÓRIO: mata com 1 headshot em escudo leve */,
  bucky: Object.assign(
    mk('bucky', 'Bucky', 'Shotguns', 850, 'both', 0, 1.1, 5, 15, 2.5, 22, 44, 'baixa', 2.4, 0.3, 5, 1.4, 0.45, 0, 3.0, 0xb8873a),
    { pel: 15, fall: [8, 17] } /* mirar = rajada de ar: pellets mais juntos */
  ),
  judge: Object.assign(
    mk('judge', 'Judge', 'Shotguns', 1850, 'both', 1, 3.5, 7, 21, 2.2, 17, 34, 'média', 1.6, 0.4, 5, 1.5, 0.9, 0, 3.4, 0xe8622a),
    { pel: 12, fall: [10, 20] }
  ),
  bulldog: Object.assign(
    mk('bulldog', 'Bulldog', 'Rifles', 2050, 'both', 1, 9.15, 24, 72, 2.5, 35, 116, 'média', 0.6, 0.3, 5, 1.6, 0.6, 0.09, 0.2, 0x7a8fd8),
    { burst: 3 } /* mirar = rajada de 3 */
  ),
  guardian: Object.assign(
    mk('guardian', 'Guardian', 'Rifles', 2250, 'both', 0, 6.5, 12, 36, 2.5, 65, 195, 'média', 1.2, 0.2, 6, 1.7, 0.5, 0, 0.1, 0x8a5ce6),
    { scope: 1, zoom: [1.5], zo: 1, hip: 1.2 }
  ),
  marshal: Object.assign(
    mk('marshal', 'Marshal', 'Snipers', 950, 'both', 0, 1.5, 5, 10, 2.5, 101, 202, 'média', 2, 0.1, 7, 2.2, 0.3, 0, 0.1, 0x3aa86a),
    { scope: 1, zoom: [2.5] }
  ),
  outlaw: Object.assign(
    mk('outlaw', 'Outlaw', 'Snipers', 2400, 'both', 0, 2.75, 2, 10, 3.8, 140, 238, 'alta', 2.4, 0.2, 6, 2.2, 0.3, 0, 0.1, 0xc8a02a),
    { scope: 1, zoom: [3.5], hip: 3.5, rld1: 2.3 }
  ),
  ares: Object.assign(
    mk('ares', 'Ares', 'Heavy', 1600, 'both', 1, 13, 50, 100, 3.25, 30, 72, 'alta', 0.5, 0.3, 4, 2, 0.8, 0, 0.45, 0x5a8a5a),
    { arate: 10, tight: 0.55, spd: 0.95 } /* fica mais precisa quanto mais atira */
  ),
  odin: Object.assign(
    mk('odin', 'Odin', 'Heavy', 3200, 'both', 1, 12, 100, 100, 5, 38, 95, 'alta', 0.5, 0.35, 4, 2.2, 0.85, 0, 0.5, 0xc83a3a),
    { arate: 15.6, spool: 15.6, spd: 0.94 } /* acelera após 8 tiros; mirando já começa no máximo */
  )
});
for (const [id, name, col] of [
  ['karambit', 'Karambit', 0xd9344a],
  ['kukri', 'Kukri', 0xc8923a],
  ['kunai', 'Kunai', 0x8a8f4a],
  ['tanto', 'Tanto', 0x4a5bd8],
  ['butterfly', 'Butterfly', 0xb44cff]
])
  WeaponRegistry[id] = Object.assign({}, WeaponRegistry.knife, { id, name, col });
const WR = WeaponRegistry,
  SH = {
    light: { n: 'Escudo Leve', price: 400, val: 25 },
    heavy: { n: 'Escudo Pesado', price: 1000, val: 100 }
  };
const KPick = {
  id: 'knife',
  /* lê a faca escolhida (da conta ou do convidado); chamado depois do login */
  load() {
    const k = Store.get('vdh_knife');
    this.id = k && WR[k] && WR[k].melee ? k : 'knife';
  }
};
let tT;
function toast(m) {
  const t = $$('toast');
  t.textContent = m;
  t.classList.add('on');
  clearTimeout(tT);
  tT = setTimeout(() => t.classList.remove('on'), 1400);
}
