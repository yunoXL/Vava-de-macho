/* ========= CIDADE ITALIANA v0.85: fachadas, telhados, campanário, caixas variadas e props temáticos ========= */
const RNG = (a => () => {
  a |= 0;
  a = (a + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
})(7);
const PAL = [
  ['#e3b872', '#3f6b4e', 0],
  ['#b4553a', '#6b4430', 1],
  ['#d8cdb2', '#3d5f86', 2],
  ['#d98e63', '#6b4430', 3],
  ['#eadfc4', '#3d5f86', 4],
  ['#c9cfa8', '#7a3b2e', 5]
];
function facadeTex(base, shut, st) {
  const drawTile = (x, w, h, feat) => {
    /* 6 m x 4,5 m por andar; y=0 é a base. 6 estilos: reboco com tijolo aparente, tijolo, pedra, portão, pilastras, trepadeira */
    x.fillStyle = base;
    x.fillRect(0, 0, w, h);
    speckle(x, w, h, 1200, 0.04);
    stains(x, w, h, 6);
    const R = (a, b) => a + Math.random() * (b - a);
    const brick = (y0, y1, c, x0 = -1, x1 = 9) => {
      for (let r = 0, y = y0; y < y1; r++, y += 14)
        for (let i = x0; i < x1; i++) {
          const v = R(-13, 13);
          x.fillStyle = 'rgb(' + (c[0] + v) + ',' + (c[1] + v * 0.6) + ',' + (c[2] + v * 0.5) + ')';
          x.fillRect(i * 32 + (r % 2 ? 16 : 0) + 1, y + 1, 30, 12);
        }
    };
    const blocks = (y0, y1, c) => {
      for (let r = 0, y = y0; y < y1; r++, y += 28)
        for (let i = -1; i < 5; i++) {
          const v = R(-11, 11);
          x.fillStyle = 'rgb(' + (c[0] + v) + ',' + (c[1] + v) + ',' + (c[2] + v) + ')';
          x.fillRect(i * 64 + (r % 2 ? 32 : 0) + R(0, 6) + 2, y + 2, 60, 24);
        }
    };
    const win = (cx, y0, hh, sh, arch) => {
      x.fillStyle = '#f1e8d2';
      x.fillRect(cx - 24, y0 - 8, 48, 8);
      x.fillRect(cx - 22, y0, 44, hh);
      if (arch) {
        x.beginPath();
        x.arc(cx, y0 + hh, 22, 0, Math.PI);
        x.fill();
      }
      x.fillStyle = '#24303a';
      x.fillRect(cx - 16, y0 + 2, 32, hh - 2);
      if (arch) {
        x.beginPath();
        x.arc(cx, y0 + hh, 16, 0, Math.PI);
        x.fill();
      }
      if (sh) {
        x.fillStyle = sh;
        x.fillRect(cx - 38, y0 + 2, 15, hh + 4);
        x.fillRect(cx + 23, y0 + 2, 15, hh + 4);
        x.strokeStyle = 'rgba(0,0,0,.35)';
        for (let k = 0; k < 10; k++) {
          const yy = y0 + 6 + k * (hh / 10);
          x.beginPath();
          x.moveTo(cx - 38, yy);
          x.lineTo(cx - 23, yy);
          x.moveTo(cx + 23, yy);
          x.lineTo(cx + 38, yy);
          x.stroke();
        }
      }
    };
    if (st === 0) {
      for (let k = 0; k < 3; k++) {
        const px = R(10, 190),
          py = R(8, 90);
        x.save();
        x.beginPath();
        x.rect(px, py, R(40, 70), R(30, 50));
        x.clip();
        brick(py - 14, py + 60, [170, 92, 64], 0, 9);
        x.restore();
      } /* reboco caindo, tijolo aparente */
      blocks(0, 18, [140, 128, 110]);
      if (feat) win(128, 125, 90, shut, 1);
    }
    if (st === 1) {
      brick(0, 236, [158, 78, 52]);
      if (feat) {
        x.fillStyle = '#2e2018';
        x.beginPath();
        x.arc(64, 95, 26, Math.PI, 0);
        x.fill();
        x.fillRect(38, 0, 52, 95); /* portão de madeira em arco */
        x.fillStyle = '#6a4426';
        for (let k = 0; k < 6; k++) x.fillRect(40 + k * 8, 2, 6, 92);
        x.fillStyle = '#14100c';
        x.fillRect(192 - 14, 150, 28, 40);
        x.fillRect(192 - 10, 154, 20, 32);
      }
    }
    if (st === 2) {
      blocks(0, 240, [196, 184, 160]);
      if (feat) {
        win(70, 130, 70, 0, 1);
        x.fillStyle = '#23262a';
        x.fillRect(190, 130, 5, 40);
        x.fillRect(184, 168, 20, 4); /* arandela */
        const g = x.createRadialGradient(193, 182, 0, 193, 182, 16);
        g.addColorStop(0, 'rgba(255,214,120,.9)');
        g.addColorStop(1, 'rgba(255,214,120,0)');
        x.fillStyle = g;
        x.fillRect(170, 160, 48, 48);
      }
    }
    if (st === 3 && feat) {
      x.fillStyle = 'rgba(0,0,0,.22)';
      x.fillRect(78, 0, 100, 118);
      x.fillStyle = '#4a3020';
      x.fillRect(84, 0, 88, 108);
      x.beginPath();
      x.arc(128, 108, 44, Math.PI, 0, true);
      x.fill(); /* portão grande */
      x.fillStyle = '#2c1c12';
      for (let k = 0; k < 7; k++) x.fillRect(86 + k * 12, 2, 2, 106);
      x.fillStyle = '#b5a283';
      for (let k = 0; k < 4; k++)
        for (let j = 0; j < 5; j++) {
          x.beginPath();
          x.arc(98 + k * 20, 12 + j * 20, 2.5, 0, 7);
          x.fill();
        }
      win(128, 160, 60, shut, 0);
    }
    if (st === 4) {
      x.fillStyle = 'rgba(255,255,255,.35)';
      x.fillRect(0, 0, 14, h);
      x.fillRect(w - 14, 0, 14, h);
      x.fillStyle = 'rgba(0,0,0,.14)';
      x.fillRect(14, 0, 3, h);
      x.fillRect(w - 17, 0, 3, h); /* pilastras */
      x.fillStyle = 'rgba(255,255,255,.4)';
      x.fillRect(0, 100, w, 8);
      if (feat) win(128, 135, 70, 0, 1);
      blocks(0, 16, [150, 140, 125]);
    }
    if (st === 5) {
      x.fillStyle = 'rgba(0,0,0,.1)';
      for (let y = 10; y < 108; y += 18) {
        x.fillRect(0, y, w, 3);
      }
      x.fillStyle = '#4d4a45';
      x.fillRect(196, 0, 8, h);
      x.fillStyle = 'rgba(255,255,255,.2)';
      x.fillRect(198, 0, 2, h); /* friso + calha */
      if (feat) {
        win(60, 125, 80, shut, 1);
        for (let k = 0; k < 70; k++) {
          x.fillStyle = 'hsl(' + R(90, 130) + ',45%,' + R(24, 40) + '%)';
          x.beginPath();
          x.arc(R(100, 190), R(120, 236) * (Math.random() < 0.4 ? 0.7 : 1), R(3, 8), 0, 7);
          x.fill();
        }
      }
    } /* trepadeira */
    const gr = x.createLinearGradient(0, 0, 0, 50);
    gr.addColorStop(0, 'rgba(40,28,18,.35)');
    gr.addColorStop(1, 'rgba(40,28,18,0)');
    x.fillStyle = gr;
    x.fillRect(0, 0, w, 50); /* sujeira na base */
    x.strokeStyle = 'rgba(40,28,20,.16)';
    x.lineWidth = 1.3;
    for (let k = 0; k < 3; k++) {
      let cx = R(0, w),
        cy = R(20, 200);
      x.beginPath();
      x.moveTo(cx, cy);
      for (let j = 0; j < 6; j++) {
        cx += R(-8, 8);
        cy += R(6, 16);
        x.lineTo(cx, cy);
      }
      x.stroke();
    } /* rachaduras */
    x.fillStyle = 'rgba(236,226,206,.3)';
    x.fillRect(0, 0, w, h); /* véu claro: menos contraste, o inimigo se destaca */
    x.fillStyle = '#f1e7d0';
    x.fillRect(0, h - 14, w, 14);
    x.fillStyle = 'rgba(0,0,0,.25)';
    x.fillRect(0, h - 18, w, 4);
  };
  /* textura 12 m x 9 m: só UM detalhe (janela/portão) por trecho, o resto é parede lisa com desgaste → bem menos janelas */
  const t = canvasTex(
    512,
    512,
    x => {
      const mk = f => {
        const c = document.createElement('canvas');
        c.width = c.height = 256;
        drawTile(c.getContext('2d'), 256, 256, f);
        return c;
      };
      const fi = Math.random() < 0.5 ? 0 : 1,
        fj = st === 1 || st === 3 ? 0 : 1;
      for (let i = 0; i < 2; i++)
        for (let j = 0; j < 2; j++) x.drawImage(mk(i === fi && j === fj), i * 256, j * 256);
    },
    1 / 12,
    1 / 9
  );
  t.offset.y = -1 / 9;
  return t;
}
const bboxOf = p =>
  p.reduce(
    (b, q) => [
      Math.min(b[0], q[0]),
      Math.min(b[1], q[1]),
      Math.max(b[2], q[0]),
      Math.max(b[3], q[1])
    ],
    [1e9, 1e9, -1e9, -1e9]
  );
const areaOf = p =>
  Math.abs(
    p.reduce((s, q, i) => {
      const r = p[(i + 1) % p.length];
      return s + q[0] * r[1] - r[0] * q[1];
    }, 0) / 2
  );
function poleOf(p) {
  const b = bboxOf(p);
  let best = [0, 0, -1];
  for (let i = 0; i <= 24; i++)
    for (let j = 0; j <= 24; j++) {
      const x = b[0] + ((b[2] - b[0]) * i) / 24,
        y = b[1] + ((b[3] - b[1]) * j) / 24;
      if (!inPoly(x, y, p)) continue;
      const d = polyDist(x, y, p);
      if (d > best[2]) best = [x, y, d];
    }
  return best;
}
function buildCity() {
  tex.roof = canvasTex(
    128,
    128,
    (x, w, h) => {
      x.fillStyle = '#8f3d26';
      x.fillRect(0, 0, w, h);
      for (let r = 0; r < 8; r++)
        for (let i = 0; i < 9; i++) {
          x.fillStyle =
            'hsl(' +
            (12 + Math.random() * 10) +
            ',' +
            (55 + Math.random() * 15) +
            '%,' +
            (36 + Math.random() * 12) +
            '%)';
          x.beginPath();
          x.arc(i * 16 + (r % 2 ? 8 : 0), r * 16 + 8, 9, 0, Math.PI);
          x.fill();
        }
      speckle(x, w, h, 300, 0.1);
    },
    1 / 3,
    1 / 3
  );
  const roof = new THREE.MeshStandardMaterial({ map: tex.roof, roughness: 0.85 }),
    FM = PAL.map(
      ([c, s, st]) =>
        new THREE.MeshStandardMaterial({
          map: facadeTex(c, s, st),
          roughness: 0.92,
          side: THREE.DoubleSide
        })
    );
  const M = (c, r, m) =>
      new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m || 0 }),
    chim = M(0x9a4a30, 0.9);
  const shell = new THREE.Shape(
    [
      [-900, -900],
      [3200, -900],
      [3200, 2600],
      [-900, 2600]
    ].map(V)
  );
  shell.holes.push(new THREE.Path(LAYOUT.outer.map(V)));
  EXTRA.push(extrude(shell, 12, [roof, FM[0]]));
  addEdges(LAYOUT.outer);
  const big = LAYOUT.solids.map((p, i) => [areaOf(p), i]).sort((a, b) => b[0] - a[0])[0][1],
    hs = [];
  LAYOUT.solids.forEach((poly, i) => {
    const H = i === big ? 16 : 8 + RNG() * 8;
    hs[i] = H;
    EXTRA.push(extrude(new THREE.Shape(poly.map(V)), H, [roof, FM[(i * 5 + 1) % FM.length]]));
    addEdges(poly);
    const g = new THREE.Group(),
      b = bboxOf(poly);
    for (let c = 0, n = 1 + ((RNG() * 3) | 0); c < n; c++)
      for (let t = 0; t < 25; t++) {
        const x = b[0] + RNG() * (b[2] - b[0]),
          y = b[1] + RNG() * (b[3] - b[1]);
        if (inPoly(x, y, poly) && polyDist(x, y, poly) > 30) {
          const k = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.8, 0.7), chim);
          k.position.set(x * S, H + 0.9, y * S);
          k.castShadow = true;
          g.add(k);
          break;
        }
      }
    scene.add(g);
  });
  /* campanário com relógio no prédio mais próximo do centro */
  const c0 = LAYOUT.center || [1100, 850],
    cand = LAYOUT.solids
      .map((p, i) => [poleOf(p), i])
      .filter(([q]) => q[2] > 110)
      .sort(
        (a, b) =>
          Math.hypot(a[0][0] - c0[0], a[0][1] - c0[1]) -
          Math.hypot(b[0][0] - c0[0], b[0][1] - c0[1])
      )[0];
  if (cand) {
    const [[px, py], i] = cand,
      r = 2.1 / S,
      H = hs[i];
    EXTRA.push(
      extrude(
        new THREE.Shape(
          [
            [px - r, py - r],
            [px + r, py - r],
            [px + r, py + r],
            [px - r, py + r]
          ].map(V)
        ),
        32 - H,
        [roof, FM[2]]
      ).translateY(H)
    );
    const cone = new THREE.Mesh(new THREE.ConeGeometry(3.3, 7, 4), M(0x4f8a74, 0.6, 0.3));
    cone.rotation.y = Math.PI / 4;
    cone.position.set(px * S, 32 + 3.5, py * S);
    cone.castShadow = true;
    scene.add(cone);
    const ck = new THREE.CanvasTexture(
      (() => {
        const c = document.createElement('canvas');
        c.width = c.height = 128;
        const x = c.getContext('2d');
        x.fillStyle = '#f6efd8';
        x.beginPath();
        x.arc(64, 64, 60, 0, 7);
        x.fill();
        x.strokeStyle = '#2b2118';
        x.lineWidth = 5;
        x.stroke();
        for (let k = 0; k < 12; k++) {
          const a = (k * Math.PI) / 6;
          x.beginPath();
          x.moveTo(64 + Math.cos(a) * 48, 64 + Math.sin(a) * 48);
          x.lineTo(64 + Math.cos(a) * 56, 64 + Math.sin(a) * 56);
          x.stroke();
        }
        x.lineWidth = 6;
        x.beginPath();
        x.moveTo(64, 64);
        x.lineTo(64, 24);
        x.moveTo(64, 64);
        x.lineTo(92, 76);
        x.stroke();
        return c;
      })()
    );
    for (let k = 0; k < 4; k++) {
      const f = new THREE.Mesh(
          new THREE.PlaneGeometry(2.6, 2.6),
          new THREE.MeshBasicMaterial({ map: ck, side: THREE.DoubleSide })
        ),
        a = (k * Math.PI) / 2;
      f.position.set(px * S + Math.cos(a) * 2.14, 27, py * S + Math.sin(a) * 2.14);
      f.rotation.y = Math.PI / 2 - a;
      scene.add(f);
    }
  }
}
function italianizeLayout() {
  if (LAYOUT._it) return;
  LAYOUT._it = 1;
  const wd = THREE.MeshStandardMaterial,
    wood = tex.wood,
    mar = tex.marble;
  mats.V = new wd({ map: wood, color: 0xc79a66, roughness: 0.9 });
  mats.X = new wd({ map: wood, color: 0x8a6a4a, roughness: 0.9 });
  mats.M = new wd({ map: mar, color: 0xe0dacb, roughness: 0.5 });
  mats.N = new wd({ map: mar, color: 0xcfc8b8, roughness: 0.55 });
  mats.K = new wd({ map: mar, color: 0xa49d8d, roughness: 0.7 });
  const T = [
    ['V', 1, 1],
    ['V', 1.3, 0.9],
    ['W', 1.5, 1.5],
    ['X', 1.7, 1.7],
    ['M', 2.3, 1.2],
    ['N', 3.4, 1],
    ['K', 1.2, 1.2],
    ['T', 2, 2],
    ['G', 1.4, 1.4],
    ['M', 1.6, 1.6],
    ['V', 0.8, 0.8],
    ['N', 2.6, 0.9]
  ];
  const TAC = [
    /* [x,y (px), largura m, profundidade m, tipo] — cobertura tática posicionada à mão */
    /* B: cobertura de plant, esconderijos e off-angle na saída do Link */
    [340, 630, 2.3, 1.2, 'M'],
    [470, 765, 1.7, 1.7, 'X'],
    [570, 640, 1.2, 1.2, 'K'],
    [300, 740, 1, 1, 'V'],
    [690, 820, 1.3, 1.3, 'X'],
    /* rota do B (atacantes): bancos de espera antes do Link (smoke/flash) */
    [600, 1000, 2.6, 0.9, 'N'],
    [690, 1000, 1, 1, 'V'],
    [745, 1560, 1, 1, 'V'],
    /* A: plant, caixa alta no fundo, pilar no nicho, banco de trade */
    [2050, 780, 1.4, 1.4, 'X'],
    [1900, 990, 3.4, 1, 'N'],
    [2100, 960, 1.2, 1.2, 'K'],
    [1860, 690, 2.3, 1.2, 'M'],
    /* corredor leste (rush A) e saída leste: cobertura escalonada, sem fechar a rota */
    [1650, 1500, 1.6, 1.6, 'X'],
    [1700, 1360, 2.3, 1.2, 'M'],
    [1420, 1625, 2.6, 0.9, 'N'],
    /* mid: bolsão com ângulos cruzados e domínio do centro */
    [1100, 1250, 2.3, 1.2, 'M'],
    [1280, 1330, 1.6, 1.6, 'X'],
    [1180, 1120, 1.2, 1.2, 'K'],
    [1140, 870, 1.3, 1.3, 'X'],
    /* lado defensor: saídas com trocação cruzada */
    [1130, 545, 1.7, 1.7, 'X'],
    [1000, 420, 2.3, 1.2, 'M'],
    [1500, 430, 2.3, 1.2, 'M'],
    [1700, 430, 1, 1, 'V']
  ];
  LAYOUT.doors = [
    /* defensores: fecham o Mid e o A longo (interruptor do lado deles) · atacantes: fecham o Beco do B (interruptor do lado deles) */
    { name: 'Portão do Mid', a: [1060, 610], b: [1155, 610], sw: [1064, 570] },
    { name: 'Portão do A Longo', a: [1595, 1290], b: [1750, 1290], sw: [1600, 1262] },
    { name: 'Porta do Beco B', a: [455, 1100], b: [530, 1100], sw: [459, 1128] }
  ];
  const man = TAC.map(([x, y, w, d, t]) => [
      x - w / S / 2,
      y - d / S / 2,
      x + w / S / 2,
      y + d / S / 2,
      t
    ]),
    near = (x, y) =>
      man.some(b => x > b[0] - 60 && x < b[2] + 60 && y > b[1] - 60 && y < b[3] + 60);
  const out = man.slice(),
    put = (x, y) => {
      if (near(x, y)) return;
      const [t, a, b] = T[(RNG() * T.length) | 0],
        sw = RNG() < 0.5,
        w = (sw ? b : a) / S / 2,
        d = (sw ? a : b) / S / 2;
      out.push([x - w, y - d, x + w, y + d, t]);
    };
  for (const b of LAYOUT.boxes) put((b[0] + b[2]) / 2, (b[1] + b[3]) / 2);
  const sp = Object.values(LAYOUT.spawns).map(s => s.rect),
    st = [LAYOUT.sites.A, LAYOUT.sites.B];
  for (let n = 0; n < 5000 && out.length < 105; n++) {
    const x = 100 + RNG() * 2100,
      y = 100 + RNG() * 2200;
    if (
      near(x, y) ||
      inWall(x, y) ||
      wallDist(x, y) < 55 ||
      barrierDist(x, y) < 90 ||
      st.some(s => Math.hypot(x - s[0], y - s[1]) < 100) ||
      sp.some(r => x > r[0] - 60 && x < r[2] + 60 && y > r[1] - 60 && y < r[3] + 60)
    )
      continue;
    put(x, y);
  }
  LAYOUT.boxes = out;
}
function createItalianProps(boxes) {
  const sp = Object.values(LAYOUT.spawns).map(s => s.rect),
    st = [LAYOUT.sites.A, LAYOUT.sites.B],
    taken = [];
  const M = (c, r, m) =>
    new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m || 0 });
  const ok = (x, y, r, wmax) =>
    !inWall(x, y) &&
    wallDist(x, y) > r &&
    (!wmax || wallDist(x, y) < wmax) &&
    barrierDist(x, y) > r + 40 &&
    !st.some(s => Math.hypot(x - s[0], y - s[1]) < 130) &&
    !sp.some(q => x > q[0] - 70 && x < q[2] + 70 && y > q[1] - 70 && y < q[3] + 70) &&
    !boxes.some(b => x > b[0] - r && x < b[2] + r && y > b[1] - r && y < b[3] + r) &&
    taken.every(t => Math.hypot(x - t[0], y - t[1]) > t[2] + r + 30);
  const spot = (r, wmin, wmax) => {
    for (let n = 0; n < 900; n++) {
      const x = 100 + RNG() * 2100,
        y = 100 + RNG() * 2200;
      if (ok(x, y, wmin || r, wmax)) {
        taken.push([x, y, r]);
        return [x * S, y * S, x, y];
      }
    }
    return null;
  };
  const col = (x, y, r, top) =>
    addEdges(
      Array.from({ length: 12 }, (_, i) => [
        x + Math.cos((i / 12) * 6.283) * r,
        y + Math.sin((i / 12) * 6.283) * r
      ]),
      -1,
      top
    );
  const put = (geo, mat, x, y, z, ry, parent) => {
    const o = new THREE.Mesh(geo, mat);
    o.position.set(x, y, z);
    if (ry) o.rotation.y = ry;
    o.castShadow = o.receiveShadow = true;
    (parent || scene).add(o);
    return o;
  };
  const marble = M(0xe8e4da, 0.4),
    terra = M(0xb5603a, 0.9),
    wood = M(0x8a5a30, 0.9);
  /* fonte de praça no maior espaço aberto */
  let best = null,
    bd = 0;
  for (let n = 0; n < 1500; n++) {
    const x = 100 + RNG() * 2100,
      y = 100 + RNG() * 2200;
    if (!ok(x, y, 70)) continue;
    const d = wallDist(x, y);
    if (d > bd) {
      bd = d;
      best = [x, y];
    }
  }
  if (best) {
    const [x, y] = [best[0] * S, best[1] * S];
    taken.push([best[0], best[1], 60]);
    put(new THREE.CylinderGeometry(2.3, 2.5, 0.9, 24), marble, x, 0.45, y);
    put(new THREE.CylinderGeometry(0.4, 0.55, 2.2, 12), marble, x, 1.5, y);
    put(new THREE.CylinderGeometry(1.2, 0.5, 0.4, 20), marble, x, 2.5, y);
    put(new THREE.SphereGeometry(0.3, 12, 8), M(0xd6b24a, 0.3, 0.6), x, 3, y);
    const w = new THREE.Mesh(
      new THREE.CylinderGeometry(2.05, 2.05, 0.02, 24),
      new THREE.MeshBasicMaterial({ color: 0x58b8d8, transparent: true, opacity: 0.85 })
    );
    w.position.set(x, 0.9, y);
    scene.add(w);
    col(best[0], best[1], 2.5 / S, 0.9);
  }
  /* barracas de feira com toldo listrado */
  for (let i = 0; i < 6; i++) {
    const s = spot(36);
    if (!s) break;
    const [x, z, px, py] = s,
      a = i % 2 ? '#d93a3a' : '#2f8a4e',
      ct = canvasTex(
        64,
        64,
        (c, w, h) => {
          for (let k = 0; k < 8; k++) {
            c.fillStyle = k % 2 ? a : '#f4efe2';
            c.fillRect(k * 8, 0, 8, h);
          }
        },
        1,
        1
      );
    put(new THREE.BoxGeometry(2.4, 0.9, 1.1), mats.V, x, 0.45, z);
    const aw = put(
      new THREE.BoxGeometry(2.8, 0.07, 1.8),
      new THREE.MeshStandardMaterial({ map: ct, roughness: 0.9 }),
      x,
      2.35,
      z - 0.2
    );
    aw.rotation.x = 0.2;
    const g = new THREE.Group();
    for (const [dx, dz] of [
      [-1.3, -0.9],
      [1.3, -0.9],
      [-1.3, 0.7],
      [1.3, 0.7]
    ])
      put(new THREE.CylinderGeometry(0.04, 0.04, 2.4, 6), wood, x + dx, 1.2, z + dz, 0, g);
    for (let k = 0; k < 7; k++)
      put(
        new THREE.BoxGeometry(0.25, 0.25, 0.25),
        M([0xf2c230, 0xe8731f, 0xd0302a][k % 3], 0.6),
        x - 0.9 + k * 0.3,
        1.03,
        z + (k % 2 ? 0.15 : -0.15),
        0,
        g
      );
    scene.add(g);
    addEdges(
      [
        [px - 1.2 / S, py - 0.55 / S],
        [px + 1.2 / S, py - 0.55 / S],
        [px + 1.2 / S, py + 0.55 / S],
        [px - 1.2 / S, py + 0.55 / S]
      ],
      -1,
      0.9
    );
  }
  /* ciprestes em vasos de terracota */
  for (let i = 0; i < 9; i++) {
    const s = spot(16);
    if (!s) break;
    const [x, z, px, py] = s;
    put(new THREE.CylinderGeometry(0.5, 0.38, 0.65, 12), terra, x, 0.33, z);
    put(new THREE.ConeGeometry(0.65, 3.8, 10), M(0x2f5a35, 1), x, 2.5, z);
    col(px, py, 0.55 / S, 0.65);
  }
  /* vespas */
  for (let i = 0; i < 4; i++) {
    const s = spot(22);
    if (!s) break;
    const [x, z, px, py] = s,
      a = RNG() * 6.28,
      c = [0xd8453f, 0x3a8ad8, 0xe8d9a0, 0x3aa87a][i],
      g = new THREE.Group();
    put(new THREE.BoxGeometry(1.5, 0.6, 0.55), M(c, 0.4, 0.3), x, 0.6, z, a);
    for (const d of [-0.55, 0.55])
      put(
        new THREE.CylinderGeometry(0.28, 0.28, 0.14, 12),
        M(0x1c1c1c, 0.8),
        x + Math.cos(a) * d,
        0.28,
        z - Math.sin(a) * d,
        a,
        g
      ).rotation.x = Math.PI / 2;
    put(
      new THREE.BoxGeometry(0.5, 0.12, 0.4),
      M(0x2a1a14, 0.8),
      x - Math.cos(a) * 0.2,
      0.98,
      z + Math.sin(a) * 0.2,
      a,
      g
    );
    scene.add(g);
    col(px, py, 0.8 / S, 0.7);
  }
  /* estátuas de mármore */
  for (let i = 0; i < 3; i++) {
    const s = spot(20);
    if (!s) break;
    const [x, z, px, py] = s;
    put(new THREE.BoxGeometry(1, 1.3, 1), marble, x, 0.65, z);
    put(new THREE.CylinderGeometry(0.22, 0.32, 1.2, 10), marble, x, 1.9, z);
    put(new THREE.SphereGeometry(0.2, 10, 8), marble, x, 2.65, z);
    col(px, py, 0.62 / S, 1.3);
  }
  /* postes de luz e bandeiras da Itália junto às paredes (sem colisão) */
  const gl = new THREE.MeshBasicMaterial({ color: 0xffd27a }),
    iron = M(0x23262a, 0.5, 0.6),
    fc = [0x2e9a4f, 0xf4f4ef, 0xd7312f];
  for (let i = 0; i < 16; i++) {
    const s = spot(10, 20, 34);
    if (!s) break;
    const [x, z] = s,
      g = new THREE.Group();
    if (i % 2) {
      put(new THREE.CylinderGeometry(0.05, 0.07, 3.4, 6), iron, x, 1.7, z, 0, g);
      put(new THREE.BoxGeometry(0.3, 0.4, 0.3), gl, x, 3.5, z, 0, g);
      put(new THREE.BoxGeometry(0.4, 0.05, 0.4), iron, x, 3.75, z, 0, g);
    } else {
      const ry = RNG() * 6.28;
      put(new THREE.CylinderGeometry(0.03, 0.03, 3.4, 6), iron, x, 1.7, z, 0, g);
      fc.forEach((c, k) => {
        const f = new THREE.Mesh(
          new THREE.PlaneGeometry(0.5, 0.9),
          new THREE.MeshBasicMaterial({ color: c, side: THREE.DoubleSide })
        );
        f.position.set(x + (k - 1) * 0.5 * Math.cos(ry), 2.9, z - (k - 1) * 0.5 * Math.sin(ry));
        f.rotation.y = ry;
        g.add(f);
      });
    }
    scene.add(g);
  }
}

function createMapGeometry() {
  italianizeLayout();
  createWalls();
  createThinWalls();
  createFloor();
  createFloorPatches();
  createBombsiteA();
  createBombsiteB();
  createLandmarks();
  createDoors();
  createAttackerSpawn();
  createDefenderSpawn();
  createEnergyBarriers();
}
function createWalls() {
  buildCity();
  const p = LAYOUT.pillar,
    n = 16,
    pp = [];
  if (p) {
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      pp.push([p.c[0] + Math.cos(a) * p.r, p.c[1] + Math.sin(a) * p.r]);
    }
    addEdges(pp);
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(p.r * S, p.r * S, WALL_H, 24), mats.wall);
    cyl.position.set(p.c[0] * S, WALL_H / 2, p.c[1] * S);
    cyl.castShadow = cyl.receiveShadow = true;
    scene.add(cyl);
  }
  const bg = {},
    eg = {},
    EP = [],
    boxList = filterBoxes();
  for (const b of boxList) {
    const [x1, y1, x2, y2, t] = b,
      h = BOX_H[t],
      w = (x2 - x1) * S,
      d = (y2 - y1) * S;
    bg[w + '_' + d + '_' + h] = bg[w + '_' + d + '_' + h] || new THREE.BoxGeometry(w, h, d);
    const g = bg[w + '_' + d + '_' + h],
      m = new THREE.Mesh(g, mats[t]);
    m.position.set(((x1 + x2) / 2) * S, h / 2, ((y1 + y2) / 2) * S);
    m.castShadow = m.receiveShadow = true;
    scene.add(m);
    m.userData.pen =
      t === 'W' || t === 'V' || t === 'X'
        ? 1
        : t === 'G' || t === 'T' || t === 'R' || t === 'S'
          ? 2
          : 0; /* 1 = madeira (qualquer arma atravessa) · 2 = radianite (só penetração alta) */
    {
      const kk = w + '_' + d + '_' + h,
        ea = eg[kk] || (eg[kk] = new THREE.EdgesGeometry(g).attributes.position.array);
      for (let i = 0; i < ea.length; i += 3)
        EP.push(ea[i] + m.position.x, ea[i + 1] + m.position.y, ea[i + 2] + m.position.z);
    } /* contornos de todas as caixas num único desenho */
    window.__box = 1;
    addEdges(
      [
        [x1, y1],
        [x2, y1],
        [x2, y2],
        [x1, y2]
      ],
      -1,
      h
    );
    window.__box = 0;
    BOXES.push([x1 * S, y1 * S, x2 * S, y2 * S, h]);
  }
  {
    const eG = new THREE.BufferGeometry();
    eG.setAttribute('position', new THREE.Float32BufferAttribute(EP, 3));
    const el = new THREE.LineSegments(eG, mats.edge);
    el.frustumCulled = false;
    scene.add(el);
  }
  createBarrels(boxList);
  createItalianProps(boxList);
}
function createBarrels(boxList) {
  const R = BARREL_R * S,
    bGeo = new THREE.CylinderGeometry(R, R * 0.94, 1.15, 14),
    rGeo = new THREE.CylinderGeometry(R * 1.05, R * 1.05, 0.07, 14);
  const cols = [0x9b7448, 0x5f8a78, 0x7b6a55],
    ringM = new THREE.MeshStandardMaterial({
      color: 0x2a2e33,
      roughness: 0.5,
      metalness: 0.6,
      emissive: 0x2fe0c0,
      emissiveIntensity: 0.6
    }); /* madeira, metal esverdeado, anéis de radianite */
  const BMT = cols.map(
    c =>
      new THREE.MeshStandardMaterial({ map: tex.metal, color: c, roughness: 0.5, metalness: 0.45 })
  ); /* materiais compartilhados */
  filterBarrels(boxList).forEach(([x, y], i) => {
    const m = new THREE.Mesh(bGeo, BMT[i % 3]);
    m.position.set(x * S, 0.575, y * S);
    m.castShadow = m.receiveShadow = true;
    scene.add(m);
    for (const hy of [0.22, 0.93]) {
      const r = new THREE.Mesh(rGeo, ringM);
      r.position.set(x * S, hy, y * S);
      scene.add(r);
    }
    const pts = [];
    for (let k = 0; k < 10; k++) {
      const a = (k / 10) * Math.PI * 2;
      pts.push([x + Math.cos(a) * BARREL_R, y + Math.sin(a) * BARREL_R]);
    }
    addEdges(pts, -1, 1.15);
  });
}
const inPoly = (x, y, p) => {
  let c = false;
  for (let i = 0, j = p.length - 1; i < p.length; j = i++) {
    if (
      p[i][1] > y != p[j][1] > y &&
      x < ((p[j][0] - p[i][0]) * (y - p[i][1])) / (p[j][1] - p[i][1]) + p[i][0]
    )
      c = !c;
  }
  return c;
};
function dseg(px, py, a, b) {
  const dx = b[0] - a[0],
    dy = b[1] - a[1];
  let t = ((px - a[0]) * dx + (py - a[1]) * dy) / (dx * dx + dy * dy);
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return Math.hypot(px - a[0] - dx * t, py - a[1] - dy * t);
}
function polyDist(px, py, poly) {
  let m = 1e9;
  for (let i = 0; i < poly.length; i++)
    m = Math.min(m, dseg(px, py, poly[i], poly[(i + 1) % poly.length]));
  return m;
}
let _thin = null;
function thinRects() {
  if (_thin) return _thin;
  _thin = [];
  for (const line of LAYOUT.thin)
    for (let i = 0; i < line.length - 1; i++) {
      const a = line[i],
        b = line[i + 1],
        dx = b[0] - a[0],
        dy = b[1] - a[1],
        l = Math.hypot(dx, dy),
        nx = (-dy / l) * 5,
        ny = (dx / l) * 5;
      _thin.push([
        [a[0] + nx, a[1] + ny],
        [b[0] + nx, b[1] + ny],
        [b[0] - nx, b[1] - ny],
        [a[0] - nx, a[1] - ny]
      ]);
    }
  return _thin;
}
const inWall = (x, y) =>
  !inPoly(x, y, LAYOUT.outer) ||
  LAYOUT.solids.some(p => inPoly(x, y, p)) ||
  thinRects().some(p => inPoly(x, y, p)) ||
  (LAYOUT.pillar && Math.hypot(x - LAYOUT.pillar.c[0], y - LAYOUT.pillar.c[1]) < LAYOUT.pillar.r);
function wallDist(x, y) {
  let m = LAYOUT.pillar
    ? Math.max(0, Math.hypot(x - LAYOUT.pillar.c[0], y - LAYOUT.pillar.c[1]) - LAYOUT.pillar.r)
    : 1e9;
  m = Math.min(m, polyDist(x, y, LAYOUT.outer));
  for (const p of LAYOUT.solids) m = Math.min(m, polyDist(x, y, p));
  for (const p of thinRects()) m = Math.min(m, polyDist(x, y, p));
  return m;
}
const barrierDist = (x, y) =>
  LAYOUT.barriers.reduce((m, b) => Math.min(m, dseg(x, y, [b[0], b[1]], [b[2], b[3]])), 1e9);
/* valida caixas: descarta as que entram em paredes/barreiras/outras caixas; cola nas paredes vizinhas
   (sem frestas que causam z-fighting e vãos onde o jogador trava) e deixa folga entre caixas */
function filterBoxes() {
  const list = LAYOUT.boxes
      .slice()
      .sort((a, b) => (b[2] - b[0]) * (b[3] - b[1]) - (a[2] - a[0]) * (a[3] - a[1])),
    kept = [];
  for (const b of list) {
    const [x1, y1, x2, y2] = b;
    let bad = false;
    for (let k = 0; k <= 24 && !bad; k++) {
      const f = k / 24,
        xs = x1 + 2 + (x2 - x1 - 4) * f,
        ys = y1 + 2 + (y2 - y1 - 4) * f;
      if (inWall(xs, y1 + 2) || inWall(xs, y2 - 2) || inWall(x1 + 2, ys) || inWall(x2 - 2, ys))
        bad = true;
    }
    if (bad) continue;
    let bd = 1e9;
    for (let k = 0; k <= 8; k++) {
      const f = k / 8;
      for (const p of [
        [x1 + (x2 - x1) * f, y1],
        [x1 + (x2 - x1) * f, y2],
        [x1, y1 + (y2 - y1) * f],
        [x2, y1 + (y2 - y1) * f]
      ])
        bd = Math.min(bd, barrierDist(p[0], p[1]));
    }
    if (bd < 14) continue;
    if (kept.some(k => b[0] < k[2] - 1 && b[2] > k[0] + 1 && b[1] < k[3] - 1 && b[3] > k[1] + 1))
      continue;
    kept.push(b);
  }
  return kept.map(b => {
    let [x1, y1, x2, y2, t] = [b[0] + 1.5, b[1] + 1.5, b[2] - 1.5, b[3] - 1.5, b[4]];
    const side = pts => pts.reduce((m, p) => Math.min(m, wallDist(p[0], p[1])), 1e9);
    const N = [0, 0.25, 0.5, 0.75, 1],
      X = N.map(f => x1 + (x2 - x1) * f),
      Y = N.map(f => y1 + (y2 - y1) * f);
    const dL = side(Y.map(y => [x1, y])),
      dR = side(Y.map(y => [x2, y])),
      dT = side(X.map(x => [x, y1])),
      dB = side(X.map(x => [x, y2]));
    const E = 24; /* fresta menor que o diâmetro do jogador (0,8 m) vira vão morto: fecha encostando na parede */
    const ext = (d, pts) => {
      if (d >= E || d < 0.01) return 0;
      const e = d + 1;
      return pts(e).every(q => inWall(q[0], q[1])) ? e : d;
    };
    const nx1 = x1 - ext(dL, e => Y.map(y => [x1 - e, y])),
      nx2 = x2 + ext(dR, e => Y.map(y => [x2 + e, y])),
      ny1 = y1 - ext(dT, e => X.map(x => [x, y1 - e])),
      ny2 = y2 + ext(dB, e => X.map(x => [x, y2 + e]));
    return [nx1, ny1, nx2, ny2, t];
  });
}
/* barris decorativos com colisão; descarta os que cairiam em paredes, barreiras ou caixas */
function filterBarrels(boxes) {
  return LAYOUT.barrels.filter(([x, y]) => {
    if (inWall(x, y) || wallDist(x, y) < BARREL_R + 10 || barrierDist(x, y) < BARREL_R + 16)
      return false;
    return !boxes.some(b => {
      const dx = Math.max(b[0] - x, x - b[2], 0),
        dy = Math.max(b[1] - y, y - b[3], 0);
      return Math.hypot(dx, dy) < BARREL_R + 10;
    });
  });
}
/* paredes finas da planta (bordas do bombsite A e divisória da rota inferior) */
function createThinWalls() {
  for (const r of thinRects()) {
    extrude(new THREE.Shape(r.map(V)), WALL_H, mats.wall);
    addEdges(r);
  }
}
function zone(pts, color, op) {
  const g = new THREE.ShapeGeometry(new THREE.Shape(pts.map(V)));
  g.rotateX(-Math.PI / 2);
  const m = new THREE.Mesh(
    g,
    new THREE.MeshStandardMaterial({
      color,
      transparent: true,
      opacity: op,
      roughness: 0.9,
      polygonOffset: true,
      polygonOffsetFactor: -2
    })
  );
  m.position.y = 0.02;
  m.receiveShadow = true;
  scene.add(m);
  return m;
}
function decal(ch, px, py) {
  const m = new THREE.Mesh(
    new THREE.PlaneGeometry(4.6, 4.6),
    new THREE.MeshBasicMaterial({
      map: letterTex(ch),
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -4
    })
  );
  m.rotation.x = -Math.PI / 2;
  m.position.set(px * S, 0.035, py * S);
  scene.add(m);
}
function createFloor() {
  const g = new THREE.ShapeGeometry(new THREE.Shape(LAYOUT.outer.map(V)));
  g.rotateX(-Math.PI / 2);
  const f = new THREE.Mesh(g, mats.floor);
  f.receiveShadow = true;
  scene.add(f);
}
function createBombsiteA() {
  zone(LAYOUT.plantA, 0xc4605a, 0.26);
  decal('A', ...LAYOUT.sites.A);
}
function createBombsiteB() {
  zone(LAYOUT.plantB, 0xc4605a, 0.26);
  decal('B', ...LAYOUT.sites.B);
}
function spawnRoom(key) {
  const s = LAYOUT.spawns[key],
    r = s.rect;
  zone(
    [
      [r[0], r[1]],
      [r[2], r[1]],
      [r[2], r[3]],
      [r[0], r[3]]
    ],
    s.color,
    0.55
  );
  s.marker = key; /* área lógica para futuro posicionamento de personagens */
}
function createAttackerSpawn() {
  spawnRoom('ATTACKER_SPAWN');
}
function createDefenderSpawn() {
  spawnRoom('DEFENDER_SPAWN');
}

function floorPatch(pts, mat, y) {
  const g = new THREE.ShapeGeometry(new THREE.Shape(pts.map(V)));
  g.rotateX(-Math.PI / 2);
  const m = new THREE.Mesh(g, mat);
  m.position.y = y;
  m.receiveShadow = true;
  scene.add(m);
  return m;
}
function createFloorPatches() {
  floorPatch(LAYOUT.plantA, mats.marble, 0.012); /* A: praça de mármore */
  floorPatch(LAYOUT.plantB, mats.dry, 0.012); /* B: pedra seca */
  if (LAYOUT.props && LAYOUT.props.grass)
    floorPatch(LAYOUT.props.grass, mats.grass, 0.012); /* Link A: grama */
  const P = LAYOUT.props || {};
  if (P.wine) floorPatch(P.wine, mats.brickD, 0.012); /* Vinho: tijolo escuro */
  for (const [gx, gy] of P.grates || [])
    floorPatch(
      [
        [gx - 21, gy - 21],
        [gx + 21, gy - 21],
        [gx + 21, gy + 21],
        [gx - 21, gy + 21]
      ],
      mats.grate,
      0.014
    ); /* grelhas de ferro */
}
const EXTRA = []; /* meshes com material em lista (alvos de tiro que o filtro padrão não pega) */
function ceilH(x, z) {
  const px = x / S,
    py = z / S;
  for (const c of LAYOUT.ceilings || []) {
    if (!inPoly(px, py, c.p)) continue;
    if (c.hole && px > c.hole[0] && px < c.hole[2] && py > c.hole[1] && py < c.hole[3]) continue;
    return c.h;
  }
  return 35; /* skybox invisível a 35 m */
}
function createLandmarks() {
  const P = LAYOUT.props;
  if (!P) return;
  const M = (c, r, m) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m });
  const add = (geo, mat, x, y, z) => {
    const o = new THREE.Mesh(geo, mat);
    o.position.set(x, y, z);
    o.castShadow = o.receiveShadow = true;
    scene.add(o);
    return o;
  };
  const rot = (pts, cx, cy, deg) => {
    const a = (deg * Math.PI) / 180,
      c = Math.cos(a),
      s = Math.sin(a);
    return pts.map(([x, y]) => [
      cx + (x - cx) * c - (y - cy) * s,
      cy + (x - cx) * s + (y - cy) * c
    ]);
  };
  if (P.generator) {
    /* gerador 3 x 1,8 x 2,2 m, inclinado 15° e deslocado para o fundo do A */
    const [gx, gy] = P.generator,
      deg = 15,
      g = new THREE.Group(),
      steel = M(0x8d949a, 0.55, 0.5),
      dark = M(0x4a5057, 0.6, 0.4);
    const part = (geo, mat, x, y, z) => {
      const o = new THREE.Mesh(geo, mat);
      o.position.set(x, y, z);
      o.castShadow = o.receiveShadow = true;
      g.add(o);
      return o;
    };
    part(new THREE.BoxGeometry(3, 2, 1.8), steel, 0, 1, 0);
    part(new THREE.BoxGeometry(3.1, 0.2, 1.9), dark, 0, 2.1, 0);
    for (const dx of [-0.8, 0.8])
      part(new THREE.CylinderGeometry(0.3, 0.3, 0.25, 14), dark, dx, 2.32, 0);
    const strip = new THREE.Mesh(
      new THREE.BoxGeometry(2.6, 0.07, 0.02),
      new THREE.MeshBasicMaterial({ color: 0x5ff2ff })
    );
    strip.position.set(0, 1.1, 0.91);
    g.add(strip);
    g.position.set(gx * S, 0, gy * S);
    g.rotation.y = (-deg * Math.PI) / 180;
    scene.add(g);
    g.children.forEach(o => {
      if (o.material.isMeshStandardMaterial) EXTRA.push(o);
    });
    addEdges(
      rot(
        [
          [gx - 45, gy - 27],
          [gx + 45, gy - 27],
          [gx + 45, gy + 27],
          [gx - 45, gy + 27]
        ],
        gx,
        gy,
        deg
      ),
      -1,
      2.2
    );
  }
  if (P.stack) {
    /* Double Stack: dois cubos de radianite de 1,2 m (2,4 m no total) */
    const [sx, sy] = P.stack;
    for (const y of [0.6, 1.8]) {
      const o = add(
        new THREE.BoxGeometry(1.2, 1.2, 1.2),
        y < 1 ? mats.T : mats.G,
        sx * S,
        y,
        sy * S
      );
      o.userData.pen = 2;
    }
    addEdges(
      [
        [sx - 18, sy - 18],
        [sx + 18, sy - 18],
        [sx + 18, sy + 18],
        [sx - 18, sy + 18]
      ],
      -1,
      2.4
    );
  }
  if (P.tree) {
    /* árvore da sala do Link A: copa acima da altura da cabeça */
    const [tx, ty] = P.tree,
      X = tx * S,
      Z = ty * S,
      leaf = M(0x4f8a3c, 0.9, 0);
    add(new THREE.CylinderGeometry(0.35, 0.5, 3.4, 10), M(0x6b4a2f, 0.95, 0), X, 1.7, Z);
    add(new THREE.SphereGeometry(1.8, 12, 10), leaf, X, 4.2, Z);
    add(new THREE.SphereGeometry(1.3, 12, 10), leaf, X + 1.1, 3.7, Z + 0.6);
    add(new THREE.SphereGeometry(1.2, 12, 10), leaf, X - 1, 3.8, Z - 0.7);
    const pts = [];
    for (let k = 0; k < 10; k++) {
      const a = (k / 10) * Math.PI * 2;
      pts.push([tx + Math.cos(a) * 16, ty + Math.sin(a) * 16]);
    }
    addEdges(pts);
  }
  if (P.bottles) {
    /* garrafas de vinho de vidro verde (decoração, sem colisão) */
    const gl = new THREE.MeshStandardMaterial({
      color: 0x2f7a46,
      roughness: 0.15,
      metalness: 0.1,
      transparent: true,
      opacity: 0.9
    });
    for (const [bx, by, ly] of P.bottles) {
      const m = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.32, 8), gl);
      m.castShadow = true;
      if (ly) {
        m.rotation.z = Math.PI / 2;
        m.rotation.y = bx;
        m.position.set(bx * S, 0.06, by * S);
      } else m.position.set(bx * S, 0.16, by * S);
      scene.add(m);
    }
  }
  if (P.logs) {
    /* Logs: pilha de troncos 2 m de largura x ~1,5 m de altura, encostada na divisa do Mercado */
    const [lx, ly] = P.logs,
      X = lx * S,
      Z = ly * S,
      bark = new THREE.MeshStandardMaterial({ map: tex.bark, roughness: 1 }),
      cap = new THREE.MeshStandardMaterial({ map: tex.logEnd, roughness: 0.9 });
    const g = new THREE.CylinderGeometry(0.25, 0.25, 1.5, 10);
    g.rotateX(Math.PI / 2);
    for (const [n, y] of [
      [4, 0.25],
      [3, 0.68],
      [2, 1.11]
    ])
      for (let i = 0; i < n; i++) {
        const m = new THREE.Mesh(g, [bark, cap, cap]);
        m.position.set(X + (i - (n - 1) / 2) * 0.5, y, Z);
        m.castShadow = m.receiveShadow = true;
        scene.add(m);
        EXTRA.push(m);
      }
    addEdges(
      [
        [lx - 30, ly - 22],
        [lx + 30, ly - 22],
        [lx + 30, ly + 22],
        [lx - 30, ly + 22]
      ],
      -1,
      1.5
    );
  }
}
function createDoors() {
  Doors.list = [];
  const D = LAYOUT.doors;
  if (!D) return;
  for (const c of D) {
    const x1 = c.a[0] * S,
      z1 = c.a[1] * S,
      x2 = c.b[0] * S,
      z2 = c.b[1] * S,
      len = Math.hypot(x2 - x1, z2 - z1),
      cx = (x1 + x2) / 2,
      cz = (z1 + z2) / 2;
    const mat = new THREE.MeshStandardMaterial({ map: tex.door, roughness: 0.6, metalness: 0.5 });
    const m = new THREE.Mesh(new THREE.BoxGeometry(len, WALL_H, 0.3), mat);
    m.position.set(cx, WALL_H / 2, cz);
    m.rotation.y = -Math.atan2(z2 - z1, x2 - x1);
    m.castShadow = m.receiveShadow = true;
    scene.add(m);
    const lamp = new THREE.Mesh(
      new THREE.SphereGeometry(0.18, 10, 8),
      new THREE.MeshBasicMaterial({ color: 0xffc21a })
    );
    lamp.position.set(cx, WALL_H - 0.4, cz);
    scene.add(lamp); /* luz de aviso amarela */
    const sx = c.sw[0] * S,
      sz = c.sw[1] * S + 0.06; /* interruptor na parede (atirável de longe) */
    const sp = new THREE.Mesh(
      new THREE.BoxGeometry(0.4, 0.55, 0.12),
      new THREE.MeshStandardMaterial({ color: 0x5a636b, roughness: 0.4, metalness: 0.7 })
    );
    sp.position.set(sx, 1.4, sz);
    scene.add(sp);
    const pl = new THREE.Mesh(
      new THREE.PlaneGeometry(0.28, 0.18),
      new THREE.MeshBasicMaterial({ color: 0x4fd8ff })
    );
    pl.position.set(sx, 1.4, sz + 0.065);
    scene.add(pl);
    const hl = new THREE.Mesh(
      new THREE.SphereGeometry(0.07, 8, 6),
      new THREE.MeshBasicMaterial({ color: 0x8fe8ff })
    );
    hl.position.set(sx, 1.75, sz + 0.14);
    scene.add(hl); /* holograma azul */
    const d = { m, mat, lamp, name: c.name, state: 'open', hp: 500, k: 1, solid: false, tt: 0 };
    m.userData.door = d;
    sp.userData.sw = d;
    segs.push([x1, z1, x2, z2, -1, d]);
    Doors.list.push(d);
  }
}
