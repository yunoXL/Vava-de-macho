const Menu = {
  on: true,
  side: 'atk',
  q: null,
  init() {
    document.body.classList.add('menu');
    $$('mSide').onclick = e => {
      const b = e.target.closest('button');
      if (!b) return;
      this.side = b.dataset.s;
      [...$$('mSide').children].forEach(x => x.classList.toggle('on', x === b));
    };
    $$('mGo').onclick = () => this.queue();
    $$('mCancel').onclick = () => {
      Net.close();
      this.cancel();
    };
    $$('mHost').onclick = () => this.p2p(1);
    $$('mJoin').onclick = () => {
      const c = $$('mCode').value.trim();
      c.length >= 4 ? this.p2p(0, c) : toast('Digite o código de 4 letras');
    };
    this.show();
  },
  p2p(h, code) {
    if (this.q) return;
    let t = 0;
    const my = (this.q = {
        tick: setInterval(() => {
          $$('mTm').textContent = fmtT(++t);
        }, 1000)
      }),
      st = x => {
        $$('mSt').textContent = x;
      };
    $$('mGo').style.display = 'none';
    $$('mMp').style.display = 'none';
    $$('mQ').style.display = 'flex';
    st('INICIANDO…');
    (h ? Net.host(c => st('SALA: ' + c + ' · PASSE O CÓDIGO AO AMIGO')) : Net.enter(code, st))
      .then(r => {
        if (this.q !== my) return;
        this.side = r.side;
        st('AMIGO CONECTADO');
        setTimeout(() => {
          if (this.q === my)
            MapSelect.open(() => {
              if (this.q === my)
                Agents.open(() => {
                  if (this.q === my)
                    SideSel.open(sd => {
                      if (this.q === my) {
                        this.side = sd;
                        this.start(r);
                      }
                    });
                });
            });
        }, 500);
      })
      .catch(e => {
        st('ERRO: ' + ((e && (e.type || e.message)) || e));
        setTimeout(() => {
          Net.close();
          this.cancel();
        }, 2500);
      });
  },
  show() {
    if (typeof Tabs !== 'undefined') Tabs.go(0); /* volta para a aba JOGAR */
    Training.on && Training.stop();
    Net.close();
    Pause.hide();
    Round.done = 0;
    Round.over = 0;
    Bomb.reset();
    $$('mEnd').classList.remove('on');
    Mini.big = 0;
    $$('bigmap').classList.remove('on');
    Board.show(0);
    Abil.reset();
    this.on = true;
    this.cancel();
    Weapon.trig(0);
    Shop.toggle(0);
    document.exitPointerLock && document.exitPointerLock();
    document.body.classList.add('menu');
    $$('menu').style.display = 'flex';
    if (Weapon.vm) Weapon.vm.visible = false;
  },
  queue() {
    if (this.q || MapSelect.on || Agents.on) return;
    if (MODE === 'treino') return Agents.open(() => Training.start());
    MapSelect.open(() => this.search());
  } /* Menu → Mapa → Agente → Jogo */,
  search() {
    if (this.q) return;
    let t = 0;
    const my = (this.q = {
        tick: setInterval(() => {
          $$('mTm').textContent = fmtT(++t);
        }, 1000)
      }),
      ok = () => this.q === my;
    $$('mGo').style.display = 'none';
    $$('mQ').style.display = 'flex';
    $$('mSt').textContent = 'PROCURANDO PARTIDA…';
    new Promise(r => setTimeout(r, 1200))
      .then(() => {
        if (!ok()) return;
        $$('mSt').textContent = 'CONECTANDO A ' + Net.url().toUpperCase() + '…';
        return Net.join({ side: this.side });
      })
      .then(r => {
        if (!ok() || !r) return;
        $$('mSt').textContent = 'PARTIDA ENCONTRADA';
        setTimeout(() => {
          if (ok())
            Agents.open(() => {
              if (ok())
                SideSel.open(sd => {
                  if (ok()) {
                    this.side = sd;
                    this.start(r);
                  }
                });
            });
        }, 500);
      })
      .catch(e => {
        if (!ok()) return;
        $$('mSt').textContent = 'ERRO: ' + ((e && (e.message || e.type)) || e);
        setTimeout(() => {
          if (ok()) {
            Net.close();
            this.cancel();
          }
        }, 2500);
      });
  },
  cancel() {
    if (this.q) {
      clearInterval(this.q.tick);
      this.q = null;
    }
    $$('mQ').style.display = 'none';
    menuMode();
    $$('mTm').textContent = '0:00';
  },
  start() {
    this.cancel();
    this.on = false;
    document.body.classList.remove('menu');
    $$('menu').style.display = 'none';
    Inv.owned = { classic: 1, knife: 1 };
    Inv.slots = { pri: null, sec: 'classic', mel: 'knife' };
    Inv.owned[KPick.id] = 1;
    Inv.slots.mel = KPick.id;
    Inv.armor = 0;
    Econ.c = CFG.startCredits; /* partida nova = tudo zerado */
    Stats.reset();
    Profile.rec(Game.agent, 'p'); /* partida jogada */
    Weapon.ammo = {};
    Game.side = this.side;
    Round.reset();
    Hud.score();
    Weapon.equip('classic');
    Abil.set(Game.agent || 'phoenix');
    Round.start();
    if (Weapon.vm) Weapon.vm.visible = true;
    Hud.flash();
  }
};
