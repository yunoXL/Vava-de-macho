/* ========= BARREIRAS DE ENERGIA ========= */
const BVERT =
  'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}';
const BFRAG = `varying vec2 vUv;uniform float uTime,uFade,uLen;
void main(){
  float ex=min(vUv.x,1.0-vUv.x)*uLen;
  float eb=clamp(max(smoothstep(.88,1.,vUv.y),1.0-smoothstep(0.,.12,vUv.y))+(1.0-smoothstep(0.,.3,ex)),0.,1.);
  float l=pow(abs(sin((vUv.x*uLen*1.6+vUv.y*2.2-uTime*.7)*3.14159)),14.0);
  float pulse=.75+.25*sin(uTime*3.0+vUv.x*uLen);
  vec3 col=mix(vec3(0.0,.5,1.0),vec3(.5,1.0,1.0),clamp(eb+l*.6,0.,1.));
  float a=(.16+.5*eb+.35*l)*pulse*uFade;
  gl_FragColor=vec4(col,a);
}`;
function createEnergyBarriers() {
  LAYOUT.barriers.forEach((b, i) => {
    const ax = b[0] * S,
      az = b[1] * S,
      bx = b[2] * S,
      bz = b[3] * S,
      len = Math.hypot(bx - ax, bz - az);
    segs.push([ax, az, bx, bz, i]);
    const mat = new THREE.ShaderMaterial({
      vertexShader: BVERT,
      fragmentShader: BFRAG,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      uniforms: { uTime: { value: 0 }, uFade: { value: 1 }, uLen: { value: len } }
    });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(len + 0.2, WALL_H), mat);
    m.position.set((ax + bx) / 2, WALL_H / 2, (az + bz) / 2);
    m.rotation.y = -Math.atan2(bz - az, bx - ax);
    scene.add(m);
    barrierObjs.push(m);
    for (const [px, pz] of [
      [ax, az],
      [bx, bz]
    ]) {
      const p = new THREE.Mesh(
        new THREE.BoxGeometry(0.22, WALL_H, 0.22),
        new THREE.MeshBasicMaterial({ color: 0x66ddff, transparent: true, opacity: 0.9 })
      );
      p.position.set(px, WALL_H / 2, pz);
      scene.add(p);
      postObjs.push(p);
    }
  });
}
function setBarriersActive(active) {
  barriersActive = !!active;
}
window.setBarriersActive = setBarriersActive;
