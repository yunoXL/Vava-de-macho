/* ========= MINIMAPA, MAPA GRANDE (M) E PLACAR (TAB) ========= */
const Stats = {
  me: { k: 0, d: 0 },
  op: { k: 0, d: 0 },
  reset() {
    this.me = { k: 0, d: 0 };
    this.op = { k: 0, d: 0 };
  }
};
const Mini = {
  c: null,
  k: null,
  box: null,
  big: 0,
  n: 0,
  toggle() {
    this.big = !this.big;
    $$('bigmap').classList.toggle('on', !!this.big);
    this.ac = 1;
  },
  build() {
    const L = LAYOUT,
      xs = L.outer.map(p => p[0]),
      ys = L.outer.map(p => p[1]),
      m = 60,
      x0 = Math.min(...xs) - m,
      y0 = Math.min(...ys) - m,
      w = Math.max(...xs) - x0 + m,
      h = Math.max(...ys) - y0 + m,
      s = 900 / Math.max(w, h),
      cv = document.createElement('canvas');
    cv.width = Math.ceil(w * s);
    cv.height = Math.ceil(h * s);
    const x = cv.getContext('2d');
    x.scale(s, s);
    x.translate(-x0, -y0);
    const poly = (p, f) => {
      x.beginPath();
      p.forEach((q, i) => (i ? x.lineTo(q[0], q[1]) : x.moveTo(q[0], q[1])));
      x.closePath();
      x.fillStyle = f;
      x.fill();
    };
    poly(L.outer, '#d9d0bb');
    for (const key in L.spawns) {
      const r = L.spawns[key].rect;
      x.fillStyle = key[0] === 'A' ? 'rgba(216,69,63,.5)' : 'rgba(58,91,216,.5)';
      x.fillRect(r[0], r[1], r[2] - r[0], r[3] - r[1]);
    }
    poly(L.plantA, 'rgba(196,96,90,.4)');
    poly(L.plantB, 'rgba(196,96,90,.4)');
    for (const p of L.solids) poly(p, '#3b434b');
    x.fillStyle = '#7f8f84';
    for (const b of L.boxes) x.fillRect(b[0], b[1], b[2] - b[0], b[3] - b[1]);
    x.font = 'bold 170px system-ui,sans-serif';
    x.textAlign = 'center';
    x.textBaseline = 'middle';
    x.lineWidth = 14;
    x.strokeStyle = 'rgba(0,0,0,.7)';
    x.fillStyle = '#fff';
    for (const k of ['A', 'B']) {
      x.strokeText(k, L.sites[k][0], L.sites[k][1]);
      x.fillText(k, L.sites[k][0], L.sites[k][1]);
    }
    this.c = cv;
    this.k = CURRENT_MAP;
    this.box = { x0, y0, s };
  },
  draw(cv, loc) {
    const g = cv.getContext('2d'),
      W = cv.width,
      H = cv.height,
      c = this.c,
      b = this.box,
      a = Math.atan2(-Math.cos(yaw), -Math.sin(yaw)),
      cx = (pos.x / S - b.x0) * b.s,
      cy = (pos.z / S - b.y0) * b.s;
    let k,
      ox = 0,
      oy = 0;
    g.clearRect(0, 0, W, H);
    g.save();
    if (loc) {
      k = W / (1500 * b.s);
      g.translate(W / 2, H / 2);
      g.rotate(-Math.PI / 2 - a);
      g.scale(k, k);
      g.translate(-cx, -cy);
    } /* minimapa: vista local que gira com você (frente = cima) */ else {
      k = Math.min(W / c.width, H / c.height);
      ox = (W - c.width * k) / 2;
      oy = (H - c.height * k) / 2;
      g.translate(ox, oy);
      g.scale(k, k);
    }
    g.drawImage(c, 0, 0);
    if (barriersActive && BarrierController.k > 0.01) {
      g.strokeStyle = 'rgba(80,200,255,.95)';
      g.lineWidth = 3 / k;
      g.beginPath();
      for (const q of LAYOUT.barriers) {
        g.moveTo((q[0] - b.x0) * b.s, (q[1] - b.y0) * b.s);
        g.lineTo((q[2] - b.x0) * b.s, (q[3] - b.y0) * b.s);
      }
      g.stroke();
    }
    if (Bomb.pl) {
      const bx = (Bomb.pl.x / S - b.x0) * b.s,
        by = (Bomb.pl.z / S - b.y0) * b.s;
      g.fillStyle = Math.floor(performance.now() / 250) % 2 ? '#ff3b3b' : '#ffd45a';
      g.beginPath();
      g.arc(bx, by, (loc ? 5 : 8) / k, 0, 7);
      g.fill();
      g.lineWidth = 2 / k;
      g.strokeStyle = '#000';
      g.stroke();
    }
    g.restore();
    const r = W / (loc ? 15 : 34),
      px = loc ? W / 2 : ox + cx * k,
      py = loc ? H / 2 : oy + cy * k,
      ang = loc ? -Math.PI / 2 : a;
    g.save();
    g.translate(px, py);
    g.rotate(ang);
    g.beginPath();
    g.moveTo(r, 0);
    g.lineTo(-r * 0.7, r * 0.65);
    g.lineTo(-r * 0.35, 0);
    g.lineTo(-r * 0.7, -r * 0.65);
    g.closePath();
    g.fillStyle = '#4fd8ff';
    g.fill();
    g.lineWidth = Math.max(1.5, W / 220);
    g.strokeStyle = '#fff';
    g.stroke();
    g.restore();
  },
  update(dt) {
    if (Menu.on || Training.on) return;
    if (!this.c || this.k !== CURRENT_MAP) this.build();
    if ((this.ac = (this.ac || 0) + dt) < 0.033) return;
    this.ac = 0;
    this.draw($$('mini'), 1);
    if (this.big) this.draw($$('bmc'), 0);
  }
};
const Board = {
  on: 0,
  t: 0,
  show(v) {
    v = !!v && !Menu.on && !Pause.on;
    this.on = v;
    $$('board').classList.toggle('on', v);
    if (v) this.render();
  },
  row(n, ag, s, me, cred) {
    const a = AGENTS.find(x => x.id === ag);
    return (
      '<tr' +
      (me ? ' class="me"' : '') +
      '><td><i style="background:' +
      (a ? a.c : '#888') +
      '"></i></td><td>' +
      n +
      '</td><td>' +
      (a ? a.name : '—') +
      '</td><td>' +
      s.k +
      '</td><td>' +
      s.d +
      '</td><td>' +
      (s.d ? (s.k / s.d).toFixed(2) : s.k.toFixed(2)) +
      '</td><td>' +
      (cred === undefined ? '—' : '¤' + fmt(cred)) +
      '</td></tr>'
    );
  },
  team(label, col, rows) {
    return (
      '<div class="bt" style="--c:' +
      col +
      '"><b>' +
      label +
      '</b><table><tr><th></th><th>JOGADOR</th><th>AGENTE</th><th>K</th><th>D</th><th>K/D</th><th>CRÉDITOS</th></tr>' +
      (rows || '<tr><td colspan="7" class="em">sem jogadores</td></tr>') +
      '</table></div>'
    );
  },
  render() {
    const atk = Game.side === 'atk',
      me = this.row('VOCÊ · ' + myName(), Game.agent, Stats.me, 1, Econ.c),
      op = Net.c ? this.row('ADVERSÁRIO', Net.agk, Stats.op, 0) : '';
    $$('bdIn').innerHTML =
      '<h3>' +
      MAP_DATA[CURRENT_MAP].name.toUpperCase() +
      ' · RODADA ' +
      Round.n +
      ' · PLACAR ' +
      Round.score.a +
      ' x ' +
      Round.score.e +
      (Round.ot ? ' · PRORROGAÇÃO' : '') +
      '</h3>' +
      this.team('ATACANTES', '#d8453f', atk ? me : op) +
      this.team('DEFENSORES', '#3a5bd8', atk ? op : me);
  },
  tick(dt) {
    if (!this.on) return;
    this.t += dt;
    if (this.t > 0.3) {
      this.t = 0;
      this.render();
    }
  }
};
