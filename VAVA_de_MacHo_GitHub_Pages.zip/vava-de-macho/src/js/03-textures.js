/* ========= TEXTURAS PROCEDURAIS ========= */
function canvasTex(w, h, draw, rx, ry) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const x = c.getContext('2d');
  draw(x, w, h);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(rx, ry);
  t.encoding = THREE.sRGBEncoding;
  t.anisotropy = 4;
  return t;
}
function speckle(x, w, h, n, a) {
  for (let i = 0; i < n; i++) {
    x.fillStyle =
      Math.random() < 0.5
        ? `rgba(0,0,0,${Math.random() * a})`
        : `rgba(255,255,255,${Math.random() * a})`;
    x.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 2, 1 + Math.random() * 2);
  }
}
function stains(x, w, h, n) {
  for (let i = 0; i < n; i++) {
    const px = Math.random() * w,
      py = Math.random() * h,
      r = 10 + Math.random() * 40;
    const g = x.createRadialGradient(px, py, 0, px, py, r);
    g.addColorStop(0, 'rgba(60,50,40,.12)');
    g.addColorStop(1, 'rgba(60,50,40,0)');
    x.fillStyle = g;
    x.fillRect(px - r, py - r, r * 2, r * 2);
  }
}
function createMaterials() {
  tex.wall = canvasTex(
    256,
    256,
    (x, w, h) => {
      /* canvas y=0 é a BASE da parede e y=256 o TOPO (1 m ≈ 51 px). Até ~1,85 m (y<95): reboco liso e limpo, sem relevo que atrapalhe a mira.
       Acima da cabeça: janelas com venezianas, arandelas de ferro, trepadeiras e beiral. */
      const g = x.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, '#e0d2b8');
      g.addColorStop(0.45, '#e8dcc4');
      g.addColorStop(1, '#d6c4a4');
      x.fillStyle = g;
      x.fillRect(0, 0, w, h);
      speckle(x, w, h, 1400, 0.05);
      x.fillStyle = '#c98b6b';
      x.fillRect(0, 0, w, 12);
      x.fillStyle = 'rgba(0,0,0,.1)';
      x.fillRect(0, 12, w, 2); /* rodapé terracota liso */
      x.fillStyle = '#b5714f';
      x.fillRect(0, 92, w, 4);
      x.fillStyle = 'rgba(0,0,0,.12)';
      x.fillRect(0, 96, w, 5); /* faixa que marca o fim da zona limpa */
      for (const cx of [64, 192]) {
        x.fillStyle = '#b5a283';
        x.fillRect(cx - 30, 106, 60, 6);
        x.fillStyle = '#f4ecd9';
        x.fillRect(cx - 25, 112, 50, 78);
        x.beginPath();
        x.arc(cx, 190, 25, 0, Math.PI);
        x.fill();
        x.fillStyle = '#3a5368';
        x.fillRect(cx - 18, 118, 36, 72);
        x.beginPath();
        x.arc(cx, 190, 18, 0, Math.PI);
        x.fill();
        x.fillStyle = 'rgba(255,255,255,.22)';
        x.fillRect(cx - 18, 150, 14, 40);
        x.fillStyle = '#f4ecd9';
        x.fillRect(cx - 1.5, 118, 3, 90);
        x.fillRect(cx - 18, 158, 36, 3);
        x.fillStyle = '#4d7a5c';
        x.fillRect(cx - 42, 114, 13, 78);
        x.fillRect(cx + 29, 114, 13, 78); /* venezianas */
        x.strokeStyle = 'rgba(0,0,0,.28)';
        x.lineWidth = 1;
        for (let k = 0; k < 9; k++) {
          const yy = 118 + k * 8;
          x.beginPath();
          x.moveTo(cx - 42, yy);
          x.lineTo(cx - 29, yy);
          x.moveTo(cx + 29, yy);
          x.lineTo(cx + 42, yy);
          x.stroke();
        }
      }
      x.fillStyle = '#23262a';
      x.fillRect(125, 150, 6, 22);
      x.fillRect(120, 168, 16, 3); /* arandela de ferro */
      const gl = x.createRadialGradient(128, 178, 0, 128, 178, 14);
      gl.addColorStop(0, 'rgba(255,214,120,.95)');
      gl.addColorStop(1, 'rgba(255,214,120,0)');
      x.fillStyle = gl;
      x.fillRect(110, 160, 36, 36);
      x.fillStyle = '#b97b5a';
      x.fillRect(0, h - 12, w, 12);
      x.fillStyle = '#7a4130';
      x.fillRect(0, h - 14, w, 2);
      x.fillStyle = 'rgba(0,0,0,.14)';
      x.fillRect(0, h - 20, w, 6); /* beiral */
      for (let i = 0; i < 16; i++) {
        const vx = Math.random() * w,
          len = 22 + Math.random() * 60; /* trepadeiras penduradas do beiral */
        for (let k = 0; k < len; k += 3) {
          x.fillStyle =
            'rgba(' +
            ((55 + Math.random() * 30) | 0) +
            ',' +
            ((105 + Math.random() * 40) | 0) +
            ',50,' +
            (0.55 + Math.random() * 0.35) +
            ')';
          x.beginPath();
          x.arc(vx + Math.sin(k * 0.3) * 3, h - 14 - k, 2 + Math.random() * 3.5, 0, 7);
          x.fill();
        }
      }
    },
    0.25,
    0.2
  );
  tex.wall.offset.y = 0.8;
  tex.floor = canvasTex(
    256,
    256,
    (x, w, h) => {
      /* calçada de paralelepípedos cinza, polida */
      x.fillStyle = '#5f5c56';
      x.fillRect(0, 0, w, h);
      for (let r = 0; r < 16; r++)
        for (let i = 0; i < 8; i++) {
          const bx = i * 32 + (r % 2 ? 16 : 0) + (Math.random() - 0.5) * 2,
            by = r * 16,
            v = Math.floor(Math.random() * 26) - 13;
          for (const o of [-w, 0, w]) {
            x.fillStyle = 'rgb(' + (156 + v) + ',' + (153 + v) + ',' + (146 + v) + ')';
            x.beginPath();
            x.ellipse(bx + o + 16, by + 8, 14.5, 7.2, 0, 0, 7);
            x.fill();
            x.fillStyle = 'rgba(255,255,255,.09)';
            x.beginPath();
            x.ellipse(bx + o + 14, by + 6, 8, 3, 0, 0, 7);
            x.fill();
          }
        }
      stains(x, w, h, 8);
      speckle(x, w, h, 1800, 0.08);
    },
    0.25,
    0.25
  );
  tex.marble = canvasTex(
    256,
    256,
    (x, w, h) => {
      /* mármore claro do Bombsite A */
      x.fillStyle = '#e9e4da';
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < 10; i++) {
        x.strokeStyle = 'rgba(120,125,135,' + (0.06 + Math.random() * 0.1) + ')';
        x.lineWidth = 1 + Math.random() * 1.5;
        x.beginPath();
        let px = Math.random() * w,
          py = Math.random() * h;
        x.moveTo(px, py);
        for (let k = 0; k < 8; k++) {
          px += (Math.random() - 0.3) * 30;
          py += (Math.random() - 0.5) * 30;
          x.lineTo(px, py);
        }
        x.stroke();
      }
      speckle(x, w, h, 900, 0.04);
      x.strokeStyle = 'rgba(90,85,75,.35)';
      x.lineWidth = 2;
      for (let i = 0; i <= 4; i++) {
        x.beginPath();
        x.moveTo(i * 64, 0);
        x.lineTo(i * 64, h);
        x.moveTo(0, i * 64);
        x.lineTo(w, i * 64);
        x.stroke();
      }
    },
    0.25,
    0.25
  );
  tex.grass = canvasTex(
    128,
    128,
    (x, w, h) => {
      /* grama da sala do Link A */
      x.fillStyle = '#5f8f45';
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < 900; i++) {
        const g = (90 + Math.random() * 70) | 0;
        x.strokeStyle = 'rgba(' + ((50 + Math.random() * 40) | 0) + ',' + g + ',45,.7)';
        x.beginPath();
        const px = Math.random() * w,
          py = Math.random() * h;
        x.moveTo(px, py);
        x.lineTo(px + (Math.random() - 0.5) * 4, py - 3 - Math.random() * 5);
        x.stroke();
      }
    },
    0.5,
    0.5
  );
  tex.metal = canvasTex(
    128,
    128,
    (x, w, h) => {
      x.fillStyle = '#ece3d2';
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < 8; i++) {
        x.fillStyle = 'rgba(60,40,20,' + (0.04 + Math.random() * 0.1) + ')';
        x.fillRect(0, i * 16, w, 16);
        x.fillStyle = 'rgba(40,25,10,.5)';
        x.fillRect(0, i * 16, w, 1.5);
      }
      for (let i = 0; i < 90; i++) {
        x.strokeStyle = 'rgba(70,45,20,' + Math.random() * 0.18 + ')';
        const yy = Math.random() * h,
          xx = Math.random() * w;
        x.beginPath();
        x.moveTo(xx, yy);
        x.lineTo(xx + 10 + Math.random() * 30, yy + (Math.random() - 0.5) * 2);
        x.stroke();
      }
      x.strokeStyle = 'rgba(25,35,30,.85)';
      x.lineWidth = 7;
      x.strokeRect(3, 3, w - 6, h - 6);
      x.lineWidth = 2.5;
      x.beginPath();
      x.moveTo(10, 10);
      x.lineTo(w - 10, h - 10);
      x.moveTo(w - 10, 10);
      x.lineTo(10, h - 10);
      x.stroke();
      x.fillStyle = '#1b2420';
      for (const p of [
        [7, 7],
        [w - 11, 7],
        [7, h - 11],
        [w - 11, h - 11]
      ])
        x.fillRect(p[0], p[1], 5, 5);
    },
    1,
    1
  );
  tex.glow = canvasTex(
    128,
    128,
    (x, w, h) => {
      /* detalhes de radianite (mapa de emissão) */
      x.fillStyle = '#000';
      x.fillRect(0, 0, w, h);
      const g = x.createRadialGradient(64, 64, 0, 64, 64, 22);
      g.addColorStop(0, '#ffb3ff');
      g.addColorStop(1, 'rgba(255,100,255,0)');
      x.fillStyle = g;
      x.fillRect(0, 0, w, h);
      x.fillStyle = '#5ff2ff';
      for (const p of [
        [12, 12],
        [w - 18, 12],
        [12, h - 18],
        [w - 18, h - 18]
      ])
        x.fillRect(p[0], p[1], 6, 6);
    },
    1,
    1
  );
  mats.wall = new THREE.MeshStandardMaterial({
    map: tex.wall,
    roughness: 0.92,
    metalness: 0,
    side: THREE.DoubleSide
  });
  mats.floor = new THREE.MeshStandardMaterial({ map: tex.floor, roughness: 0.95, metalness: 0 });
  for (const k in BOX_C)
    mats[k] = new THREE.MeshStandardMaterial({
      map: tex.metal,
      color: BOX_C[k],
      roughness: 0.7,
      metalness: 0.15,
      emissive: 0xffffff,
      emissiveMap: tex.glow,
      emissiveIntensity: 0.55
    });
  mats.edge = new THREE.LineBasicMaterial({ color: 0x2b2118 });
  tex.wood = canvasTex(
    128,
    128,
    (x, w, h) => {
      /* caixa de madeira amarela amarrada com corda */
      x.fillStyle = '#c79a3f';
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < 8; i++) {
        x.fillStyle = 'rgba(60,35,10,' + (0.05 + Math.random() * 0.12) + ')';
        x.fillRect(0, i * 16, w, 16);
        x.fillStyle = 'rgba(50,30,8,.55)';
        x.fillRect(0, i * 16, w, 1.5);
      }
      for (let i = 0; i < 70; i++) {
        x.strokeStyle = 'rgba(90,55,15,' + Math.random() * 0.25 + ')';
        const yy = Math.random() * h,
          xx = Math.random() * w;
        x.beginPath();
        x.moveTo(xx, yy);
        x.lineTo(xx + 8 + Math.random() * 28, yy + (Math.random() - 0.5) * 2);
        x.stroke();
      }
      x.fillStyle = '#8a5e22';
      x.fillRect(0, 0, w, 8);
      x.fillRect(0, h - 8, w, 8);
      x.fillRect(0, 0, 8, h);
      x.fillRect(w - 8, 0, 8, h);
      x.strokeStyle = '#d9c79a';
      x.lineWidth = 4;
      x.setLineDash([6, 3]);
      x.beginPath();
      x.moveTo(0, h * 0.5);
      x.lineTo(w, h * 0.5);
      x.moveTo(w * 0.5, 0);
      x.lineTo(w * 0.5, h);
      x.stroke();
      x.setLineDash([]);
    },
    1,
    1
  );
  tex.logEnd = canvasTex(
    64,
    64,
    (x, w, h) => {
      x.fillStyle = '#c9a26b';
      x.fillRect(0, 0, w, h);
      for (let r = 30; r > 2; r -= 4) {
        x.strokeStyle = 'rgba(90,55,25,' + (0.35 + Math.random() * 0.3) + ')';
        x.lineWidth = 1.5;
        x.beginPath();
        x.arc(32, 32, r, 0, 7);
        x.stroke();
      }
    },
    1,
    1
  );
  tex.bark = canvasTex(
    64,
    64,
    (x, w, h) => {
      x.fillStyle = '#6b4a2f';
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < 40; i++) {
        x.fillStyle = 'rgba(0,0,0,' + Math.random() * 0.3 + ')';
        x.fillRect(Math.random() * w, 0, 1 + Math.random() * 2, h);
      }
    },
    1,
    2
  );
  tex.brickD = canvasTex(
    128,
    128,
    (x, w, h) => {
      /* tijolo vermelho escuro do canto do Vinho */
      x.fillStyle = '#3d2420';
      x.fillRect(0, 0, w, h);
      for (let r = 0; r < 8; r++)
        for (let i = 0; i < 4; i++) {
          const bx = i * 32 + (r % 2 ? 16 : 0),
            v = (Math.random() * 20) | 0;
          for (const o of [-w, 0]) {
            x.fillStyle =
              'rgb(' + (110 + v) + ',' + ((48 + v / 2) | 0) + ',' + ((40 + v / 2) | 0) + ')';
            x.fillRect(bx + o + 1, r * 16 + 1, 30, 14);
          }
        }
      stains(x, w, h, 6);
      speckle(x, w, h, 900, 0.12);
    },
    0.5,
    0.5
  );
  tex.grate = canvasTex(
    64,
    64,
    (x, w, h) => {
      x.fillStyle = '#14171a';
      x.fillRect(0, 0, w, h);
      x.fillStyle = '#4b5259';
      for (let i = 0; i < 8; i++) x.fillRect(i * 8 + 2, 2, 4, h - 4);
      x.strokeStyle = '#6b737a';
      x.lineWidth = 3;
      x.strokeRect(1.5, 1.5, w - 3, h - 3);
    },
    1,
    1
  );
  tex.door = canvasTex(
    128,
    128,
    (x, w, h) => {
      /* chapa de aço corrugado cinza-escuro */
      x.fillStyle = '#454b52';
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < 16; i++) {
        x.fillStyle = i % 2 ? 'rgba(255,255,255,.09)' : 'rgba(0,0,0,.28)';
        x.fillRect(i * 8, 0, 8, h);
      }
      x.fillStyle = '#d9b21c';
      x.fillRect(0, 0, w, 10);
    },
    1,
    1
  );
  tex.grass = canvasTex(
    128,
    128,
    (x, w, h) => {
      /* grama + terra batida + folhas caídas */
      x.fillStyle = '#5f8f45';
      x.fillRect(0, 0, w, h);
      for (let i = 0; i < 5; i++) {
        const px = Math.random() * w,
          py = Math.random() * h,
          g = x.createRadialGradient(px, py, 0, px, py, 18);
        g.addColorStop(0, 'rgba(110,80,50,.55)');
        g.addColorStop(1, 'rgba(110,80,50,0)');
        x.fillStyle = g;
        x.fillRect(px - 18, py - 18, 36, 36);
      }
      for (let i = 0; i < 900; i++) {
        const g = (90 + Math.random() * 70) | 0;
        x.strokeStyle = 'rgba(' + ((50 + Math.random() * 40) | 0) + ',' + g + ',45,.7)';
        x.beginPath();
        const px = Math.random() * w,
          py = Math.random() * h;
        x.moveTo(px, py);
        x.lineTo(px + (Math.random() - 0.5) * 4, py - 3 - Math.random() * 5);
        x.stroke();
      }
      const lc = ['#a8742f', '#c19a3a', '#8a5a24'];
      for (let i = 0; i < 40; i++) {
        x.fillStyle = lc[i % 3];
        x.fillRect(Math.random() * w, Math.random() * h, 3, 2);
      }
    },
    0.5,
    0.5
  );
  const po = { polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 };
  mats.marble = new THREE.MeshStandardMaterial({
    map: tex.marble,
    roughness: 0.15,
    metalness: 0.1,
    ...po
  });
  mats.dry = new THREE.MeshStandardMaterial({
    map: tex.floor,
    color: 0xb09a7c,
    roughness: 1,
    metalness: 0,
    ...po
  }); /* pedra seca e rústica do B */
  mats.grass = new THREE.MeshStandardMaterial({
    map: tex.grass,
    roughness: 1,
    metalness: 0,
    ...po
  });
  mats.W = new THREE.MeshStandardMaterial({
    map: tex.wood,
    roughness: 0.85,
    metalness: 0
  }); /* madeira amarela */
  mats.brickD = new THREE.MeshStandardMaterial({
    map: tex.brickD,
    roughness: 0.95,
    metalness: 0,
    ...po
  });
  mats.grate = new THREE.MeshStandardMaterial({
    map: tex.grate,
    roughness: 0.5,
    metalness: 0.7,
    ...po
  });
}
function letterTex(ch) {
  return canvasTex(
    256,
    256,
    (x, w, h) => {
      x.clearRect(0, 0, w, h);
      x.strokeStyle = 'rgba(235,225,205,.85)';
      x.lineWidth = 10;
      x.beginPath();
      x.arc(128, 128, 100, 0, 7);
      x.stroke();
      x.fillStyle = 'rgba(240,232,215,.9)';
      x.font = 'bold 150px system-ui,sans-serif';
      x.textAlign = 'center';
      x.textBaseline = 'middle';
      x.fillText(ch, 128, 138);
    },
    1,
    1
  );
}
