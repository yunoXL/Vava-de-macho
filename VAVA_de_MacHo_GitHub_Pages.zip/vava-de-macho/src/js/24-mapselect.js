/* ========= SELEÇÃO DE MAPA (Menu → Mapa → Agente → Jogo) ========= */
function mapPreview(m) {
  const L = m.layout;
  if (!L)
    return '<svg viewBox="0 0 220 138"><rect width="220" height="138" fill="#10161d"/><path d="M0 34H220M0 69H220M0 103H220M55 0V138M110 0V138M165 0V138" stroke="rgba(255,255,255,.07)"/><rect x="92" y="62" width="36" height="28" rx="4" fill="#7d8996"/><path d="M99 62v-9a11 11 0 0 1 22 0v9" fill="none" stroke="#7d8996" stroke-width="5" stroke-linecap="round"/></svg>';
  const f = p => p.map(q => q[0] + ',' + q[1]).join(' '),
    hx = c => '#' + c.toString(16).padStart(6, '0');
  const bx = L.outer.map(p => p[0]),
    by = L.outer.map(p => p[1]),
    x0 = Math.min(...bx) - 60,
    y0 = Math.min(...by) - 60,
    bw = Math.max(...bx) - x0 + 60,
    bh = Math.max(...by) - y0 + 60;
  return (
    '<svg viewBox="' +
    x0 +
    ' ' +
    y0 +
    ' ' +
    bw +
    ' ' +
    bh +
    '" preserveAspectRatio="xMidYMid meet"><rect x="' +
    x0 +
    '" y="' +
    y0 +
    '" width="' +
    bw +
    '" height="' +
    bh +
    '" fill="#10161d"/><polygon points="' +
    f(L.outer) +
    '" fill="#9e988d"/>' +
    Object.values(L.spawns)
      .map(
        q =>
          '<rect x="' +
          q.rect[0] +
          '" y="' +
          q.rect[1] +
          '" width="' +
          (q.rect[2] - q.rect[0]) +
          '" height="' +
          (q.rect[3] - q.rect[1]) +
          '" fill="' +
          hx(q.color) +
          '" opacity=".8"/>'
      )
      .join('') +
    [L.plantA, L.plantB]
      .map(p => '<polygon points="' + f(p) + '" fill="#c4605a" opacity=".55"/>')
      .join('') +
    L.solids
      .map(
        p => '<polygon points="' + f(p) + '" fill="#d4c2a6" stroke="#a85d43" stroke-width="12"/>'
      )
      .join('') +
    '<g>' +
    [L.outer]
      .concat(L.solids)
      .map(
        (p, n) =>
          '<polygon class="dr" pathLength="1" style="--n:' +
          Math.min(n, 24) +
          '" points="' +
          f(p) +
          '"/>'
      )
      .join('') +
    '</g>' +
    ['A', 'B']
      .map(
        k =>
          '<text x="' +
          L.sites[k][0] +
          '" y="' +
          L.sites[k][1] +
          '" font-size="200" font-weight="800" font-family="system-ui,sans-serif" fill="#fff" text-anchor="middle" dominant-baseline="central">' +
          k +
          '</text>'
      )
      .join('') +
    '</svg>'
  );
}
const MapSelect = {
  pick: null,
  cb: null,
  on: false,
  list: Object.values(MAP_DATA),
  init() {
    $$('msGrid').innerHTML = this.list
      .map(
        (m, i) =>
          '<div class="mp' +
          (m.locked ? ' lk' : '') +
          '" data-i="' +
          i +
          '" style="--c:' +
          m.c +
          '"><div class="pv">' +
          mapPreview(m) +
          '</div><div class="mi"><span class="st">' +
          (m.locked ? 'EM BREVE' : 'DISPONÍVEL') +
          '</span><b>' +
          m.name +
          '</b><i>' +
          m.tag +
          '</i><p>' +
          m.desc +
          '</p></div></div>'
      )
      .join('');
    $$('msGrid').onclick = e => {
      const c = e.target.closest('.mp');
      if (c) this.sel(+c.dataset.i);
    };
    $$('msOk').onclick = () => this.ok();
    addEventListener('keydown', e => {
      if (!this.on) return;
      const k = e.key;
      if (k === 'Enter') this.ok();
      else if (/^[1-3]$/.test(k)) this.sel(+k - 1);
      else if (k === 'Escape') this.cancel();
      else return;
      e.preventDefault();
    });
  },
  sel(i) {
    const m = this.list[i];
    if (!m || m.locked) return; /* mapas bloqueados não respondem */
    this.pick = i;
    $$('msGrid').classList.add('pk'); /* os outros cartões escurecem */
    [...$$('msGrid').children].forEach((c, j) => c.classList.toggle('on', j === i));
    $$('msOk').disabled = false;
    $$('msMsg').style.visibility = 'hidden';
  },
  open(cb) {
    this.on = true;
    this.cb = cb;
    this.pick = null;
    [...$$('msGrid').children].forEach(c => c.classList.remove('on'));
    $$('msGrid').classList.remove('pk');
    $$('msOk').disabled = true;
    $$('msMsg').style.visibility = 'visible';
    $$('mapSelect').classList.add('on');
  },
  ok() {
    if (!this.on || this.pick === null) return;
    const m = this.list[this.pick],
      cb = this.cb;
    this.on = false;
    this.cb = null;
    $$('mapSelect').classList.remove('on');
    selectMap(m.id);
    Game.map = m.id;
    window.MAP && MAP.onMap && MAP.onMap(m);
    cb && cb();
  },
  cancel() {
    this.on = false;
    this.cb = null;
    $$('mapSelect').classList.remove('on');
    Net.close();
    Menu.cancel();
  }
};
