/* ========= ABAS DO MENU · AGENTES (habilidades, estatísticas, skins) · CARREIRA (perfil) =========
   Fica salvo via Store ('vdh_prof'): na conta online vai para o banco do servidor; convidado fica só neste navegador. */

/* Skins: trocam só as cores do agente (s=roupa, s2=roupa escura, a=detalhe/brilho, h/h2=cabelo). */
const SKINS = {
  phoenix: [
    { n: 'Brasa Negra', o: { s: 0x1c1c1c, s2: 0x0b0b0b, a: 0xff3b1f, h: 0x111111, h2: 0xff3b1f } },
    { n: 'Sol Dourado', o: { s: 0xe0a820, s2: 0x8a6208, a: 0xfff2a8, h: 0xfff2a8, h2: 0xffffff } },
    { n: 'Cinzas', o: { s: 0x6b6f78, s2: 0x3a3d44, a: 0xffffff, h: 0xcfd3da, h2: 0xffffff } }
  ],
  neon: [
    { n: 'Lima Tóxica', o: { s: 0x2f8f2f, s2: 0x14501a, a: 0xb6ff3b, h: 0x0f2a0f, h2: 0xb6ff3b } },
    { n: 'Rosa Choque', o: { s: 0xb8267a, s2: 0x6a1148, a: 0xff7ad9, h: 0x2a0a22, h2: 0xff7ad9 } },
    { n: 'Noite Branca', o: { s: 0xe8ecf4, s2: 0x9aa3b8, a: 0x6a8cff, h: 0xdfe6ff, h2: 0x6a8cff } }
  ],
  jett: [
    { n: 'Tempestade', o: { s: 0x2c3e5a, s2: 0x16233a, a: 0x7fd1ff, h: 0x9fb6d6, h2: 0x7fd1ff } },
    { n: 'Rubi', o: { s: 0xb11c2e, s2: 0x6a0f1b, a: 0xffb3bd, h: 0xffe3e6, h2: 0xff7a8a } },
    { n: 'Jade', o: { s: 0x1f8f74, s2: 0x0f5646, a: 0x7dffd9, h: 0xd8fff3, h2: 0x7dffd9 } }
  ],
  omen: [
    { n: 'Sangue Lunar', o: { s: 0x5a1020, s2: 0x2a0810, a: 0xff4d6d, h: 0x1a0a10, h2: 0xff4d6d } },
    { n: 'Fantasma', o: { s: 0xcfd6e6, s2: 0x7f89a3, a: 0xffffff, h: 0xeef1f8, h2: 0xaebcff } },
    { n: 'Abismo', o: { s: 0x0c2b3a, s2: 0x051721, a: 0x2fe0c8, h: 0x061018, h2: 0x2fe0c8 } }
  ],
  yoru: [
    { n: 'Vermelho Riscado', o: { s: 0xa8141f, s2: 0x5e0a11, a: 0xff9a3b, h: 0x1a0a0a, h2: 0xff9a3b } },
    { n: 'Ouro Fosco', o: { s: 0x8a6d1d, s2: 0x4a3a0e, a: 0xffe27a, h: 0x1a1608, h2: 0xffe27a } },
    { n: 'Gelo', o: { s: 0x7fb2e8, s2: 0x3a6ea8, a: 0xffffff, h: 0xe8f3ff, h2: 0xffffff } }
  ]
};
/* Skins se ganham por mérito, com as estatísticas DAQUELE agente (k=abates, w=vitórias, h=headshots).
   SKIN_REQ[i] vale para a skin i+1 de cada agente. Para mudar a meta, mexa só aqui. */
const SKIN_REQ = [
  { key: 'k', n: 100, lab: 'ABATES' },
  { key: 'w', n: 20, lab: 'VITÓRIAS' },
  { key: 'h', n: 75, lab: 'HEADSHOTS' }
];
const hexc = n => '#' + n.toString(16).padStart(6, '0');
const Skins = {
  ctx: null /* {id, i}: skin forçada enquanto um corpo/mão é montado */,
  /* a skin i (1..3) do agente está liberada? (a padrão, 0, sempre está) */
  open(id, i) {
    const r = SKIN_REQ[i - 1];
    return !i || !r || Profile.of(id)[r.key] >= r.n;
  },
  /* skin escolhida (0 = padrão, 1..3 = SKINS[id][i-1]); skin ainda bloqueada vira padrão */
  sel(id) {
    const i = (Profile.d.skins && Profile.d.skins[id]) | 0;
    return SKINS[id] && i >= 1 && i <= SKINS[id].length && this.open(id, i) ? i : 0;
  },
  /* cores do agente com a skin aplicada (se for o caso) */
  colors(id, i) {
    const b = AGS[id] || AGS.def;
    return i && SKINS[id] && SKINS[id][i - 1] ? Object.assign({}, b, SKINS[id][i - 1].o) : b;
  },
  /* usada por agentOf(): só aplica skin dentro de Skins.run */
  of(id) {
    const c = this.ctx;
    return this.colors(id, c && c.id === id ? c.i : 0);
  },
  /* executa f() com a skin i do agente id aplicada (monta corpos e mãos já coloridos) */
  run(id, i, f) {
    const old = this.ctx;
    this.ctx = { id, i: i | 0 };
    try {
      return f();
    } finally {
      this.ctx = old;
    }
  }
};
SKIN_HOOK = id => Skins.of(id);
SKIN_RUN = (id, i, f) => Skins.run(id, i, f);

/* Perfil e estatísticas por agente: partidas (p), vitórias (w), abates (k), mortes (d), headshots (h) */
const Profile = {
  d: { code: '', desc: '', skins: {}, st: {} },
  load() {
    try {
      const o = JSON.parse(Store.get('vdh_prof') || '{}');
      this.d = Object.assign({ code: '', desc: '', skins: {}, st: {} }, o);
    } catch (_) {}
    if (!/^\d{4}$/.test(this.d.code)) {
      this.d.code = String(1000 + Math.floor(Math.random() * 9000)); /* código do perfil (#1234) */
      this.save();
    }
  },
  save() {
    Store.set('vdh_prof', JSON.stringify(this.d));
  },
  code() {
    return '#' + this.d.code;
  },
  /* soma n em uma estatística do agente (ex.: rec('jett','k')) */
  rec(agent, key, n) {
    const a = agent || 'phoenix',
      s = (this.d.st[a] = this.d.st[a] || { p: 0, w: 0, k: 0, d: 0, h: 0 });
    const before = SKINS[a] ? SKINS[a].map((_, j) => Skins.open(a, j + 1)) : [];
    s[key] = (s[key] | 0) + (n || 1);
    this.save();
    before.forEach((was, j) => {
      if (!was && Skins.open(a, j + 1)) toast('SKIN DESBLOQUEADA: ' + SKINS[a][j].n.toUpperCase());
    }); /* avisa na hora em que a meta é batida */
  },
  of(agent) {
    return Object.assign({ p: 0, w: 0, k: 0, d: 0, h: 0 }, this.d.st[agent] || {});
  },
  total() {
    const t = { p: 0, w: 0, k: 0, d: 0, h: 0 };
    for (const a in this.d.st) for (const k in t) t[k] += this.of(a)[k];
    return t;
  },
  init() {
    this.load();
    $$('mCode2').textContent = this.code();
  }
};

/* caixinhas de estatística (partidas, vitórias, abates, mortes, K/D, headshots) */
function statGrid(s) {
  const kd = s.d ? (s.k / s.d).toFixed(2) : s.k ? s.k.toFixed(2) : '0.00',
    it = [
      ['PARTIDAS', s.p],
      ['VITÓRIAS', s.w],
      ['ABATES', s.k],
      ['MORTES', s.d],
      ['K/D', kd],
      ['HEADSHOTS', s.h]
    ];
  return (
    '<div class="stg">' + it.map(x => '<div><b>' + x[1] + '</b><i>' + x[0] + '</i></div>').join('') + '</div>'
  );
}

/* Aba AGENTES: escolher um agente para ver habilidades, estatísticas e skins */
const AgentsPage = {
  i: 0,
  TYPE: {
    wall: 'Parede',
    proj: 'Lançável',
    recall: 'Retorno',
    bar: 'Energia',
    buff: 'Reforço',
    jump: 'Impulso',
    dash: 'Arrancada',
    knives: 'Facas',
    step: 'Teleporte',
    point: 'Marcação',
    aerial: 'Aéreo',
    decoy: 'Isca',
    gate: 'Portal',
    ghost: 'Fantasma'
  },
  render() {
    const a = AGENTS[this.i],
      keys = ['C', 'Q', 'E', 'X'],
      cur = Skins.sel(a.id),
      st = Profile.of(a.id);
    $$('agpList').innerHTML = AGENTS.map(
      (g, j) =>
        '<div class="agi' +
        (j === this.i ? ' on' : '') +
        '" data-i="' +
        j +
        '" style="--c:' +
        g.c +
        '"><svg viewBox="0 0 64 64">' +
        g.i +
        '</svg>' +
        g.name.toUpperCase() +
        '</div>'
    ).join('');
    const abil = (ABI[a.id] || [])
      .map(
        (x, j) =>
          '<div class="abl"><kbd>' +
          keys[j] +
          '</kbd><b>' +
          x.n +
          '</b><span>' +
          (this.TYPE[x.t] || '') +
          ' · ' +
          (x.ult
            ? 'ULTIMATE ' + ULT_COST + ' pts'
            : x.chg
              ? CHG[x.chg].nm + ' · comprada na loja (máx. ' + CHG[x.chg].max + ')'
              : x.rr
                ? x.rr + ' por rodada' + (x.rk ? ' (+1 por abate)' : '')
                : x.cd
                ? 'recarga ' + x.cd + ' s'
                : 'passiva') +
          '</span></div>'
      )
      .join('');
    const sk = [{ n: 'Padrão', o: null }]
      .concat(SKINS[a.id] || [])
      .map((k, j) => {
        const c = Skins.colors(a.id, j),
          r = SKIN_REQ[j - 1],
          lock = j && !Skins.open(a.id, j);
        return (
          '<div class="sk' +
          (j === cur ? ' on' : '') +
          (lock ? ' lock' : '') +
          '" data-k="' +
          j +
          '"><div class="dots"><i style="background:' +
          hexc(c.s) +
          '"></i><i style="background:' +
          hexc(c.a) +
          '"></i><i style="background:' +
          hexc(c.h) +
          '"></i></div>' +
          k.n.toUpperCase() +
          (lock
            ? '<em>🔒 ' + Math.min(st[r.key], r.n) + '/' + r.n + ' ' + r.lab + '</em>'
            : j
              ? '<em class="ok">DESBLOQUEADA</em>'
              : '') +
          '</div>'
        );
      })
      .join('');
    $$('agpBox').style.setProperty('--c', a.c);
    $$('agpBox').innerHTML =
      '<div class="pb" style="--c:' +
      a.c +
      '"><h2>' +
      a.name.toUpperCase() +
      ' · ' +
      a.role.toUpperCase() +
      '</h2><p>' +
      a.d +
      '</p></div><div class="pb" style="--c:' +
      a.c +
      '"><h2>HABILIDADES</h2>' +
      abil +
      '</div><div class="pb wide" style="--c:' +
      a.c +
      '"><h2>ESTATÍSTICAS COM ' +
      a.name.toUpperCase() +
      '</h2>' +
      statGrid(st) +
      '</div><div class="pb wide" style="--c:' +
      a.c +
      '"><h2>SKINS · SE GANHAM JOGANDO</h2><div class="skg">' +
      sk +
      '</div></div>';
  },
  init() {
    $$('agpList').onclick = e => {
      const c = e.target.closest('.agi');
      if (!c) return;
      this.i = +c.dataset.i;
      this.render();
    };
    $$('agpBox').onclick = e => {
      const c = e.target.closest('.sk');
      if (!c) return;
      const a = AGENTS[this.i],
        k = +c.dataset.k,
        r = SKIN_REQ[k - 1];
      if (k && !Skins.open(a.id, k)) {
        toast('Bloqueada: faça ' + r.n + ' ' + r.lab.toLowerCase() + ' com ' + a.name);
        return;
      }
      Profile.d.skins[a.id] = +c.dataset.k;
      Profile.save();
      this.render();
      toast('Skin: ' + (+c.dataset.k ? SKINS[a.id][+c.dataset.k - 1].n : 'Padrão'));
    };
    const i = AGENTS.findIndex(a => a.id === Game.agent);
    if (i >= 0) this.i = i;
  }
};

/* Aba CARREIRA: perfil no próprio computador (nome, descrição, estatísticas gerais) */
const Career = {
  render() {
    const nm = (($$('mName').value || '').trim() || 'JOGADOR').toUpperCase(),
      rows = AGENTS.map(a => {
        const s = Profile.of(a.id);
        return (
          '<tr><td style="color:' +
          a.c +
          '">' +
          a.name.toUpperCase() +
          '</td><td>' +
          s.p +
          '</td><td>' +
          s.w +
          '</td><td>' +
          s.k +
          '</td><td>' +
          s.d +
          '</td><td>' +
          s.h +
          '</td></tr>'
        );
      }).join('');
    $$('caBox').innerHTML =
      '<div class="pb wide"><div class="cap"><div class="av">' +
      nm.charAt(0) +
      '</div><div><b>' +
      nm +
      '</b><small>' +
      Profile.code() +
      (Auth.user
        ? ' · conta online (salva no servidor)'
        : ' · convidado (salvo só neste computador) · mude o nome no canto de cima') +
      '</small></div></div></div>' +
      '<div class="pb wide"><h2>DESCRIÇÃO</h2><textarea id="caDesc" maxlength="140" placeholder="Escreva algo sobre você…"></textarea></div>' +
      '<div class="pb wide"><h2>ESTATÍSTICAS GERAIS</h2>' +
      statGrid(Profile.total()) +
      '</div><div class="pb wide"><h2>POR AGENTE</h2><table class="pt2"><tr><th>AGENTE</th><th>PARTIDAS</th><th>VITÓRIAS</th><th>ABATES</th><th>MORTES</th><th>HEADSHOTS</th></tr>' +
      rows +
      '</table></div><div class="pb wide"><h2>OUTROS JOGADORES</h2><p class="lock">Procurar outros jogadores precisa de contas online. Fica para a próxima fase.</p><button class="ghostbtn" id="caReset">ZERAR ESTATÍSTICAS</button></div>';
    const t = $$('caDesc');
    t.value = Profile.d.desc || '';
    t.oninput = () => {
      Profile.d.desc = t.value;
      Profile.save();
    };
    $$('caReset').onclick = () => {
      if (!confirm('Zerar todas as estatísticas deste perfil?')) return;
      Profile.d.st = {};
      Profile.save();
      this.render();
    };
  }
};

/* Barra de cima fixa: cada aba troca só o conteúdo de baixo (JOGAR, ARSENAL, AGENTES, CARREIRA, ATUALIZAÇÕES) */
const Tabs = {
  i: 0,
  ids: ['mMain', 'arMenu', 'agMenu', 'caMenu', 'upMenu', 'cfMenu'],
  go(i) {
    this.i = i;
    this.ids.forEach((id, j) => $$(id).classList.toggle('on', j === i));
    [...$$('mTabs').children].forEach((e, j) => e.classList.toggle('on', j === i));
    if (i === 1) ArMenu.render();
    else if (i === 2) AgentsPage.render();
    else if (i === 3) Career.render();
    else if (i === 4) Updates.render();
    else if (i === 5) Settings.mount($$('cfHost'), 'inmenu');
    $$('mPages').scrollTop = 0;
  },
  init() {
    [...$$('mTabs').children].forEach((e, i) => (e.onclick = () => this.go(i)));
    AgentsPage.init();
    addEventListener('keydown', e => {
      /* ESC volta para JOGAR (menos quando uma tela de seleção está aberta por cima) */
      if (e.key !== 'Escape' || !this.i || !document.body.classList.contains('menu')) return;
      if (document.querySelector('#agents.on,#mapSelect.on,#sideSel.on')) return;
      e.preventDefault();
      this.go(0);
    });
  }
};
