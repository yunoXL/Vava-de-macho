/* ========= HABILIDADES (5 agentes). Recargas e custo de ultimate são PROVISÓRIOS ========= */
const Mv = {
  cr: 0,
  walk: 0,
  gm: 1,
  quiet: 0,
  air: 0,
  stt: '',
  speed: 1,
  bs: 1,
  bt: 0,
  vy: 0,
  h: 0,
  dx: 0,
  dz: 0,
  dt: 0,
  ghost: 0,
  dmg: 1
}; /* efeitos no movimento do jogador */
const ULT_COST = 5; /* pontos; ganha 1 por abate, 1 ao plantar e 1 ao desarmar a spike (Abil.addUlt(n)) */
/* cargas compradas na loja (smoke/flash): free = já vem de graça a cada rodada · max = total que pode carregar */
const CHG = {
  smoke: { free: 1, max: 3, price: 200, nm: 'Smoke' },
  flash: { free: 1, max: 2, price: 250, nm: 'Flash' }
};
const ABI = {
  phoenix: [
    {
      n: 'Chama',
      t: 'wall',
      rr: 1,
      len: 24,
      gr: 0.35,
      col: 0xff6a1f,
      dur: 8,
      h: 5.5,
      flame: 1,
      heal: 15,
      dps: 25
    },
    {
      n: 'Mão Quente',
      t: 'proj',
      rr: 1,
      land: 'zone',
      col: 0xff7a2f,
      r: 5,
      dur: 4,
      heal: 20,
      dps: 15,
      lava: 1,
      trail: 1
    },
    {
      n: 'Bola Curva',
      t: 'proj',
      chg: 'flash',
      land: 'flash',
      curve: 1,
      col: 0xfff0b0,
      life: 0.75,
      fd: 1.5
    },
    { n: 'De Volta à Ação', t: 'recall', ult: 1, dur: 10, col: 0xff7a2f }
  ],
  neon: [
    {
      n: 'Parede Elétrica',
      t: 'wall',
      rr: 1,
      len: 34,
      twin: 1,
      blk: 1,
      gr: 0.6,
      col: 0x8a5cff,
      dur: 7,
      h: 7,
      dmg: 20,
      stun: 0.5
    },
    {
      n: 'Ricochete',
      t: 'proj',
      rr: 1,
      land: 'zone',
      bounce: 1,
      fast: 1,
      col: 0xa678ff,
      r: 4.5,
      dur: 2.5,
      life: 0.55,
      slow: 0.4,
      trail: 1
    },
    { n: 'Equipamento Voltaico', t: 'bar', mult: 1.35, drain: 20, rech: 7 },
    { n: 'Sobrecarga', t: 'buff', ult: 1, mult: 1.3, dur: 15, over: 1 }
  ],
  jett: [
    { n: 'Corrente Ascendente', t: 'jump', cd: 10, v: 15.6 },
    { n: 'Vento de Cauda', t: 'dash', cd: 12 },
    {
      n: 'Véu de Névoa',
      t: 'proj',
      chg: 'smoke',
      land: 'smoke',
      col: 0xdfe8f0,
      r: 3.2,
      dur: 11,
      life: 1.2
    },
    { n: 'Tempestade de Aço', t: 'knives', ult: 1, k: 8 }
  ],
  omen: [
    { n: 'Passos Tenebrosos', t: 'step', rr: 2, range: 10, ch: 0.7, hold: 1 },
    {
      n: 'Visão Obscura',
      t: 'proj',
      chg: 'flash',
      land: 'para',
      str: 1,
      life: 1,
      col: 0x6a2fb0,
      dur: 2.5,
      big: 1,
      trail: 1
    },
    { n: 'Névoa Escura', t: 'point', chg: 'smoke', col: 0x2a1f45, r: 3.2, h: 5, dur: 28, range: 60 },
    { n: 'Salto das Sombras', t: 'aerial', ult: 1, ch: 2.5 }
  ],
  yoru: [
    { n: 'Farsa', t: 'decoy', rr: 1 },
    {
      n: 'Cegueira',
      t: 'proj',
      chg: 'flash',
      land: 'flash',
      bounce: 1,
      col: 0x4fe0ff,
      fuse: 0.6,
      fd: 1.2
    },
    { n: 'Salto Dimensional', t: 'gate', rr: 2, rk: 1, col: 0x4fa8ff, life: 1.67, mk: 15 },
    { n: 'Desvio Dimensional', t: 'ghost', ult: 1, dur: 10 }
  ]
};
const IC = {
  bar: '<path d="M36 4L14 36h14l-4 24 26-34H34z"/>',
  para: '<path d="M8 32L54 12v40z"/>',
  step: '<ellipse cx="32" cy="32" rx="12" ry="24"/>',
  aerial: '<circle cx="32" cy="32" r="22"/><path d="M32 4v12M32 48v12M4 32h12M48 32h12"/>',
  wall: '<path d="M12 54V14M52 54V14M12 34c8-9 12 9 20 0s12 9 20 0"/>',
  proj: '<circle cx="32" cy="38" r="10"/><path d="M14 14l12 14M30 8l4 14M48 14l-12 14"/>',
  zone: '<ellipse cx="32" cy="46" rx="22" ry="8"/><path d="M32 8c6 8 8 12 8 18a8 8 0 0 1-16 0c0-6 2-10 8-18z"/>',
  smoke: '<path d="M18 48a10 10 0 0 1 2-20 12 12 0 0 1 24-2 9 9 0 0 1 2 22z"/>',
  flash:
    '<circle cx="32" cy="32" r="8"/><path d="M32 6v10M32 48v10M6 32h10M48 32h10M14 14l7 7M43 43l7 7M50 14l-7 7M21 43l-7 7"/>',
  jump: '<path d="M32 56V10M16 26l16-16 16 16"/>',
  dash: '<path d="M8 22h30M14 34h40M8 46h26"/>',
  buff: '<path d="M36 4L14 36h14l-4 24 26-34H34z"/>',
  blink: '<ellipse cx="32" cy="32" rx="12" ry="24"/>',
  gate: '<ellipse cx="32" cy="32" rx="12" ry="24"/><path d="M4 32h14M12 26l6 6-6 6"/>',
  recall: '<path d="M44 12a22 22 0 1 0 8 20M44 4v10H34"/>',
  cone: '<path d="M8 32L54 12v40z"/>',
  point: '<path d="M18 48a10 10 0 0 1 2-20 12 12 0 0 1 24-2 9 9 0 0 1 2 22z"/>',
  decoy: '<circle cx="32" cy="16" r="8"/><path d="M18 56c0-20 6-28 14-28s14 8 14 28"/>',
  ghost: '<path d="M16 56V28a16 16 0 0 1 32 0v28l-8-6-8 6-8-6z"/>',
  knives: '<path d="M12 52L44 10l8 6-32 40z"/>'
};
const bm = (c, o) =>
  new THREE.MeshBasicMaterial({
    color: c,
    transparent: true,
    opacity: o,
    depthWrite: false,
    side: THREE.DoubleSide
  });
const DAG = (L, H, t, flip) => {
  const g = geoOf({
    g: 'e',
    a: [
      t,
      0,
      H * 0.5,
      L * 0.7,
      H * 0.5,
      L,
      H * 0.05,
      L * 0.88,
      -H * 0.22,
      L * 0.5,
      -H * 0.5,
      0,
      -H * 0.5
    ]
  }).clone();
  if (flip) g.rotateY(Math.PI);
  return g;
}; /* adaga: ponta em -Z (ou +Z com flip) */
const Hp = {
  v: 100,
  add(n) {
    if (this.v <= 0) return;
    this.v = Math.min(100, this.v + n);
    Hud.hp(this.v);
  },
  hit(n) {
    if (this.v <= 0) return;
    Sfx.hurt(n);
    Hud.hurt(n);
    const a = Math.min(Inv.armor, n * 0.66);
    Inv.armor -= a;
    Hud.arm();
    this.v = Math.max(0, this.v - (n + 0 - a));
    Hud.hp(this.v);
    if (!this.v && !Abil.rc) Net.died();
    window.MAP && MAP.onDeath && MAP.onDeath();
  }
};
const Abil = {
  slowT: 0,
  stunT: 0,
  vt: 0,
  slowF: 1,
  rf: 0,
  ab: null,
  st: [],
  ult: 0,
  ua: 0,
  kn: 0,
  kc: 0,
  fl: 0,
  e: [],
  p: [],
  ck: '',
  rc: null,
  emit(o) {
    window.MAP && MAP.onAbility && MAP.onAbility(o);
  },
  dir() {
    return new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion);
  },
  hd() {
    return new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
  },
  ray(o, d, far) {
    RAY.set(o, d);
    RAY.far = far;
    const h = RAY.intersectObjects(Weapon.targets, false)[0];
    RAY.far = 150;
    return h;
  },
  add(m, dur, fn, end) {
    scene.add(m);
    const e = { m, t: 0, dur, fn, end };
    this.e.push(e);
    return e;
  },
  addUlt(n) {
    this.ult = Math.min(ULT_COST, this.ult + n);
  },
  set(id) {
    this.ab = ABI[id];
    this.st = []; /* agente novo: cargas voltam ao início */
    this.nb = id === 'neon' ? { e: 100, on: 0 } : null;
    this.ult = 0;
    this.ua = 0;
    this.reset();
    this.ab.forEach((a, i) => {
      const el = $$('ab' + i);
      el.classList.add('has');
      el.title = a.n;
      el.querySelector('.ic').innerHTML =
        '<svg viewBox="0 0 64 64">' +
        IC[a.land && a.t === 'proj' ? a.land : a.t] +
        '</svg><em></em>';
    });
    Weapon.vm && Weapon.buildVM();
  },
  reset() {
    for (const e of this.e) scene.remove(e.m);
    for (const p of this.p) scene.remove(p.m);
    if (this.ae && this.ae.cur) scene.remove(this.ae.cur);
    this.ae = null;
    this.slowT = this.stunT = this.vt = 0;
    this.ov = 0;
    this.sl = 0;
    scene.fog.near = FOG_N;
    scene.fog.far = FOG_F;
    this.e = [];
    this.p = [];
    this.rc = null;
    const old = this.st || []; /* as cargas passam de uma rodada para a outra */
    this.st = [0, 1, 2, 3].map(i => {
      const a = this.ab && this.ab[i],
        c = a && a.chg ? CHG[a.chg] : null;
      return {
        cd: 0,
        u: a && a.rr ? a.rr : 0 /* usos da rodada */,
        n: c ? Math.min(c.max, Math.max(c.free, (old[i] && old[i].n) || 0)) : 0 };
    });
    Object.assign(Mv, {
      speed: 1,
      bs: 1,
      bt: 0,
      vy: 0,
      h: 0,
      dx: 0,
      dz: 0,
      dt: 0,
      ghost: 0,
      dmg: 1
    });
    $$('fxg').classList.remove('on');
    this.ck = '';
    this.endVM();
    if (this.aim) {
      scene.remove(this.aim.m);
      this.aim = null;
    }
    if (this.nb) {
      this.nb.e = 100;
      this.nb.on = 0;
    }
    if (this.lg) {
      this.lg = 0;
      if (Weapon.vm) Weapon.vm.visible = true;
      Hud.ammo();
    }
    if (this.kn > 0) {
      this.kn = 0;
      if (Weapon.vm) Weapon.vm.visible = true;
      Hud.ammo();
    }
  },
  cast(i) {
    if (
      Menu.on ||
      Pause.on ||
      Shop.on ||
      !this.ab ||
      Round.phase === undefined ||
      Hp.v <= 0 ||
      Round.done ||
      Bomb.act
    )
      return;
    const a = this.ab[i],
      s = this.st[i];
    if (a.ult ? this.ult < ULT_COST : a.chg ? s.n <= 0 : a.rr ? s.u <= 0 : s.cd > 0) return;
    if (Mv.ghost > 0 && a.t !== 'ghost') return;
    if (this.kn > 0 || this.ae) return;
    let used = true;
    const h = this.hd();
    switch (a.t) {
      case 'wall':
        this.wall(a, h);
        break;
      case 'proj':
        this.throw(a, i, !!a.str);
        break;
      case 'gate':
        if (s.mk) {
          pos.x = s.mk.x;
          pos.z = s.mk.z;
          checkCollisions(pos);
          s.me.t = s.me.dur;
        } else {
          if (s.pend) return;
          s.pend = 1;
          this.throw(a, i, true);
          used = false;
        }
        break;
      case 'buff':
        if (this.ov > 0 && !a.over) {
          this.sl = 2;
          break;
        }
        Mv.bs = a.mult;
        Mv.bt = a.dur;
        this.sl = a.slides || this.sl;
        if (a.over) {
          this.lg = 1;
          if (Weapon.vm) Weapon.vm.visible = false;
          this.lv = this.mkVM('lg');
          this.ov = a.dur;
          Mv.dmg = 1.15;
          this.st[2].cd = 0;
          this.sl = 2;
        }
        this.burst(0xa678ff, 6);
        break;
      case 'bar': {
        const nb = this.nb;
        if (!nb) return;
        if (nb.on) nb.on = 0;
        else if (nb.e >= 8) {
          nb.on = 1;
          this.burst(0xa678ff, 4);
        } else return;
        used = false;
        break;
      }
      case 'jump':
        Mv.vy = a.v * MOVE.ABIL_VS;
        this.burst(0xdfe8f0, 3);
        break;
      case 'dash': {
        let ix = (keys.d ? 1 : 0) - (keys.a ? 1 : 0),
          iy = (keys.w ? 1 : 0) - (keys.s ? 1 : 0);
        if (!ix && !iy) iy = 1;
        const dd = (ix && iy ? 5 : ix ? 4 : iy < 0 ? 5 : 7) * 4,
          l = Math.hypot(ix, iy);
        ix /= l;
        iy /= l;
        Mv.dx = (Math.cos(yaw) * ix + h.x * iy) * dd;
        Mv.dz = (-Math.sin(yaw) * ix + h.z * iy) * dd;
        Mv.dt = 0.25;
        break;
      }
      case 'step': {
        if (this.aim) return;
        const m = new THREE.Mesh(new THREE.RingGeometry(0.7, 1.2, 28), bm(0x8b5cf6, 0.9));
        m.rotation.x = -Math.PI / 2;
        scene.add(m);
        this.aim = { i, a, m };
        return;
      } /* segure C e mire; solte para ir */
      case 'aerial':
        this.aerialOpen(a);
        return;
      case 'point': {
        const d = this.dir(),
          hit = this.ray(camera.position, d, a.range);
        this.smoke(
          a,
          hit ? hit.point.clone() : camera.position.clone().addScaledVector(d, a.range)
        );
        break;
      }
      case 'decoy':
        this.decoy(a, h);
        break;
      case 'ghost':
        Mv.ghost = a.dur;
        $$('fxg').classList.add('on');
        break;
      case 'recall': {
        const p = pos.clone(),
          m = new THREE.Mesh(new THREE.TorusGeometry(0.7, 0.07, 8, 24), bm(a.col, 0.9));
        m.position.set(p.x, 0.1, p.z);
        m.rotation.x = Math.PI / 2;
        this.rc = {
          p,
          t: a.dur,
          e: this.add(m, a.dur, e => {
            e.m.rotation.z += 0.06;
            e.m.position.y = 0.1 + 0.15 * Math.sin(e.t * 4);
          })
        };
        this.burst(a.col, 3);
        break;
      }
      case 'knives':
        this.kv = this.mkVM('kn');
        this.kn = a.k;
        this.kc = 0.3;
        if (Weapon.vm) Weapon.vm.visible = false;
        break;
    }
    if (used) {
      if (a.ult) this.ult = 0;
      else if (a.chg) s.n--;
      else if (a.rr) s.u--;
      else s.cd = a.cd;
    }
    Net.send({
      t: 'c',
      ag: Game.agent || 'phoenix',
      i,
      p: pos.toArray(),
      y: yaw,
      o: camera.position.toArray(),
      d: this.dir().toArray(),
      sh: keys.shift ? 1 : 0
    });
    this.emit({
      type: 'cast',
      slot: i,
      name: a.n,
      kind: a.t,
      params: a,
      pos: pos.toArray(),
      dir: this.dir().toArray()
    });
  },
  wall(a, h) {
    const n = a.twin ? 2 : 1,
      H = a.h,
      W = a.flame ? 1.6 : 0.5;
    for (let k = 0; k < n; k++) {
      const sd = n === 2 ? (k ? 1.25 : -1.25) : 0,
        o = pos.clone().addScaledVector(h, 2);
      o.x += Math.cos(yaw) * sd;
      o.z -= Math.sin(yaw) * sd;
      const m = new THREE.Mesh(new THREE.BoxGeometry(W, H, 1), bm(a.col, 1));
      m.rotation.y = yaw;
      const w = this.add(m, a.dur, e => {
        const g = Math.min(1, e.t / a.gr),
          L = Math.max(0.01, a.len * g),
          f = Math.min(1, (e.dur - e.t) / 1);
        e.L = L;
        e.m.scale.set(1, a.flame ? 1 + 0.06 * Math.sin(e.t * 20 + L) : 1, L);
        e.m.position.set(o.x + (h.x * L) / 2, H / 2, o.z + (h.z * L) / 2);
        e.m.material.opacity = f;
        e.m.material.color.setHex(
          a.flame
            ? Math.sin(e.t * 9) > 0
              ? 0xffb030
              : a.col
            : Math.sin(e.t * 12) > 0
              ? a.col
              : 0xb89cff
        );
      });
      Object.assign(w, {
        heal: a.heal || 0,
        dps: a.dps || 0,
        dmg: a.dmg || 0,
        stun: a.stun || 0,
        blk: a.blk ? 1 : 0,
        en: this.rf ? 1 : 0,
        o,
        h: h.clone(),
        W,
        L: 0
      });
    }
    this.burst(a.col, 3);
  },
  decoy(a, h) {
    const m = mkBody('yoru', 0.55, 0),
      g = h.clone();
    m.position.set(pos.x, 0, pos.z);
    m.rotation.y = yaw;
    this.add(
      m,
      3,
      (e, dt) => {
        if (this.ray(new THREE.Vector3(e.m.position.x, 1, e.m.position.z), g, 0.6)) {
          e.hit = 1;
          e.t = e.dur;
        } else e.m.position.addScaledVector(g, 6 * dt);
        const f = Math.min(1, (e.dur - e.t) / 0.5);
        e.m.traverse(o => {
          if (o.material) o.material.opacity = 0.55 * f;
        });
      },
      e => {
        if (e.hit) this.flash(e.m.position.clone().setY(1), 3, 0.8);
        else this.burst(0x5aa8ff, 1.5);
      }
    );
  },
  rfx(a, i, R) {
    const sp = pos.clone(),
      sy = yaw,
      o = new THREE.Vector3(...R.o),
      d = new THREE.Vector3(...R.d);
    pos.set(...R.p);
    yaw = R.y;
    this.rf = 1;
    const h = this.hd(); /* efeito visual de habilidade do outro jogador */
    try {
      switch (a.t) {
        case 'wall':
          this.wall({ ...a, heal: 0 }, h);
          break;
        case 'proj':
        case 'gate':
          this.throw({ ...a, heal: 0 }, i, a.t === 'gate' || !!a.str, { o, d, sh: R.sh });
          break;
        case 'point': {
          const hit = this.ray(o, d, a.range);
          this.smoke(a, hit ? hit.point.clone() : o.clone().addScaledVector(d, a.range));
          break;
        }
        case 'decoy':
          this.decoy(a, h);
          break;
        case 'buff':
        case 'bar':
        case 'jump':
        case 'dash':
        case 'recall':
        case 'step':
        case 'aerial':
          this.burst(a.col || 0xa678ff, 4);
          break;
      }
    } finally {
      pos.copy(sp);
      yaw = sy;
      this.rf = 0;
    }
  },
  knife(o, e) {
    const L = o.distanceTo(e),
      T = Math.max(0.05, L / 110),
      d = e.clone().sub(o).normalize(),
      m = new THREE.Mesh(DAG(0.5, 0.07, 0.012, 1), bm(0xdff3ff, 1));
    m.position.copy(o);
    m.lookAt(e);
    this.add(m, T, x => {
      x.m.position.copy(o).addScaledVector(d, L * Math.min(1, x.t / T));
    });
  },
  trail(c) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.03, 0.6), bm(c, 0.8));
    m.position.set(pos.x, 0.05, pos.z);
    m.rotation.y = yaw;
    this.add(m, 0.5, e => {
      e.m.material.opacity = 0.8 * (1 - e.t / 0.5);
    });
  },
  block() {
    for (const e of this.e)
      if (e.blk) {
        const dx = pos.x - e.o.x,
          dz = pos.z - e.o.z,
          al = dx * e.h.x + dz * e.h.z,
          ac = dx * e.h.z - dz * e.h.x,
          hw = e.W / 2 + RADIUS;
        if (al > -RADIUS && al < e.L + RADIUS && Math.abs(ac) < hw) {
          const sg = ac >= 0 ? 1 : -1,
            d = hw - Math.abs(ac);
          pos.x += e.h.z * sg * d;
          pos.z -= e.h.x * sg * d;
        }
      }
  } /* parede do Neon é sólida */,
  release(i) {
    const q = this.aim;
    if (!q || q.i !== i) return;
    this.aim = null;
    scene.remove(q.m);
    if (!q.ok || !q.t) {
      toast('Local inválido');
      return;
    }
    const a = q.a,
      t = q.t.clone(),
      m = new THREE.Mesh(new THREE.CircleGeometry(1.1, 24), bm(0x4a2a7a, 0.8));
    m.rotation.x = -Math.PI / 2;
    m.position.set(t.x, 0.07, t.z);
    this.burst(0x1c1f2a, 3);
    if (a.rr) this.st[i].u--;
    else this.st[i].cd = a.cd;
    this.add(
      m,
      a.ch,
      e => {
        e.m.scale.setScalar(0.4 + (e.t / a.ch) * 0.8);
      },
      () => {
        pos.x = t.x;
        pos.z = t.z;
        checkCollisions(pos);
        this.burst(0x1c1f2a, 5);
      }
    );
  },
  mkVM(kind) {
    const g = new THREE.Group(),
      hd = mkHand();
    hd.position.set(0, -0.11, 0.09);
    g.add(hd);
    const E = new THREE.MeshBasicMaterial({ color: 0xb48cff }),
      D = new THREE.MeshStandardMaterial({ color: 0x1b1e22, roughness: 0.5, metalness: 0.5 });
    if (kind === 'lg') {
      const b = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.09, 0.4), D);
      b.position.set(0, 0.01, -0.08);
      g.add(b);
      for (let i = 0; i < 3; i++) {
        const r = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.012, 6, 12), E);
        r.position.set(0, 0.01, -0.3 - i * 0.09);
        g.add(r);
      }
      const c = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 8), E);
      c.position.set(0, 0.01, -0.58);
      g.add(c);
    } else
      for (let i = 0; i < 8; i++) {
        const k = new THREE.Group(),
          bl = new THREE.Mesh(
            DAG(0.26, 0.045, 0.012, 0),
            new THREE.MeshStandardMaterial({ color: 0xdfe8f0, metalness: 0.9, roughness: 0.2 })
          ),
          hl = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.03, 0.08), D);
        bl.position.z = -0.04;
        hl.position.z = -0.02;
        k.add(bl, hl);
        k.rotation.z = (i - 3.5) * 0.16;
        k.rotation.x = -0.1;
        k.position.set(0, -0.02, -0.02);
        g.add(k);
      }
    g.scale.setScalar(0.5);
    g.position.set(0.2, -0.18, -0.4);
    camera.add(g);
    return g;
  },
  endVM() {
    if (this.lv) {
      camera.remove(this.lv);
      this.lv = null;
    }
    if (this.kv) {
      camera.remove(this.kv);
      this.kv = null;
    }
  },
  beam(o, e) {
    const pts = [o.clone()];
    for (let i = 1; i < 6; i++) {
      const t = o.clone().lerp(e, i / 6);
      t.x += (Math.random() - 0.5) * 0.35;
      t.y += (Math.random() - 0.5) * 0.35;
      t.z += (Math.random() - 0.5) * 0.35;
      pts.push(t);
    }
    pts.push(e.clone());
    const g = new THREE.Group();
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i],
        b = pts[i + 1],
        m = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.035, a.distanceTo(b)), bm(0xd9c6ff, 1));
      m.position.copy(a.clone().add(b).multiplyScalar(0.5));
      m.lookAt(b);
      g.add(m);
    }
    this.add(g, 0.07, x => {
      x.m.children.forEach(c => {
        c.material.opacity = 1 - x.t / 0.07;
      });
    });
  },
  lightning(dt) {
    this.kc -= dt;
    if (Weapon.held && this.kc <= 0) {
      this.kc = 1 / 14;
      const d = this.dir(),
        h = this.ray(camera.position, d, 150),
        end = h ? h.point.clone() : camera.position.clone().addScaledVector(d, 70),
        o = camera.position
          .clone()
          .addScaledVector(d, 0.6)
          .add(new THREE.Vector3(Math.cos(yaw) * 0.18, -0.15, -Math.sin(yaw) * 0.18));
      this.beam(o, end);
      if (h) {
        FX.hit(h.point);
        window.MAP &&
          MAP.onHit &&
          MAP.onHit({ point: h.point, object: h.object, damage: 38, weapon: 'lightning' });
      }
      Net.fire(camera.position, d, 38, h ? h.distance : 1e9, 150, { head: 95, leg: 30, k: 2 });
    } /* sem recoil, sem munição */
    $$('am').innerHTML = '<b>∞</b><small>RAIO</small>';
    return true;
  },
  zoneFx(a, pt) {
    const g = new THREE.Group(),
      R = a.r,
      A = (m, o) => {
        m.material.opacity = o;
        m.userData.o = o;
        g.add(m);
        return m;
      };
    g.position.set(pt.x, 0.06, pt.z);
    const disk = (r, c, o, y) => {
      const m = new THREE.Mesh(new THREE.CircleGeometry(r, 36), bm(c, o));
      m.rotation.x = -Math.PI / 2;
      m.position.y = y || 0;
      return A(m, o);
    };
    if (a.lava) {
      disk(R, 0x5a1000, 0.95);
      for (let i = 0; i < 6; i++) {
        const b = disk(
          R * (0.25 + Math.random() * 0.3),
          i % 2 ? 0xff5a00 : 0xffa020,
          0.9,
          0.01 + i * 0.002
        );
        b.position.x = (Math.random() - 0.5) * R * 1.1;
        b.position.z = (Math.random() - 0.5) * R * 1.1;
        b.userData.ph = Math.random() * 6;
      }
      const rim = new THREE.Mesh(new THREE.RingGeometry(R * 0.93, R, 40), bm(0xffd060, 0.95));
      rim.rotation.x = -Math.PI / 2;
      rim.position.y = 0.03;
      A(rim, 0.95);
      for (let i = 0; i < 14; i++) {
        const m = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 5), bm(0xffb040, 0.9));
        m.userData = {
          o: 0.9,
          em: Math.random(),
          x: (Math.random() - 0.5) * R * 1.6,
          z: (Math.random() - 0.5) * R * 1.6
        };
        g.add(m);
      }
    } else {
      disk(R, 0x3a1f7a, 0.35);
      for (let i = 0; i < 3; i++) {
        const m = new THREE.Mesh(new THREE.RingGeometry(0.85, 1, 40), bm(0xc9a8ff, 0.9));
        m.rotation.x = -Math.PI / 2;
        m.position.y = 0.04;
        m.userData = { o: 0.9, ring: i };
        g.add(m);
      }
      for (let i = 0; i < 6; i++) {
        const m = new THREE.Mesh(new THREE.BoxGeometry(0.05, 2.4, 0.05), bm(0xd9c6ff, 1));
        m.userData = { o: 1, bolt: i };
        g.add(m);
      }
      this.burst(a.col, 7);
    }
    return g;
  },
  zfx(e, a) {
    const f = Math.min(1, (e.dur - e.t) / 0.5),
      t = e.t,
      R = a.r;
    e.m.children.forEach(m => {
      const u = m.userData;
      let o = u.o;
      if (u.ph !== undefined) {
        m.scale.setScalar(1 + 0.12 * Math.sin(t * 3 + u.ph));
        o *= 0.85 + 0.15 * Math.sin(t * 6 + u.ph);
      }
      if (u.em !== undefined) {
        const k = (t * 0.6 + u.em) % 1;
        m.position.set(u.x * (1 - k * 0.3), 0.1 + k * 2.2, u.z * (1 - k * 0.3));
        o *= 1 - k;
      }
      if (u.ring !== undefined) {
        const k = (t * 1.6 + u.ring / 3) % 1;
        m.scale.setScalar(R * (0.15 + k * 0.85));
        o *= 1 - k;
      }
      if (u.bolt !== undefined) {
        const an = u.bolt * 1.047 + t * 2,
          rr = R * 0.6 * (0.4 + 0.6 * Math.abs(Math.sin(t * 7 + u.bolt)));
        m.position.set(Math.cos(an) * rr, 1.2, Math.sin(an) * rr);
        m.visible = Math.sin(t * 30 + u.bolt * 3) > -0.3;
      }
      m.material.opacity = o * f;
    });
  },
  burst(c, r) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), bm(c, 0.5));
    m.position.set(pos.x, 1, pos.z);
    this.add(m, 0.5, e => {
      e.m.scale.setScalar(0.3 + e.t * (r || 6));
      e.m.material.opacity = 0.5 * (1 - e.t / 0.5);
    });
  },
  /* habilidades de smoke/flash do agente atual (índices) */
  chgList() {
    const r = [];
    if (this.ab) this.ab.forEach((a, i) => a.chg && r.push(i));
    return r;
  },
  /* compra 1 carga da habilidade i na loja (só na fase de compra) */
  buyCharge(i) {
    const a = this.ab && this.ab[i],
      s = this.st && this.st[i];
    if (!a || !a.chg || !s) return;
    const c = CHG[a.chg];
    if (Round.phase !== 'buy' && !Training.on) return toast('FASE DE COMPRA ENCERRADA');
    if (s.n >= c.max) return toast('Você já está com o máximo de cargas');
    if (!Econ.spend(c.price)) return toast('Créditos insuficientes');
    s.n++;
    this.ck = '';
  },
  kill() {
    this.addUlt(1);
    this.ab && this.ab.forEach((a, i) => a.rk && this.st[i].u++); /* Yoru: +1 salto por abate */
    if (this.kn > 0) {
      this.kn = this.ab[3].k;
      this.kv && this.kv.children.forEach(c => (c.visible = true));
    }
  } /* chame ao eliminar um inimigo: recarrega as facas da Jett */,
  slide() {
    if (!(this.nb && this.nb.on && this.nb.e >= 15) || Mv.ghost || this.ae) return false;
    this.nb.e -= 15;
    let ix = (keys.d ? 1 : 0) - (keys.a ? 1 : 0),
      iy = (keys.w ? 1 : 0) - (keys.s ? 1 : 0);
    if (!ix && !iy) iy = 1;
    const l = Math.hypot(ix, iy),
      h = this.hd();
    ix /= l;
    iy /= l;
    Mv.dx = (Math.cos(yaw) * ix + h.x * iy) * 24;
    Mv.dz = (-Math.sin(yaw) * ix + h.z * iy) * 24;
    Mv.dt = 0.35;
    const a = pos.clone(),
      b = new THREE.Vector3(a.x + Mv.dx * 0.35, 0.05, a.z + Mv.dz * 0.35),
      m = new THREE.Mesh(
        new THREE.BoxGeometry(0.25, 0.05, Math.max(0.1, Math.hypot(b.x - a.x, b.z - a.z))),
        bm(0xc9a8ff, 0.8)
      );
    m.position.set((a.x + b.x) / 2, 0.05, (a.z + b.z) / 2);
    m.lookAt(b);
    this.add(m, 1, e => {
      e.m.material.opacity = 0.8 * (1 - e.t);
    });
    this.burst(0xa678ff, 3);
    return true;
  },
  aerialOpen(a) {
    const cur = new THREE.Mesh(new THREE.RingGeometry(1, 1.5, 24), bm(0x8b5cf6, 0.9));
    cur.rotation.x = -Math.PI / 2;
    scene.add(cur);
    Weapon.trig(0);
    scene.fog.near = 400;
    scene.fog.far = 900;
    this.ae = { a, tx: pos.x, tz: pos.z, ch: -1, cur };
    toast('Mova o mouse e clique no destino');
  },
  click(e) {
    const q = this.ae;
    if (!q) return false;
    if (q.ch >= 0 || e.button !== 0) return true;
    if (inWall(q.tx / S, q.tz / S)) {
      toast('Local inválido');
      return true;
    }
    q.ch = q.a.ch;
    this.ult = 0;
    scene.remove(q.cur);
    scene.fog.near = FOG_N;
    scene.fog.far = FOG_F;
    const m = new THREE.Mesh(new THREE.CircleGeometry(1.4, 24), bm(0x2a1f45, 0.8));
    m.rotation.x = -Math.PI / 2;
    m.position.set(q.tx, 0.08, q.tz);
    q.me = this.add(m, q.ch, e => {
      e.m.scale.setScalar(0.3 + (e.t / q.ch) * 0.9);
    });
    return true;
  },
  throw(a, i, straight, R) {
    const d = R ? R.d.clone() : this.dir(),
      m = new THREE.Mesh(
        new THREE.SphereGeometry(a.big ? 0.3 : 0.13, 12, 10),
        bm(a.col || 0xa678ff, 1)
      );
    m.position.copy(R ? R.o : camera.position).addScaledVector(d, 0.7);
    m.position.y -= 0.15;
    scene.add(m);
    const v = d.clone().multiplyScalar(straight ? 15 : a.fast ? 26 : 18);
    if (!straight) v.y += 3;
    this.p.push({
      m,
      v,
      a,
      i,
      rem: R ? 1 : 0,
      g: straight ? 0 : 14,
      b: a.bounce || 0,
      t: 0,
      rt: new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw)).multiplyScalar(
        a.curve ? ((R ? R.sh : keys.shift) ? -1 : 1) * 9 : 0
      )
    });
  },
  land(p, pt) {
    const a = p.a,
      k = a.land || 'gate';
    p.rem || this.emit({ type: 'land', kind: k, params: a, name: a.n, pos: pt.toArray() });
    if (k === 'smoke') this.smoke(a, pt);
    else if (k === 'para') this.burst(0x5b2a8f, 3);
    else if (k === 'flash') {
      if (a.fuse)
        this.add(
          new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), bm(a.col, 0.9)),
          a.fuse,
          e => {
            e.m.position.copy(pt);
            e.m.scale.setScalar(1 + 0.5 * Math.sin(e.t * 40));
          },
          () => this.flash(pt, 30, a.fd)
        );
      else this.flash(pt, 30, a.fd);
    } else if (k === 'zone') {
      const g = this.zoneFx(a, pt),
        z = this.add(g, a.dur, e => this.zfx(e, a));
      Object.assign(z, {
        heal: a.heal || 0,
        dps: a.dps || 0,
        slow: a.slow || 0,
        en: p.rem ? 1 : 0,
        c: pt.clone(),
        r: a.r
      });
    } else if (p.rem) this.burst(a.col, 2);
    else {
      const s = this.st[p.i],
        m = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.07, 8, 24), bm(a.col, 0.9));
      m.position.set(pt.x, 1, pt.z);
      s.pend = 0;
      s.mk = pt.clone();
      s.me = this.add(
        m,
        a.mk || 30,
        e => {
          e.m.rotation.y += 0.05;
        },
        () => {
          s.mk = null;
          if (a.rr) s.u--;
          else s.cd = a.cd;
        }
      );
    }
  },
  smoke(a, p) {
    const c = a.h,
      m = new THREE.Mesh(
        c ? new THREE.CylinderGeometry(1, 1, a.h, 20) : new THREE.SphereGeometry(1, 18, 14),
        bm(a.col, 0.995)
      );
    m.position.set(p.x, c ? a.h / 2 : Math.max(p.y, a.r * 0.6), p.z);
    m.userData.sm = a.col;
    m.userData.h = c ? a.h : 0;
    this.add(m, a.dur, e => {
      const g = Math.min(1, e.t / (c ? 0.8 : 0.5)),
        f = Math.min(1, (e.dur - e.t) / (c ? 3 : 0.7)),
        sy = c ? (0.3 + 0.7 * g) * (0.4 + 0.6 * f) : 0.2 + g * a.r,
        sx = 0.2 + g * a.r;
      e.m.scale.set(sx, sy, sx);
      e.m.material.opacity = 0.995 * Math.min(1, f * (c ? 1.4 : 1));
      if (c) e.m.position.y = (a.h * sy) / 2;
    });
  },
  flash(p, R, dur) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 10), bm(0xfff3b0, 0.9));
    m.position.copy(p);
    this.add(m, 0.35, e => {
      e.m.scale.setScalar(0.3 + e.t * 8);
      e.m.material.opacity = 0.9 * (1 - e.t / 0.35);
    });
    const v = p.clone().sub(camera.position),
      d = v.length();
    R = R || 30;
    if (d < R) {
      const f = v.dot(this.dir()) / d;
      this.fl = f > 0.3 ? 1 : 0.35;
      this.fr = 1 / (dur || 1.2);
    }
  } /* cega quem olha para o clarão */,
  knives(dt) {
    this.kc -= dt;
    const all = Weapon.ads && this.kc <= 0,
      one = Weapon.held && this.kc <= 0;
    if (all || one) {
      const n = all ? this.kn : 1,
        d0 = this.dir(),
        R = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
      this.kc = all ? 1.1 : 0.35;
      for (let q = 0; q < n; q++) {
        this.kn--;
        const d = d0.clone();
        if (all) d.addScaledVector(R, (q - (n - 1) / 2) * 0.012);
        else {
          d.x += (Math.random() - 0.5) * 0.03;
          d.y += (Math.random() - 0.5) * 0.03;
        }
        d.normalize();
        const h = this.ray(camera.position, d, 120),
          end = h ? h.point.clone() : camera.position.clone().addScaledVector(d, 60);
        if (h) {
          FX.hit(h.point);
          window.MAP &&
            MAP.onHit &&
            MAP.onHit({
              point: h.point,
              object: h.object,
              damage: 50,
              head: 150,
              leg: 40,
              weapon: 'blade'
            });
        }
        Net.fire(camera.position, d, 50, h ? h.distance : 1e9, 120, { head: 150, leg: 40, k: 1 });
        this.knife(
          camera.position
            .clone()
            .addScaledVector(d, 0.5)
            .add(new THREE.Vector3(0, -0.12, 0)),
          end
        );
        const m = new THREE.Mesh(
          new THREE.BoxGeometry(0.02, 0.02, end.distanceTo(camera.position)),
          bm(0xbfe4ff, 0.35)
        );
        m.position.copy(camera.position.clone().add(end).multiplyScalar(0.5));
        m.lookAt(end);
        this.add(m, 0.12, e => {
          e.m.material.opacity = 0.9 * (1 - e.t / 0.12);
        });
      }
      if (this.kv)
        this.kv.children.forEach((c, i) => {
          if (i > 0) c.visible = i <= this.kn;
        });
      if (this.kn <= 0) {
        this.endVM();
        if (Weapon.vm) Weapon.vm.visible = true;
        Hud.ammo();
        return false;
      }
    }
    if (this.kn > 0) $$('am').innerHTML = '<b>' + this.kn + '</b><small>FACAS · E/D</small>';
    return true;
  },
  update(dt) {
    if (!this.ab) return;
    for (const s of this.st) if (s.cd > 0) s.cd -= dt;
    if (Mv.bt > 0) {
      Mv.bt -= dt;
      if (Mv.bt <= 0) Mv.bs = 1;
    }
    if (Mv.ghost > 0) {
      Mv.ghost -= dt;
      if (Mv.ghost <= 0) {
        Mv.ghost = 0;
        $$('fxg').classList.remove('on');
        checkCollisions(pos);
      }
    }
    Mv.speed =
      (Mv.ghost > 0 ? 1.25 : Mv.bs) *
      (this.nb && this.nb.on ? this.ab[2].mult : 1) *
      (this.stunT > 0 ? 0 : this.slowT > 0 ? this.slowF : 1);
    if (this.rc) {
      this.rc.t -= dt;
      if (this.rc.t <= 0) this.rc = null;
    }
    if (Hp.v <= 0 && this.rc) {
      pos.x = this.rc.p.x;
      pos.z = this.rc.p.z;
      Hp.v = 100;
      Inv.armor = 100;
      Hud.arm();
      Hud.hp(100);
      this.burst(0xff7a2f, 9);
      this.rc.e.t = this.rc.e.dur;
      this.rc = null;
    }
    if (this.nb) {
      const nb = this.nb;
      if (this.ov > 0) nb.e = 100;
      if (nb.on) {
        if (this.ov <= 0) nb.e -= this.ab[2].drain * dt;
        if (nb.e <= 0) {
          nb.e = 0;
          nb.on = 0;
        }
        if (Math.hypot(vel.x, vel.z) > 1 && (nb.sp = (nb.sp || 0) - dt) <= 0) {
          nb.sp = 0.07;
          this.trail(0xa678ff);
        }
      } else nb.e = Math.min(100, nb.e + this.ab[2].rech * dt);
    }
    if (this.aim) {
      const q = this.aim,
        d = this.dir(),
        o = camera.position,
        t = new THREE.Vector3();
      if (d.y < -0.02) t.copy(o).addScaledVector(d, -o.y / d.y);
      else t.copy(o).addScaledVector(this.hd(), q.a.range);
      const dx = t.x - pos.x,
        dz = t.z - pos.z,
        l = Math.hypot(dx, dz);
      if (l > q.a.range) {
        t.x = pos.x + (dx / l) * q.a.range;
        t.z = pos.z + (dz / l) * q.a.range;
      }
      t.y = 0;
      q.t = t;
      const dl = Math.hypot(t.x - pos.x, t.z - pos.z),
        wh =
          dl > 0.3 &&
          this.ray(
            new THREE.Vector3(pos.x, 1, pos.z),
            new THREE.Vector3(t.x - pos.x, 0, t.z - pos.z).normalize(),
            dl
          );
      q.ok = dl > 0.8 && !inWall(t.x / S, t.z / S) && !wh;
      q.m.position.set(t.x, 0.08, t.z);
      q.m.material.color.setHex(q.ok ? 0x8b5cf6 : 0xff3355);
    }
    this.slowT = Math.max(0, this.slowT - dt);
    this.stunT = Math.max(0, this.stunT - dt);
    this.vt = Math.max(0, this.vt - dt);
    for (const e of this.e)
      if (e.heal || e.dps || e.dmg || e.slow) {
        let n = false;
        if (e.r) n = Math.hypot(pos.x - e.c.x, pos.z - e.c.z) < e.r;
        else {
          const dx = pos.x - e.o.x,
            dz = pos.z - e.o.z,
            al = dx * e.h.x + dz * e.h.z,
            ac = Math.abs(dx * e.h.z - dz * e.h.x);
          n = al > -0.5 && al < e.L + 0.5 && ac < e.W / 2 + 0.9;
        }
        if (e.dmg) e.tc = (e.tc || 0) - dt;
        if (!n) continue;
        if (!e.en) {
          if (e.heal) Hp.add(e.heal * dt);
          continue;
        } /* efeito do inimigo: dano, atordoamento, lentidão */
        if (e.dps) Hp.hit(e.dps * dt);
        if (e.dmg && e.tc <= 0) {
          e.tc = 1.2;
          Hp.hit(e.dmg);
          this.stunT = e.stun || 0.5;
        }
        if (e.slow) {
          this.slowT = 2;
          this.slowF = 1 - e.slow;
        }
      }
    {
      let sm = -1;
      for (const e of this.e) {
        const u = e.m.userData;
        if (u && u.sm !== undefined && e.m.material.opacity > 0.6) {
          const sx = e.m.scale.x,
            dx = camera.position.x - e.m.position.x,
            dz = camera.position.z - e.m.position.z,
            ins = u.h
              ? Math.hypot(dx, dz) < sx &&
                camera.position.y < e.m.position.y + (u.h * e.m.scale.y) / 2
              : Math.hypot(dx, camera.position.y - e.m.position.y, dz) < sx;
          if (ins) {
            sm = u.sm;
            break;
          }
        }
      }
      const vk = sm >= 0 ? 'sm' : this.vt > 0 ? 'pv' : this.slowT > 0 ? 'bl' : '',
        vo =
          sm >= 0
            ? 1
            : vk === 'pv'
              ? Math.min(1, this.vt / 0.5)
              : vk === 'bl'
                ? Math.min(1, this.slowT / 0.5)
                : 0,
        fv = $$('fxv');
      if (fv.dataset.k !== vk) {
        fv.className = vk;
        fv.dataset.k = vk;
        fv.style.background = vk === 'sm' ? '#' + sm.toString(16).padStart(6, '0') : '';
      }
      fv.style.opacity = vo;
    }
    if (this.ov > 0) {
      this.ov -= dt;
      this.st[2].cd = 0;
      if (Math.floor((this.ov + dt) / 2) > Math.floor(this.ov / 2)) this.burst(0xa678ff, 4);
      if (this.ov <= 0) {
        Mv.dmg = 1;
        Mv.bt = 0;
        Mv.bs = 1;
        this.lg = 0;
        this.endVM();
        if (Weapon.vm) Weapon.vm.visible = true;
        Hud.ammo();
      }
    }
    if (this.ae && this.ae.ch < 0) this.ae.cur.position.set(this.ae.tx, 0.1, this.ae.tz);
    if (this.ae && this.ae.ch >= 0) {
      const q = this.ae;
      q.ch -= dt;
      if (Math.hypot(vel.x, vel.z) > 1 || Mv.dx || q.ch <= 0) {
        if (q.ch > 0) {
          this.ult = Math.floor(ULT_COST / 2);
          q.me.t = q.me.dur;
          toast('Interrompido');
        } else {
          this.burst(0x1c1f2a, 5);
          pos.x = q.tx;
          pos.z = q.tz;
          checkCollisions(pos);
          this.burst(0x1c1f2a, 6);
        }
        this.ae = null;
      }
    }
    for (let k = this.p.length - 1; k >= 0; k--) {
      const p = this.p[k];
      p.t += dt;
      if (p.a.trail) {
        p.tc = (p.tc || 0) - dt;
        if (p.tc <= 0) {
          p.tc = 0.02;
          const q = new THREE.Mesh(
            new THREE.SphereGeometry(p.a.big ? 0.22 : 0.09, 6, 5),
            bm(p.a.col, 0.8)
          );
          q.position.copy(p.m.position);
          this.add(q, 0.3, e => {
            e.m.scale.setScalar(1 - e.t / 0.3);
            e.m.material.opacity = 0.8 * (1 - e.t / 0.3);
          });
        }
      }
      if (p.rem && p.a.land === 'para' && !p.hit && p.m.position.distanceTo(pos) < 1.4) {
        p.hit = 1;
        this.vt = p.a.dur;
      }
      p.v.addScaledVector(p.rt, dt);
      p.v.y -= p.g * dt;
      {
        const ch = ceilH(p.m.position.x, p.m.position.z);
        if (p.m.position.y > ch && p.v.y > 0) {
          p.m.position.y = ch - 0.1;
          p.v.y = -p.v.y * 0.3;
        }
      } /* teto: skybox 35 m, salas baixas 4 m */
      const st = p.v.clone().multiplyScalar(dt),
        len = st.length(),
        h = this.ray(p.m.position, st.clone().normalize(), len + 0.05);
      let pt = null;
      if (h) {
        const n = h.face.normal.clone().transformDirection(h.object.matrixWorld);
        if (p.b > 0) {
          p.v.reflect(n).multiplyScalar(0.75);
          p.m.position.copy(h.point).addScaledVector(n, 0.1);
          p.b--;
          continue;
        }
        pt = h.point.clone().addScaledVector(n, 0.3);
      } else {
        p.m.position.add(st);
        if (p.m.position.y <= 0.1) {
          if (p.b > 0 && p.v.y < 0) {
            p.v.y *= -0.6;
            p.m.position.y = 0.12;
            p.b--;
          } else {
            pt = p.m.position.clone();
            pt.y = 0.05;
          }
        }
      }
      if (!pt && p.t > (p.a.life || 3.5)) pt = p.m.position.clone();
      if (pt) {
        scene.remove(p.m);
        this.p.splice(k, 1);
        this.land(p, pt);
      }
    }
    for (let k = this.e.length - 1; k >= 0; k--) {
      const e = this.e[k];
      e.t += dt;
      if (e.t >= e.dur) {
        scene.remove(e.m);
        this.e.splice(k, 1);
        e.end && e.end(e);
      } else e.fn && e.fn(e, dt);
    }
    if (this.fl > 0) {
      this.fl = Math.max(0, this.fl - dt * (this.fr || 0.8));
      $$('fxf').style.opacity = Math.min(1, this.fl * 1.3);
    }
    let key = '';
    for (let i = 0; i < 4; i++) {
      const a = this.ab[i],
        s = this.st[i],
        ok = a.ult ? this.ult >= ULT_COST : a.chg ? s.n > 0 : a.rr ? s.u > 0 : s.cd <= 0;
      key +=
        (a.ult ? this.ult : a.chg ? 'c' + s.n : a.rr ? 'u' + s.u : Math.ceil(s.cd)) +
        (ok ? 'y' : 'n') +
        (s.mk ? 'm' : '') +
        (a.t === 'bar' ? Math.round(this.nb.e / 2) + (this.nb.on ? 'o' : 'f') : '');
    }
    if (key !== this.ck) {
      this.ck = key;
      for (let i = 0; i < 4; i++) {
        const a = this.ab[i],
          s = this.st[i],
          ok = a.ult ? this.ult >= ULT_COST : a.chg ? s.n > 0 : a.rr ? s.u > 0 : s.cd <= 0,
          el = $$('ab' + i),
          pr =
            a.t === 'bar'
              ? Math.round(this.nb.e)
              : a.chg
                ? Math.round((s.n / CHG[a.chg].max) * 100)
                : a.rr
                  ? Math.round((Math.min(s.u, a.rr) / a.rr) * 100)
                : Math.round((a.ult ? this.ult / ULT_COST : ok ? 1 : 1 - s.cd / a.cd) * 100);
        el.classList.toggle('off', !ok);
        el.style.outline = a.t === 'bar' && this.nb.on ? '2px solid #a678ff' : '';
        el.querySelector('em').textContent = a.chg
          ? s.n
          : a.rr
            ? s.u
          : a.ult
            ? this.ult + '/' + ULT_COST
            : s.cd > 0
              ? Math.ceil(s.cd)
              : '';
        el.querySelector('u').style.background =
          'linear-gradient(90deg,#52d6a3 ' + pr + '%,rgba(255,255,255,.28) ' + pr + '%)';
      }
    }
  }
};
