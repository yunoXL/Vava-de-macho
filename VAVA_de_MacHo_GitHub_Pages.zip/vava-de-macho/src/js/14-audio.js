/* ========= ÁUDIO (WebAudio sintetizado): tiros em camadas, reverb, som 3D com oclusão, passos, recarga ========= */
const Sfx = {
  ac: null,
  bus: null,
  rv: null,
  nb: null,
  mg: null,
  vol: 0.8,
  ps: null,
  rk: 0,
  SH: {
    classic: { c: 3200, l: 3600, d: 0.13, t: [190, 60], g: 0.5, w: 0.12 },
    ghost: { c: 2400, l: 2600, d: 0.1, t: [170, 60], g: 0.38, w: 0.08 },
    frenzy: { c: 3600, l: 4200, d: 0.09, t: [210, 80], g: 0.4, w: 0.1 },
    sheriff: { c: 2600, l: 2600, d: 0.24, t: [140, 40], g: 0.85, w: 0.28 },
    spectre: { c: 2200, l: 2400, d: 0.08, t: [200, 90], g: 0.32, w: 0.06 },
    stinger: { c: 3800, l: 4500, d: 0.07, t: [230, 100], g: 0.38, w: 0.08 },
    phantom: { c: 2000, l: 2200, d: 0.11, t: [150, 70], g: 0.45, w: 0.1 },
    vandal: { c: 2800, l: 3200, d: 0.17, t: [140, 50], g: 0.7, w: 0.22 },
    operator: { c: 2400, l: 1800, d: 0.5, t: [90, 30], g: 1, w: 0.55, m: 1 },
    shorty: { c: 1800, l: 1700, d: 0.3, t: [100, 35], g: 0.95, w: 0.3 },
    bandit: { c: 2600, l: 2900, d: 0.12, t: [160, 55], g: 0.5, w: 0.12 },
    bucky: { c: 1800, l: 1600, d: 0.34, t: [95, 30], g: 1, w: 0.3 },
    judge: { c: 2000, l: 1900, d: 0.28, t: [105, 35], g: 0.9, w: 0.24 },
    bulldog: { c: 2600, l: 3000, d: 0.14, t: [150, 60], g: 0.55, w: 0.14 },
    guardian: { c: 2400, l: 2600, d: 0.2, t: [130, 45], g: 0.75, w: 0.22 },
    marshal: { c: 2200, l: 1900, d: 0.4, t: [100, 32], g: 0.95, w: 0.4, m: 1 },
    outlaw: { c: 2000, l: 1800, d: 0.42, t: [95, 30], g: 1, w: 0.45 },
    ares: { c: 2200, l: 2400, d: 0.1, t: [140, 55], g: 0.5, w: 0.1 },
    odin: { c: 1900, l: 2100, d: 0.1, t: [120, 45], g: 0.55, w: 0.1 }
  },
  unlock() {
    try {
      if (!this.ac) this.build();
      if (this.ac && this.ac.state === 'suspended') this.ac.resume();
    } catch (e) {}
  },
  ok() {
    return !!this.ac && this.ac.state === 'running';
  },
  setVol(v) {
    this.vol = v;
    if (this.mg) this.mg.gain.value = v;
  },
  build() {
    const A = (this.ac = new (window.AudioContext || window.webkitAudioContext)()),
      cm = A.createDynamicsCompressor();
    cm.threshold.value = -14;
    cm.knee.value = 12;
    cm.ratio.value = 5;
    cm.attack.value = 0.003;
    cm.release.value = 0.18;
    const mg = (this.mg = A.createGain());
    mg.gain.value = this.vol;
    cm.connect(mg);
    mg.connect(A.destination);
    const b = (this.bus = A.createGain());
    b.connect(cm);
    const L = Math.floor(A.sampleRate * 1.8),
      ir = A.createBuffer(2, L, A.sampleRate),
      r0 = A.sampleRate * 0.012; /* reverb: ruído com decaimento que escurece */
    for (let c = 0; c < 2; c++) {
      const D = ir.getChannelData(c);
      let lp = 0;
      for (let i = 0; i < L; i++) {
        const t = i / L;
        lp += (Math.random() * 2 - 1 - lp) * (0.55 - 0.45 * t);
        D[i] = lp * 2.4 * Math.pow(1 - t, 2.6) * (i < r0 ? i / r0 : 1);
      }
    }
    const cv = (this.rv = A.createConvolver());
    cv.buffer = ir;
    const rg = A.createGain();
    rg.gain.value = 0.9;
    cv.connect(rg);
    rg.connect(cm);
    const nb = (this.nb = A.createBuffer(1, Math.floor(A.sampleRate * 1.2), A.sampleRate)),
      D = nb.getChannelData(0);
    for (let i = 0; i < D.length; i++) D[i] = Math.random() * 2 - 1;
  },
  W(n, wet) {
    if (wet) {
      const w = this.ac.createGain();
      w.gain.value = wet;
      n.connect(w);
      w.connect(this.rv);
    }
  },
  N(o, wet, type, f, q, g, du, dl, rate) {
    const A = this.ac,
      t = A.currentTime + (dl || 0),
      s = A.createBufferSource(),
      fl = A.createBiquadFilter(),
      gn = A.createGain();
    s.buffer = this.nb;
    s.playbackRate.value = rate || 1;
    fl.type = type;
    fl.frequency.value = f;
    fl.Q.value = q;
    gn.gain.setValueAtTime(g, t);
    gn.gain.exponentialRampToValueAtTime(0.0008, t + du);
    s.connect(fl);
    fl.connect(gn);
    gn.connect(o);
    this.W(gn, wet);
    s.start(t, Math.random() * 0.4, du + 0.03);
  },
  T(o, wet, f0, f1, g, du, dl) {
    const A = this.ac,
      t = A.currentTime + (dl || 0),
      s = A.createOscillator(),
      gn = A.createGain();
    s.type = 'sine';
    s.frequency.setValueAtTime(f0, t);
    s.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + du);
    gn.gain.setValueAtTime(g, t);
    gn.gain.exponentialRampToValueAtTime(0.0008, t + du);
    s.connect(gn);
    gn.connect(o);
    this.W(gn, wet);
    s.start(t);
    s.stop(t + du + 0.03);
  },
  click(o, dl, f, g) {
    this.N(o, 0.04, 'bandpass', f, 6, g, 0.035, dl);
    this.T(o, 0, f * 0.55, f * 0.3, g * 0.7, 0.045, dl);
  },
  occl(p) {
    const d = p.clone().sub(camera.position),
      L = d.length();
    if (L < 1) return false;
    d.normalize();
    return (
      new THREE.Raycaster(camera.position.clone(), d, 0, L - 0.3).intersectObjects(
        Weapon.targets,
        false
      ).length > 0
    );
  } /* parede no caminho = som abafado */,
  out(p, maxD) {
    if (!p) return this.bus;
    const A = this.ac,
      d = p.distanceTo(camera.position);
    if (d > (maxD || 45)) return null;
    const pn = A.createPanner();
    pn.panningModel = 'HRTF';
    pn.distanceModel = 'inverse';
    pn.refDistance = 4;
    pn.rolloffFactor = 1.3;
    pn.maxDistance = 150;
    if (pn.positionX) {
      pn.positionX.value = p.x;
      pn.positionY.value = p.y;
      pn.positionZ.value = p.z;
    } else pn.setPosition(p.x, p.y, p.z);
    const fl = A.createBiquadFilter(),
      gn = A.createGain();
    fl.type = 'lowpass';
    fl.frequency.value = Math.max(1200, 16000 / (1 + d * 0.1)); /* ar absorve agudos */
    gn.gain.value = 1;
    if (this.occl(p)) {
      fl.frequency.value = Math.min(fl.frequency.value, 600);
      gn.gain.value = 0.5;
    }
    fl.connect(gn);
    gn.connect(pn);
    pn.connect(this.bus);
    return fl;
  },
  shot(id, p) {
    if (!this.ok()) return;
    const o = this.out(p, 130);
    if (!o) return;
    if (id === 'knife') {
      const r = 0.9 + Math.random() * 0.2;
      this.N(o, 0.03, 'bandpass', 3500 * r, 1.2, 0.14, 0.16, 0, r);
      this.N(o, 0, 'highpass', 5000, 0.7, 0.07, 0.1, 0.04);
      return;
    }
    const P = this.SH[id] || this.SH.classic,
      r = 0.94 + Math.random() * 0.12;
    this.N(o, P.w, 'highpass', P.c, 0.7, P.g * 0.55, 0.035, 0, r * 1.4); /* estalo */
    this.N(o, P.w, 'lowpass', P.l, 0.6, P.g * 0.8, P.d, 0, r); /* corpo */
    this.T(o, P.w * 0.5, P.t[0] * r, P.t[1], P.g * 0.8, P.d * 0.9); /* baque grave */
    if (P.m && !p) {
      this.click(o, 0.6, 2000, 0.35);
      this.click(o, 0.78, 1300, 0.4);
    }
  } /* ferrolho da Operator */,
  step(s, v, p) {
    if (!this.ok()) return;
    const o = this.out(p);
    if (!o) return;
    const [ty, f, Q, g, du, ec] = Steps.T[s] || Steps.T.stone,
      r = 0.9 + Math.random() * 0.2,
      vv = (v || 1) * (0.8 + Math.random() * 0.4);
    for (const [dl, gm] of ec
      ? [
          [0, 1],
          [0.075, 0.35]
        ]
      : [[0, 1]])
      this.N(o, 0.05, ty, f * r, Q, g * vv * gm * 1.3, du, dl, r);
    if (s !== 'grass') this.T(o, 0, 110 * r, 60, g * vv * 1.5, 0.08);
    else this.N(o, 0, 'lowpass', 400, 0.5, g * vv, 0.12);
  },
  peer(m) {
    const n = performance.now(),
      s = this.ps;
    this.ps = { x: m.x, z: m.z, t: n, d: s ? s.d : 0 };
    if (!s || !this.ok()) return;
    const d = Math.hypot(m.x - s.x, m.z - s.z),
      dt = Math.max(0.001, (n - s.t) / 1000);
    if (d > 3 || m.g || m.j || m.q || d / dt < 2.2 || Round.phase === undefined)
      return; /* parado, no ar, andando devagar ou agachado = sem barulho */
    this.ps.d += d;
    if (this.ps.d >= 1.75) {
      this.ps.d = 0;
      this.step(Steps.surf(m.x, m.z), 1, new THREE.Vector3(m.x, 0.1, m.z));
    }
  },
  jump(q) {
    if (!this.ok()) return;
    this.N(this.bus, 0, 'bandpass', 900, 0.8, 0.07 * (q ? 0.5 : 1), 0.12);
  },
  land(vy, q) {
    if (!this.ok()) return;
    const v = Math.min(2.2, vy / 8) * (q ? 0.5 : 1);
    this.step(Steps.surf(), v * 1.4);
    this.T(this.bus, 0, 80, 38, 0.35 * v, 0.18);
  },
  reload(w) {
    if (!this.ok()) return;
    const k = ++this.rk,
      r = w.rld,
      o = this.bus,
      run = (t, f) =>
        setTimeout(() => {
          if (this.rk === k && Weapon.rl > 0) f();
        }, t * 1000),
      pis = w.cat === 'Pistolas';
    if (w.cat === 'Snipers') {
      run(r * 0.18, () => this.click(o, 0, 1500, 0.3));
      run(r * 0.4, () => {
        this.click(o, 0, 1100, 0.35);
        this.T(o, 0, 200, 100, 0.2, 0.08);
      });
      run(r * 0.7, () => this.click(o, 0, 1800, 0.35));
      run(r - 0.35, () => {
        this.click(o, 0, 1300, 0.4);
        this.click(o, 0.09, 2200, 0.4);
      });
    } else {
      run(r * 0.2, () => {
        this.click(o, 0, 1700, 0.3);
        this.N(o, 0, 'bandpass', 500, 1, 0.1, 0.1);
      });
      run(r * 0.58, () => {
        this.T(o, 0, 170, 90, 0.25, 0.09);
        this.click(o, 0, 1900, 0.35);
      });
      run(r - (pis ? 0.2 : 0.28), () => {
        this.click(o, 0, 1200, 0.4);
        this.click(o, pis ? 0.05 : 0.1, pis ? 2000 : 2300, 0.33);
      });
    }
  },
  empty() {
    if (!this.ok()) return;
    this.click(this.bus, 0, 2600, 0.25);
    this.T(this.bus, 0, 260, 170, 0.15, 0.06);
  },
  equip(id) {
    this.rk++;
    if (!this.ok()) return;
    this.click(this.bus, 0, 1000, 0.3);
    this.N(this.bus, 0, 'bandpass', 800, 0.9, 0.1, 0.14, 0.08);
  },
  beep(p) {
    if (!this.ok()) return;
    const o = this.out(p, 90);
    if (!o) return;
    this.T(o, 0.12, 1750, 1700, 0.22, 0.1);
    this.T(o, 0.05, 3500, 3400, 0.08, 0.06);
  },
  bomb(k) {
    if (!this.ok()) return;
    const o = this.bus;
    if (k === 'boom') {
      this.N(o, 0.5, 'lowpass', 600, 0.6, 1.6, 1.4);
      this.T(o, 0.4, 90, 22, 1.4, 1.2);
      this.N(o, 0.3, 'highpass', 2000, 0.6, 0.5, 0.4);
    } else if (k === 'plant') {
      for (let i = 0; i < 4; i++) this.click(o, i * 0.18, 1400 + i * 250, 0.35);
      this.T(o, 0.1, 300, 500, 0.25, 0.3, 0.7);
    } else if (k === 'defuse') {
      this.T(o, 0.1, 500, 900, 0.25, 0.4);
      this.click(o, 0, 2200, 0.35);
      this.click(o, 0.1, 1600, 0.35);
    } else if (k === 'tick') this.click(o, 0, 2400, 0.12);
  },
  hit(h) {
    if (!this.ok()) return;
    this.T(this.bus, 0, h ? 2400 : 1600, h ? 2000 : 1300, h ? 0.28 : 0.2, h ? 0.14 : 0.07);
    if (h) this.T(this.bus, 0, 3200, 2800, 0.18, 0.1);
  },
  hurt(n) {
    if (!this.ok()) return;
    const v = Math.min(1, 0.3 + n / 60);
    this.T(this.bus, 0, 130, 50, 0.55 * v, 0.22);
    this.N(this.bus, 0.08, 'lowpass', 1000, 0.6, 0.5 * v, 0.18);
  },
  scope(on) {
    if (!this.ok()) return;
    this.click(this.bus, 0, on ? 1900 : 1400, 0.2);
    this.N(this.bus, 0, 'bandpass', on ? 1200 : 800, 0.8, 0.07, 0.12);
  },
  update() {
    if (!this.ok()) return;
    const L = this.ac.listener,
      p = camera.position,
      d = camera.getWorldDirection(this._d || (this._d = new THREE.Vector3()));
    if (L.positionX) {
      L.positionX.value = p.x;
      L.positionY.value = p.y;
      L.positionZ.value = p.z;
      L.forwardX.value = d.x;
      L.forwardY.value = d.y;
      L.forwardZ.value = d.z;
      L.upX.value = 0;
      L.upY.value = 1;
      L.upZ.value = 0;
    } else {
      L.setPosition(p.x, p.y, p.z);
      L.setOrientation(d.x, d.y, d.z, 0, 1, 0);
    }
  }
};
['pointerdown', 'keydown', 'touchstart'].forEach(ev =>
  addEventListener(ev, () => Sfx.unlock(), { capture: true })
);
