/* ========= MODO TREINO: campo de tiro (bots parados · em movimento · relâmpago · placas · parede de madeira · caixas) =========
   Não mexe no Ascent: ao entrar, o mundo do mapa é escondido e a colisão/alvos são trocados pelos do campo; ao sair, tudo volta. */
const TR = {
  xc: 57.5,
  zN: 16,
  zS: 104,
  hw: 18,
  z0: 96
}; /* centro X · parede norte · parede sul · meia largura · linha de tiro (em metros) */
const Training = {
  on: false,
  w: null,
  segs: [],
  boxes: [],
  statics: [],
  bots: [],
  plates: [],
  targets: [],
  hid: [],
  pt: 1,
  st: { shots: 0, hits: 0, heads: 0, kills: 0, dmg: 0 },
  build() {
    const W = (this.w = new THREE.Group()),
      X = TR.xc,
      hw = TR.hw,
      zN = TR.zN,
      zS = TR.zS,
      z0 = TR.z0,
      LZ = zS - zN,
      mid = (zN + zS) / 2;
    const std = (c, r, m) =>
        new THREE.MeshStandardMaterial({
          color: c,
          roughness: r == null ? 0.8 : r,
          metalness: m || 0
        }),
      bas = c => new THREE.MeshBasicMaterial({ color: c });
    const box = (w, h, d, x, y, z, mat, tg, sh) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      m.position.set(x, y, z);
      if (sh !== 0) m.castShadow = m.receiveShadow = true;
      W.add(m);
      if (tg) this.statics.push(m);
      return m;
    };
    const seg = (ax, az, bx, bz, top) => this.segs.push([ax, az, bx, bz, -1, null, top]);
    const hex = c => '#' + c.toString(16).padStart(6, '0');
    /* ---- chão: ladrilhos, faixas, linhas de distância e linha de tiro (textura desenhada) ---- */
    const fl = canvasTex(
      1024,
      2048,
      (x, w, h) => {
        const ym = z => ((z - zN) / LZ) * h,
          xm = u => ((u + hw) / (2 * hw)) * w;
        x.fillStyle = '#2a3445';
        x.fillRect(0, 0, w, h);
        speckle(x, w, h, 2500, 0.05);
        x.strokeStyle = 'rgba(255,255,255,.055)';
        x.lineWidth = 2;
        for (let u = -hw; u <= hw; u += 3) {
          x.beginPath();
          x.moveTo(xm(u), 0);
          x.lineTo(xm(u), h);
          x.stroke();
        }
        for (let z = zN; z <= zS; z += 3) {
          x.beginPath();
          x.moveTo(0, ym(z));
          x.lineTo(w, ym(z));
          x.stroke();
        }
        x.fillStyle = 'rgba(56,225,255,.16)';
        for (const u of [-hw + 1.2, hw - 1.2]) x.fillRect(xm(u) - 7, 0, 14, h);
        x.fillStyle = 'rgba(255,70,85,.14)';
        x.fillRect(xm(0) - 4, 0, 8, ym(z0));
        x.textAlign = 'center';
        x.font = 'bold 54px sans-serif';
        for (let d = 10; d <= 80; d += 10) {
          const y = ym(z0 - d);
          x.fillStyle = 'rgba(56,225,255,.55)';
          x.fillRect(0, y - 3, w, 6);
          for (const u of [-hw + 4.5, hw - 4.5]) {
            x.save();
            x.translate(xm(u), y - 12);
            x.scale(1, 0.818);
            x.fillStyle = 'rgba(180,240,255,.8)';
            x.fillText(d + ' M', 0, 0);
            x.restore();
          }
        }
        const yl = ym(z0);
        x.fillStyle = '#ff4655';
        x.fillRect(0, yl - 9, w, 18);
        x.fillStyle = 'rgba(255,255,255,.85)';
        for (let i = 0; i < w; i += 64) x.fillRect(i, yl - 9, 32, 18);
        x.save();
        x.translate(xm(0), yl + 90);
        x.scale(1, 0.818);
        x.fillStyle = 'rgba(255,255,255,.75)';
        x.font = 'bold 64px sans-serif';
        x.fillText('LINHA DE TIRO', 0, 0);
        x.restore();
        x.fillStyle = 'rgba(255,199,43,.18)';
        x.fillRect(0, ym(z0 + 2), w, h);
      },
      1,
      1
    );
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(2 * hw, LZ),
      new THREE.MeshStandardMaterial({ map: fl, roughness: 0.9, metalness: 0.05 })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(X, 0, mid);
    floor.receiveShadow = true;
    W.add(floor);
    this.statics.push(floor);
    /* ---- paredes (colisão + alvo de tiro), faixas de luz, postes e letreiro ---- */
    const wm = std(0x1e2736, 0.85);
    box(0.6, 7, LZ + 1.2, X - hw - 0.3, 3.5, mid, wm, 1);
    box(0.6, 7, LZ + 1.2, X + hw + 0.3, 3.5, mid, wm, 1);
    box(2 * hw + 1.2, 7, 0.6, X, 3.5, zN - 0.3, wm, 1);
    box(2 * hw + 1.2, 7, 0.6, X, 3.5, zS + 0.3, wm, 1);
    seg(X - hw, zN, X + hw, zN);
    seg(X + hw, zN, X + hw, zS);
    seg(X + hw, zS, X - hw, zS);
    seg(X - hw, zS, X - hw, zN);
    box(0.05, 0.28, LZ, X - hw + 0.03, 2.4, mid, bas(0x38e1ff), 0, 0);
    box(0.05, 0.28, LZ, X + hw - 0.03, 2.4, mid, bas(0xff4655), 0, 0);
    box(2 * hw, 0.28, 0.05, X, 2.4, zN + 0.03, bas(0xffc72b), 0, 0);
    box(2 * hw, 0.28, 0.05, X, 2.4, zS - 0.03, bas(0xc18cff), 0, 0);
    for (let z = zN + 6; z <= zS - 6; z += 12)
      for (const sx of [-1, 1]) {
        box(0.35, 5.5, 0.35, X + sx * (hw - 0.2), 2.75, z, std(0x2e3a50, 0.6, 0.4));
        box(0.5, 0.3, 0.5, X + sx * (hw - 0.2), 5.65, z, bas(0xdff6ff), 0, 0);
      }
    const board = (w, h, cw, ch, draw) =>
      new THREE.MeshBasicMaterial({ map: canvasTex(cw, ch, draw, 1, 1), side: THREE.DoubleSide });
    const sg = new THREE.Mesh(
      new THREE.PlaneGeometry(22, 5.5),
      board(22, 5.5, 1024, 256, (x, w, h) => {
        x.fillStyle = '#0d1422';
        x.fillRect(0, 0, w, h);
        x.strokeStyle = '#ff4655';
        x.lineWidth = 8;
        x.strokeRect(10, 10, w - 20, h - 20);
        x.fillStyle = '#ff4655';
        x.save();
        x.translate(110, h / 2);
        x.rotate(Math.PI / 4);
        x.fillRect(-34, -34, 68, 68);
        x.restore();
        x.textAlign = 'left';
        x.fillStyle = '#fff';
        x.font = 'bold 80px sans-serif';
        x.fillText('CAMPO DE TREINO', 190, 128);
        x.fillStyle = '#ff8791';
        x.font = 'bold 40px sans-serif';
        x.fillText('V A V A   D E   H O M E M', 194, 190);
      })
    );
    sg.position.set(X, 4.4, zN + 0.08);
    W.add(sg);
    /* ---- placas de zona (billboards) ---- */
    const sign = (t, sub, x, z, c) => {
      const cv = canvasTex(
        512,
        128,
        (g, w, h) => {
          g.fillStyle = 'rgba(10,15,25,.86)';
          g.fillRect(0, 0, w, h);
          g.fillStyle = c;
          g.fillRect(0, 0, 12, h);
          g.textAlign = 'left';
          g.fillStyle = '#fff';
          g.font = 'bold 46px sans-serif';
          g.fillText(t, 30, 58);
          g.fillStyle = c;
          g.font = 'bold 28px sans-serif';
          g.fillText(sub, 30, 98);
        },
        1,
        1
      );
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: cv, transparent: true }));
      s.scale.set(7, 1.75, 1);
      s.position.set(x, 4.3, z);
      W.add(s);
    };
    sign('ALVOS PARADOS', '10 · 20 · 30 · 45 · 60 M', X, z0 - 8, '#38e1ff');
    sign('EM MOVIMENTO', 'acompanhe o strafe', X, z0 - 28, '#ff9a3d');
    sign('RELÂMPAGO', 'bots surgem do chão', X, z0 - 44, '#ffc72b');
    sign('PLACAS', 'acerte e derrube', X, z0 - 62, '#ff4655');
    sign('PAREDE DE MADEIRA', 'as balas atravessam', X - 14, z0 - 32, '#c18cff');
    /* ---- caixas de movimento (1,0 m e 1,5 m dá pra subir pulando; 2,3 m só a Jett) ---- */
    const crate = (x, z, w, d, h, c) => {
      box(w, h, d, x, h / 2, z, std(c, 0.7, 0.1), 1);
      box(w + 0.05, 0.12, d + 0.05, x, h - 0.06, z, bas(0x38e1ff), 0, 0);
      const x1 = x - w / 2,
        x2 = x + w / 2,
        z1 = z - d / 2,
        z2 = z + d / 2;
      seg(x1, z1, x2, z1, h);
      seg(x2, z1, x2, z2, h);
      seg(x2, z2, x1, z2, h);
      seg(x1, z2, x1, z1, h);
      this.boxes.push([x1, z1, x2, z2, h]);
    };
    crate(X - 13, z0 - 3, 1.6, 1.6, 1, 0xe8453c);
    crate(X - 10.2, z0 - 2.8, 1.4, 1.4, 1.5, 0xf0c030);
    crate(X + 13, z0 - 3, 1.6, 1.6, 2.3, 0x3a6bff);
    crate(X + 10.2, z0 - 2.8, 1.4, 1.4, 1, 0x2fbf71);
    /* ---- parede de madeira: as balas atravessam (userData.pen=1) ---- */
    const ww = box(7, 3.2, 0.3, X - 14, 1.6, z0 - 32, std(0xa8612f, 0.7), 1);
    ww.userData.pen = 1;
    box(7.1, 0.14, 0.34, X - 14, 3.25, z0 - 32, std(0x7a3f1c, 0.7), 0);
    /* ---- placas redondas: acertou, caiu; volta depois de 1,6 s ---- */
    const plate = (x, d) => {
      const g = new THREE.Group();
      g.position.set(X + x, 0, z0 - d);
      const post = new THREE.Mesh(
        new THREE.CylinderGeometry(0.05, 0.06, 1.2, 8),
        std(0x3a4658, 0.6, 0.4)
      );
      post.position.y = 0.6;
      g.add(post);
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.38, 0.08, 16), std(0x1b2230));
      base.position.y = 0.04;
      g.add(base);
      const pv = new THREE.Group();
      pv.position.y = 1.2;
      g.add(pv);
      const P = { g, pv, up: 1, t: 0 };
      const ring = (r, c, z) => {
        const ge = new THREE.CylinderGeometry(r, r, 0.05, 20);
        ge.rotateX(Math.PI / 2);
        const m = new THREE.Mesh(ge, std(c, 0.5, 0.1));
        m.position.set(0, 0.3, z);
        pv.add(m);
        return m;
      };
      const o = ring(0.3, 0xff4655, 0);
      ring(0.21, 0xffffff, 0.03);
      ring(0.12, 0xff4655, 0.06);
      ring(0.05, 0xffd23a, 0.09);
      o.userData.plate = P;
      P.hit = o;
      this.plates.push(P);
      W.add(g);
    };
    [
      [-15, 12],
      [15, 12],
      [-16, 28],
      [16, 28],
      [-8, 48],
      [8, 48],
      [0, 66],
      [14, 70]
    ].forEach(a => plate(a[0], a[1]));
    /* ---- bots ---- */
    const bot = (type, x, d, ag, gn, o) => {
      const root = new THREE.Group(),
        av = mkBody(ag, 0, 1, gn);
      root.add(av);
      root.position.set(X + x, 0, z0 - d);
      const ring = new THREE.Mesh(
        new THREE.CylinderGeometry(0.55, 0.6, 0.06, 20),
        bas(type === 'pop' ? 0xffc72b : type === 'strafe' ? 0xff9a3d : 0x38e1ff)
      );
      ring.position.set(X + x, 0.03, z0 - d);
      if (type !== 'pop') W.add(ring);
      const hits = av.children.filter(c => c.userData.p),
        mats = [],
        seen = new Set();
      av.traverse(c => {
        if (c.isMesh) {
          c.castShadow = true;
          const m = c.material;
          if (m && m.emissive && !seen.has(m)) {
            seen.add(m);
            mats.push({ m, e: m.emissive.getHex(), i: m.emissiveIntensity });
          }
        }
      });
      const b = Object.assign(
        {
          type,
          root,
          av,
          hits,
          mats,
          hp: 100,
          dead: 0,
          dt: 0,
          fall: 0,
          up: 1,
          fl: 0,
          dir: Math.random() < 0.5 ? -1 : 1,
          pa: 0,
          state: 'up',
          t: 0
        },
        o || {}
      );
      hits.forEach(h => {
        h.userData.bot = b;
      });
      W.add(root);
      this.bots.push(b);
      return b;
    };
    [
      [-9, 10, 0, 0],
      [0, 10, 1, 1],
      [9, 10, 2, 2],
      [-13, 20, 3, 3],
      [13, 20, 4, 0],
      [-6, 30, 0, 1],
      [6, 30, 1, 0],
      [0, 45, 2, 4],
      [-12, 60, 3, 1],
      [12, 60, 4, 0]
    ].forEach(a => bot('static', a[0], a[1], TRN_AG[a[2]], TRN_GN[a[3]]));
    bot('static', -14, 35, TRN_AG[2], 'phantom'); /* atrás da parede de madeira */
    [
      [-10, 25, -16, -4, 3],
      [10, 35, 4, 16, 4.2],
      [0, 50, -5, 5, 2.6]
    ].forEach((a, i) =>
      bot('strafe', a[0], a[1], TRN_AG[(i + 1) % 5], TRN_GN[i], {
        x0: X + a[2],
        x1: X + a[3],
        sp: a[4]
      })
    );
    [
      [-4, 16],
      [4, 16],
      [-16, 24],
      [16, 24],
      [-10, 40],
      [10, 40],
      [0, 55],
      [-17, 65],
      [17, 65]
    ].forEach((a, i) => {
      const b = bot('pop', a[0], a[1], TRN_AG[i % 5], TRN_GN[i % 6], { state: 'hid', up: 0 });
      b.root.position.y = -2.4;
    });
    W.traverse(o => {
      o.matrixAutoUpdate = true;
    });
  },
  rebuild() {
    const t = this.statics.slice();
    for (const b of this.bots) if (b.up && !b.dead) t.push(...b.hits);
    for (const p of this.plates) if (p.up) t.push(p.hit);
    this.targets = t;
    Weapon.targets = t;
  },
  flash(b, on) {
    for (const o of b.mats) {
      o.m.emissive.setHex(on ? 0xff2a2a : o.e);
      o.m.emissiveIntensity = on ? 0.7 : o.i;
    }
    b.fl = on ? 0.1 : 0;
  },
  dn(pt, txt, cls) {
    const v = pt.clone().project(camera);
    if (v.z > 1) return;
    const e = document.createElement('div');
    e.className = 'dn ' + (cls || '');
    e.textContent = txt;
    e.style.left = (v.x * 0.5 + 0.5) * innerWidth + 'px';
    e.style.top = (-v.y * 0.5 + 0.5) * innerHeight + 'px';
    document.body.appendChild(e);
    setTimeout(() => e.remove(), 750);
  },
  hit(e) {
    const o = e.object,
      u = o && o.userData;
    if (!u) return;
    const pl = u.plate,
      b = u.bot;
    if (pl) {
      if (!pl.up) return;
      pl.up = 0;
      pl.t = 0;
      this.st.hits++;
      Sfx.hit(false);
      Hud.hitmark(false);
      this.dn(e.point, '✔', 'pl');
      this.rebuild();
      this.refresh();
      return;
    }
    if (!b || b.dead || !b.up) return;
    const w = WR[e.weapon],
      p = u.p,
      mv = Mv.dmg || 1;
    let d = e.damage;
    if (p === 'h') d = e.head || (w && !w.melee ? (w.head || d * 3) * mv : d);
    else if (p === 'l') d = e.leg || e.damage * 0.85;
    d = Math.round(d);
    const dealt = Math.min(d, b.hp);
    b.hp -= d;
    const kill = b.hp <= 0,
      hd = p === 'h';
    this.st.hits++;
    this.st.dmg += dealt;
    if (hd) this.st.heads++;
    Sfx.hit(hd);
    Hud.hitmark(hd || kill);
    this.flash(b, 1);
    this.dn(e.point, d, (kill ? 'k ' : '') + (hd ? 'h' : p === 'l' ? 'l' : ''));
    if (kill) {
      b.dead = 1;
      b.hp = 0;
      b.dt = b.type === 'pop' ? 1.1 : 2.6;
      b.fall = 0;
      b.up = 0;
      this.st.kills++;
      this.rebuild();
    }
    this.refresh();
  },
  refresh() {
    const s = this.st;
    $$('tAc').textContent = s.shots ? Math.round((s.hits / s.shots) * 100) + '%' : '—';
    $$('tHs').textContent = s.hits ? Math.round((s.heads / s.hits) * 100) + '%' : '—';
    $$('tK').textContent = s.kills;
    $$('tD').textContent = Math.round(s.dmg);
  },
  resetStats() {
    this.st = { shots: 0, hits: 0, heads: 0, kills: 0, dmg: 0 };
    this.refresh();
    toast('Estatísticas zeradas');
  },
  resetTargets() {
    for (const b of this.bots) {
      b.dead = 0;
      b.hp = 100;
      b.fall = 0;
      b.av.rotation.x = 0;
      this.flash(b, 0);
      if (b.type === 'pop') {
        b.state = 'hid';
        b.up = 0;
        b.root.position.y = -2.4;
      } else {
        b.up = 1;
        b.root.position.y = 0;
      }
    }
    for (const p of this.plates) {
      p.up = 1;
      p.t = 0;
      p.pv.rotation.x = 0;
    }
    this.rebuild();
  },
  respawn(b) {
    b.dead = 0;
    b.hp = 100;
    b.fall = 0;
    b.av.rotation.x = 0;
    if (b.type === 'pop') {
      b.state = 'hid';
      b.up = 0;
      b.root.position.y = -2.4;
    } else b.up = 1;
    this.rebuild();
  },
  tick(dt) {
    if (!this.on) return;
    if (Econ.c < 9000) {
      Econ.c = 9000;
      Hud.cred();
    }
    if (Hp.v < 100) {
      Hp.v = 100;
      Hud.hp(100);
    }
    if (Abil.st)
      Abil.st.forEach((s, i) => {
        s.cd = 0;
        const a = Abil.ab && Abil.ab[i];
        if (a && a.rr) s.u = a.rr;
        if (a && a.chg) s.n = CHG[a.chg].max; /* no treino as cargas nunca acabam */
      });
    Abil.ult = ULT_COST; /* habilidades e ultimate sempre prontas */
    const a = Weapon.ammo[Weapon.cur];
    if (a && a.res < 900) a.res = 999;
    let ch = 0;
    for (const b of this.bots) {
      if (b.fl > 0) {
        b.fl -= dt;
        if (b.fl <= 0) this.flash(b, 0);
      }
      if (b.dead) {
        b.dt -= dt;
        b.fall = Math.min(1, b.fall + dt / 0.35);
        b.av.rotation.x = b.fall * 1.45;
        if (b.dt <= 0) this.respawn(b);
        continue;
      }
      if (b.type === 'strafe') {
        if (b.pa > 0) b.pa -= dt;
        else {
          const r = b.root.position;
          r.x += b.dir * b.sp * dt;
          if (r.x < b.x0 || r.x > b.x1) {
            r.x = Math.max(b.x0, Math.min(b.x1, r.x));
            b.dir *= -1;
            b.pa = 0.3;
          } else if (Math.random() < dt * 0.6) {
            b.dir *= -1;
            b.pa = 0.12;
          }
        }
      } else if (b.type === 'pop') {
        const r = b.root.position;
        b.t += dt;
        if (b.state === 'rise') {
          r.y = -2.4 + 2.4 * Math.min(1, b.t / 0.22);
          if (b.t >= 0.22) {
            b.state = 'up';
            b.t = 0;
            b.ho = 1.7 + Math.random() * 0.9;
          }
        } else if (b.state === 'up') {
          if (b.t >= b.ho) {
            b.state = 'low';
            b.t = 0;
          }
        } else if (b.state === 'low') {
          r.y = -2.4 * Math.min(1, b.t / 0.22);
          if (b.t >= 0.22) {
            b.state = 'hid';
            b.up = 0;
            ch = 1;
          }
        }
      }
      if (b.up || b.type === 'pop') {
        const r = b.root.position;
        b.root.rotation.y = Math.atan2(-(pos.x - r.x), -(pos.z - r.z));
      }
    }
    this.pt -= dt;
    if (this.pt <= 0) {
      this.pt = 0.8 + Math.random() * 1.3;
      const hid = this.bots.filter(b => b.type === 'pop' && b.state === 'hid' && !b.dead),
        act = this.bots.filter(b => b.type === 'pop' && b.state !== 'hid' && !b.dead).length;
      if (hid.length && act < 3) {
        const b = hid[Math.floor(Math.random() * hid.length)];
        b.state = 'rise';
        b.t = 0;
        b.up = 1;
        ch = 1;
      }
    }
    for (const p of this.plates) {
      if (!p.up) {
        p.t += dt;
        p.pv.rotation.x = -1.5 * Math.min(1, p.t / 0.15);
        if (p.t > 1.6) {
          p.up = 1;
          p.pv.rotation.x = 0;
          ch = 1;
        }
      }
    }
    if (ch) this.rebuild();
  },
  start() {
    Menu.cancel();
    Menu.on = false;
    document.body.classList.remove('menu');
    $$('menu').style.display = 'none';
    if (!this.w) this.build();
    const keep = new Set([camera].concat(FX.p || [], Tracer.p));
    this.hid = [];
    scene.children.slice().forEach(o => {
      if (o.isLight || keep.has(o) || o === sun.target || o === this.w) return;
      this.hid.push([o, o.visible]);
      o.visible = false;
    });
    scene.add(this.w);
    this.segsBak = segs.slice();
    segs.length = 0;
    segs.push(...this.segs);
    this.boxBak = BOXES.slice();
    BOXES.length = 0;
    BOXES.push(...this.boxes);
    this.tgBak = Weapon.targets;
    Inv.owned = {};
    Inv.slots = { pri: null, sec: null, mel: null };
    Inv.armor = 0;
    Weapon.ammo = {};
    Game.side = 'atk';
    Stats.reset();
    for (const id in WR) {
      Inv.owned[id] = 1;
      Weapon.give(id);
    }
    Inv.slots = { pri: 'vandal', sec: 'classic', mel: KPick.id };
    Econ.c = 9000;
    Abil.set(Game.agent || 'phoenix');
    this.bgBak = [scene.background.getHex(), scene.fog.color.getHex()];
    scene.background.setHex(0x0b1220);
    scene.fog.color.setHex(0x0b1220);
    this.on = true;
    Round.phase = 'buy';
    Round.k = '';
    Weapon.equip('vandal');
    pos.set(TR.xc, EYE, TR.z0 + 2.5);
    vel.set(0, 0, 0);
    yaw = 0;
    pitch = 0;
    Mv.h = 0;
    Mv.vy = 0;
    Hp.v = 100;
    Hud.hp(100);
    Recoil.zero();
    Hud.cred();
    Hud.arm();
    Hud.weapon();
    this.st = { shots: 0, hits: 0, heads: 0, kills: 0, dmg: 0 };
    this.pt = 1;
    this.resetTargets();
    this.refresh();
    $$('score').style.display = 'none';
    $$('mini').style.display = 'none';
    $$('trn').classList.add('on');
    $$('sct').textContent = 'ARSENAL LIVRE';
    $$('sct').className = 'wh';
    if (Weapon.vm) Weapon.vm.visible = true;
    Hud.flash();
    toast('Treino: T zera estatísticas · Y reinicia alvos · B arsenal livre');
  },
  stop() {
    if (!this.on) return;
    this.on = false;
    scene.remove(this.w);
    for (const [o, v] of this.hid) o.visible = v;
    this.hid = [];
    segs.length = 0;
    segs.push(...this.segsBak);
    BOXES.length = 0;
    BOXES.push(...this.boxBak);
    Weapon.targets = this.tgBak;
    scene.background.setHex(this.bgBak[0]);
    scene.fog.color.setHex(this.bgBak[1]);
    $$('score').style.display = '';
    $$('mini').style.display = '';
    $$('trn').classList.remove('on');
    document.querySelectorAll('.dn').forEach(e => e.remove());
  }
};
const TRN_AG = ['phoenix', 'neon', 'jett', 'omen', 'yoru'],
  TRN_GN = ['vandal', 'phantom', 'spectre', 'classic', 'operator', 'stinger'];
