# VAVA de MacHo

FPS tático no navegador. Fontes modulares em `src/`; `npm run build` gera o HTML final em `dist/`.

## Publicar no GitHub Pages

Siga o tutorial completo em [GITHUB_PAGES.md](GITHUB_PAGES.md). O workflow `.github/workflows/pages.yml` compila e publica automaticamente quando há push na branch `main`.

## Desenvolvimento local

- `npm run build` — gera `dist/index.html` e `dist/vava_de_macho.html`.
- `npm start` — inicia o servidor Node.js antigo em `http://localhost:3000`.
- `npm run dev` — build + servidor.

## Multiplayer e limitações

O jogo mantém o modo offline/bots e o P2P manual PeerJS (criar sala/entrar com código). O matchmaking automático e as contas persistentes dependem do servidor `server/server.js`; GitHub Pages não executa Node.js nem mantém WebSocket. Veja [GITHUB_PAGES.md](GITHUB_PAGES.md) antes de publicar.

Leia `CLAUDE.md` antes de alterar a arquitetura do projeto.
